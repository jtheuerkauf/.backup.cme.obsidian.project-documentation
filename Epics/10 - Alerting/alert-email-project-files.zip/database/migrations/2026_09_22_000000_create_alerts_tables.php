<?php
declare(strict_types=1);

namespace Database\Migrations;

use App\Enums\Alerts\AlertType;
use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration {
    /**
     * Run the migrations.
     */
    public function up(): void
    {
        Schema::create(
            'alerts',
            function(Blueprint $table)
            {
                $table->id();
                $table->enum(
                    'type_key',
                    array_map(AlertType::getSlug(...), AlertType::cases()),
                );
                $table->string('name');
                $table->json('source_config')->nullable();
                $table->unsignedInteger('definition_version')->default(1);
                $table->timestamp('enabled_at')->nullable();
                $table->timestamp('disabled_at')->nullable();
                $table->timestamp('created_at')->useCurrent();
                $table->timestamp('updated_at')->useCurrent()->useCurrentOnUpdate();
                $table->index(['type_key', 'enabled_at']);
            },
        );

        Schema::create(
            'alert_schedules',
            function(Blueprint $table)
            {
                $table->id();
                $table->foreignId('alert_id')->constrained();
                $table->string('schedule_type');
                $table->string('schedule_definition');
                $table->string('timezone');
                $table->json('data_params');
                $table->char('data_params_hash', 64);
                $table->timestamp('next_run_at')->nullable();
                $table->timestamp('enabled_at')->nullable();
                $table->timestamp('disabled_at')->nullable();
                $table->timestamp('created_at')->useCurrent();
                $table->timestamp('updated_at')->useCurrent()->useCurrentOnUpdate();
                $table->index(['enabled_at', 'next_run_at']);
                $table->unique(['alert_id', 'data_params_hash']);
            },
        );

        Schema::create(
            'alert_role_recipients',
            function(Blueprint $table)
            {
                $table->id();
                $table->foreignId('alert_id')->constrained();
                $table->foreignId('role_id')->constrained('roles');
                $table->boolean('enabled')->default(true);
                $table->timestamp('created_at')->useCurrent();
                $table->timestamp('updated_at')->useCurrent()->useCurrentOnUpdate();
                $table->unique(['alert_id', 'role_id']);
            },
        );

        Schema::create(
            'alert_runs',
            function(Blueprint $table)
            {
                $table->id();
                $table->foreignId('alert_id')->constrained();
                $table->foreignId('alert_schedule_id')->constrained();
                $table->timestamp('scheduled_for');
                $table->timestamp('started_at')->nullable();
                $table->timestamp('completed_at')->nullable();
                $table->string('status');
                $table->string('idempotency_key');
                $table->json('context')->nullable();
                $table->string('error_summary')->nullable();
                $table->timestamp('created_at')->useCurrent();
                $table->timestamp('updated_at')->useCurrent()->useCurrentOnUpdate();
                $table->unique(['alert_schedule_id', 'scheduled_for']);
                $table->unique('idempotency_key');
                $table->index(['alert_id', 'scheduled_for']);
                $table->index(['status', 'started_at']);
            },
        );
    }

    /**
     * Reverse the migrations.
     */
    public function down(): void
    {
        Schema::dropIfExists('alert_runs');
        Schema::dropIfExists('alert_role_recipients');
        Schema::dropIfExists('alert_schedules');
        Schema::dropIfExists('alerts');
    }
};
