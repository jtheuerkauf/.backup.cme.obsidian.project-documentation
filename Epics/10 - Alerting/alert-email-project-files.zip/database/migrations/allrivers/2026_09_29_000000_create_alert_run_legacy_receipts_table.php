<?php
declare(strict_types=1);

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    protected $connection = 'allrivers';

    public function up(): void
    {
        Schema::connection('allrivers')->create('alert_run_legacy_receipts', function (Blueprint $table): void {
            $table->string('idempotency_key')->primary();
            $table->string('name');
            $table->date('run_date');
            $table->unsignedInteger('line_count');
            $table->char('payload_hash', 64);
            $table->timestamp('created_at')->useCurrent();
        });
    }

    public function down(): void
    {
        Schema::connection('allrivers')->dropIfExists('alert_run_legacy_receipts');
    }
};
