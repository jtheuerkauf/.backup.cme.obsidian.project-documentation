<?php
declare(strict_types=1);

use App\Enums\Email\EmailType;
use App\Models\Email;
use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    public function up(): void
    {
        $replacementMap = EmailType::mailableClassReplacements();

        $unknown = Email::distinct()
            ->whereNotNull('mailable')
            ->pluck('mailable')->flip()
            // Any from the DB that aren't in the Enum? Bail: they need to be mapped.
            ->diffKeys($replacementMap);
        if ($unknown->isNotEmpty()) {
            throw new RuntimeException('Unknown emails.mailable values: ' . $unknown->implode(', '));
        }

        foreach ($replacementMap as $class => $typeSlug) {
            Email::where('mailable', $class)->update(['mailable' => $typeSlug]);
        }

        Schema::table('emails', function (Blueprint $table): void {
            $table->enum('mailable', EmailType::slugs())->nullable()->change();
        });
    }

    public function down(): void
    {
        Schema::table('emails', function (Blueprint $table): void {
            $table->string('mailable', 255)->nullable()->change();
        });

        foreach (EmailType::mailableClassReplacements() as $class => $slug) {
            Email::where('mailable', $slug)->update(['mailable' => $class]);
        }
    }
};
