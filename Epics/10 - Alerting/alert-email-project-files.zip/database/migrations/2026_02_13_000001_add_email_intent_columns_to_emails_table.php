<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    /**
     * Run the migrations.
     */
    public function up(): void
    {
        Schema::table('emails', function (Blueprint $table) {
            $table->string('email_type', 100)
                ->after('provider');

            $table->string('mailable', 255)
                ->nullable()
                ->after('email_type');

            $table->string('related_type', 255)
                ->nullable()
                ->after('mailable');

            $table->unsignedBigInteger('related_id')
                ->nullable()
                ->after('related_type');

            $table->unsignedBigInteger('initiator_user_id')
                ->nullable()
                ->after('related_id');

            $table->unsignedBigInteger('model_action_log_id')
                ->nullable()
                ->after('initiator_user_id');

            $table->timestamp('queued_at')
                ->nullable()
                ->after('status');

            $table->string('dedupe_key', 255)
                ->nullable()
                ->after('message_id');

            $table->index('email_type', 'emails_email_type_idx');
            $table->index('related_type', 'emails_related_type_idx');
            $table->index('related_id', 'emails_related_id_idx');
            $table->index('initiator_user_id', 'emails_initiator_user_id_idx');
            $table->index('model_action_log_id', 'emails_model_action_log_id_idx');
            $table->unique('dedupe_key', 'emails_dedupe_key_unique');

            $table->foreign('model_action_log_id', 'emails_model_action_log_id_fk')
                ->references('id')
                ->on('model_action_logs')
                ->nullOnDelete();
        });
    }

    /**
     * Reverse the migrations.
     */
    public function down(): void
    {
        Schema::table('emails', function (Blueprint $table) {
            $table->dropForeign('emails_model_action_log_id_fk');

            $table->dropUnique('emails_dedupe_key_unique');
            $table->dropIndex('emails_email_type_idx');
            $table->dropIndex('emails_related_type_idx');
            $table->dropIndex('emails_related_id_idx');
            $table->dropIndex('emails_initiator_user_id_idx');
            $table->dropIndex('emails_model_action_log_id_idx');

            $table->dropColumn([
                'email_type',
                'mailable',
                'related_type',
                'related_id',
                'initiator_user_id',
                'model_action_log_id',
                'queued_at',
                'dedupe_key',
            ]);
        });
    }
};
