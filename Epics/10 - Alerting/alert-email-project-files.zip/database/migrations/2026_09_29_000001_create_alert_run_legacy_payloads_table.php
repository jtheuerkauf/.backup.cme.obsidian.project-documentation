<?php
declare(strict_types=1);

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    public function up(): void
    {
        Schema::create('alert_run_legacy_payloads', function (Blueprint $table): void {
            $table->foreignId('alert_run_id')->primary()->constrained('alert_runs')->cascadeOnDelete();
            $table->json('payload');
            $table->timestamp('created_at')->useCurrent();
        });
    }

    public function down(): void
    {
        Schema::dropIfExists('alert_run_legacy_payloads');
    }
};
