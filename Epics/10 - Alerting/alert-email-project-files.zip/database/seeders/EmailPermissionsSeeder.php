<?php
declare(strict_types=1);

namespace Database\Seeders;

use App\Enums\Email\EmailType;
use App\Enums\PermissionCode;
use App\Models\Permission;
use App\Models\Role;
use Illuminate\Database\Eloquent\Builder;
use Illuminate\Database\Seeder;

class EmailPermissionsSeeder extends Seeder
{
    public function run(): void
    {
        $guardName = config('auth.defaults.guard');
        foreach (EmailType::cases() as $mailable) {
            Permission::updateOrCreate(
                ['code' => $mailable->permissionCode(), 'guard_name' => $guardName],
                ['name' => 'View ' . $mailable->display() . ' Emails'],
            );
        }

        $allPermission = Permission::updateOrCreate(
            ['code' => PermissionCode::MailableAll->slug(), 'guard_name' => $guardName],
            ['name' => 'View All Emails'],
        );

        Role::query()
            ->whereHas('permissions', fn(Builder $query) => $query->where('code', PermissionCode::AllAccess->slug()))
            ->get()
            ->each(fn(Role $role) => $role->givePermissionTo($allPermission));
    }
}
