<?php
declare(strict_types=1);

namespace Database\Seeders\Alerts;

use App\DTO\Alerts\AlertSourceConfig;
use App\Enums\Alerts\AlertType;
use App\Enums\Alerts\ScheduleType;
use App\Models\Alerts\Alert;
use App\Models\Alerts\AlertSchedule;
use App\Models\Role;
use App\Services\Alerts\AlertsRegistry;
use Carbon\CarbonImmutable;
use Cron\CronExpression;
use DateTimeZone;
use Exception;
use Illuminate\Database\Seeder;
use Illuminate\Support\Facades\DB;
use InvalidArgumentException;
use TypeError;

/**
 * Extend this class and override seedData(), or copy it to a new seeder and edit seedData().
 * Add the alert's enum case, collector, and config/alerts.php registry entry before running it.
 */
abstract class AbstractAlertSeeder extends Seeder
{
    /**
     * Put all alert-specific values here. Leave IDs and data_params_hash to the write methods.
     *
     * @return array{
     *   alert: array{
     *     type_key: AlertType,
     *     name: string,
     *     source_config: array<string, mixed>,
     *   },
     *   schedule: array{
     *     schedule_type: ScheduleType,
     *     schedule_definition: string,
     *     timezone: string,
     *     data_params: array<string, mixed>,
     *   },
     *   recipient_roles: array<int|string, int|string|bool>,
     * }
     */
    abstract protected function seedData(): array;
    // {
    //     return [
    //         'alert' => [
    //             'name' => 'Replace with alert display name',
    //             /*
    //              * alerts.type_key: add this value as an AlertType enum case and as a key in config/alerts.php.
    //              */
    //             'type_key' => 'replace-with-alert-type-CASE: AlertType::CaseName',
    //             /*
    //              * alerts.source_config: source settings not already defined by the source models.
    //              */
    //             'source_config' => [],
    //         ],
    //         'schedule' => [
    //             /*
    //              * alert_schedules.schedule_type: add a ScheduleType case before using a new value.
    //              * This template calculates next_run_at from a cron expression.
    //              * Currently only cron-style is supported
    //              */
    //             'schedule_type' => ScheduleType::Cron,
    //             'schedule_definition' => 'replace-with-cron-schedule-string: * * * * *',
    //             /*
    //              * IANA TZDB name is expected:
    //              * any entry available from DateTimeZone::listIdentifiers()
    //              */
    //             'timezone' => 'America/New_York',
    //             /*
    //              * alert_schedules.data_params: collector inputs; the seeder calculates data_params_hash.
    //              */
    //             'data_params' => [],
    //         ],
    //         /*
    //          * alert_role_recipients.role_id: integers are IDs; strings look up roles.code exactly.
    //          * Add every role that should receive this alert, for example 590 or 'ROLE_CODE'.
    //          * To specify enabled true/false, make the ID/Code the array key and the value true/false.
    //          * [
    //          *   'FOO',
    //          *   'BAR' => false,
    //          *      25 => true,
    //          *      30,
    //          * ] will produce: [
    //          *    {int} => ['enabled' => true],
    //          *    {int} => ['enabled' => false],
    //          *       25 => ['enabled' => true],
    //          *       30 => ['enabled' => true],
    //          * ]
    //          */
    //         'recipient_roles' => ['replace-with-role-codes'],
    //     ];
    // }

    public function run(): void
    {
        $data = $this->seedData();
        [$type, $scheduleType, $timezone, $roles, $definitionVersion] = $this->normalizeData($data);

        DB::transaction(
            function() use ($data, $type, $scheduleType, $timezone, $roles, $definitionVersion): void
            {
                $alert = $this->writeAlert($data['alert'], $type, $definitionVersion);
                $this->writeSchedule($alert, $data['schedule'], $scheduleType, $timezone);
                $this->writeRecipients($alert, $roles);
            },
        );
    }

    /**
     * Validate all planted values before making any writes.
     *
     * @param array<string, mixed> $data
     *
     * @return array{AlertType, ScheduleType, DateTimeZone, array<int, array{enabled: bool}>, int}
     */
    private function normalizeData(array $data): array
    {
        try {
            $type = $this->validAlertType($data['alert']['type_key']);
        } catch (TypeError $e) {
            throw new InvalidArgumentException(
                'alerts.type_key must be an AlertType enum case.',
                previous: $e,
            );
        }
        /*
         * definitionVersion() throws when the type has no entry in config/alerts.php.
         */
        $definitionVersion = app(AlertsRegistry::class)->definitionVersion($type);

        try {
            $scheduleType = $this->validScheduleType($data['schedule']['schedule_type']);
        } catch (TypeError $e) {
            throw new InvalidArgumentException(
                'alert_schedules.schedule_type must be a ScheduleType enum case.',
                previous: $e,
            );
        }

        $this->validScheduleExpression($data['schedule']['schedule_definition'], $scheduleType);

        $timezone = $this->validTimeZone($data['schedule']['timezone']);

        $roles = $this->validRoles($data['recipient_roles']);

        return [
            $type,
            $scheduleType,
            $timezone,
            $roles,
            $definitionVersion,
        ];
    }

    private function validAlertType(AlertType $type): AlertType
    {
        if ($type->slug() !== $type->value) {
            throw new InvalidArgumentException("AlertType::{$type->name} value should match the slug() return string.");
        }

        return $type;
    }

    private function validScheduleType(ScheduleType $scheduleType): ScheduleType
    {
        return match ($scheduleType) {
            /*
             * Add new supported types here as a list of matches:
             * ScheduleType::Cron,
             * ScheduleType::SpecialDate => $scheduleType,
             */
            ScheduleType::Cron => $scheduleType,
            default => throw new InvalidArgumentException(
                "ScheduleType [{$scheduleType->value}] is not yet supported.",
            ),
        };
    }

    private function validScheduleExpression(string $expression, ScheduleType $scheduleType): void
    {
        $validCronExpression = match ($scheduleType) {
            ScheduleType::Cron => CronExpression::isValidExpression($expression),
            default => false,
        };
        if (!$validCronExpression) {
            $message = match ($scheduleType) {
                ScheduleType::Cron => 'Invalid alert_schedules.schedule_definition cron expression.',
                default => "Unsupported schedule_definition for schedule type [{$scheduleType->name}]",
            };

            throw new InvalidArgumentException($message);
        }
    }

    /**
     * @param array<int|string, int|string|bool> $recipientRoles
     *
     * @return array<int, array{enabled: bool}>
     */
    private function validRoles(array $recipientRoles): array
    {
        $roleIds = [];
        foreach ($recipientRoles as $roleKey => $roleValue) {
            $enabled = true;
            if (is_bool($roleValue)) {
                [$enabled, $roleValue] = [$roleValue, $roleKey];
            }
            if (!(is_int($roleValue) || is_string($roleValue))) {
                throw new InvalidArgumentException('Alert recipients must be integer role IDs or roles.code strings.');
            }
            $role = is_int($roleValue)
                ? Role::query()->find($roleValue)
                : Role::query()->where('code', $roleValue)->first();
            if ($role === null) {
                throw new InvalidArgumentException("No role matches recipient role [{$roleValue}].");
            }
            $roleIds[$role->id] = ['enabled' => $enabled];
        }

        return $roleIds;
    }

    private function validTimeZone(string $timezoneName): DateTimeZone
    {
        try {
            $timezone = new DateTimeZone($timezoneName);
        } catch (Exception $e) {
            throw new InvalidArgumentException("Invalid alert_schedules.timezone [{$timezoneName}].", previous: $e);
        }

        return $timezone;
    }

    /**
     * @param array{
     *   type_key: AlertType,
     *   name: string,
     *   source_config: array<string, mixed>,
     * } $data
     */
    private function writeAlert(array $data, AlertType $type, int $definitionVersion): Alert
    {
        return Alert::query()->updateOrCreate(
            [
                'type_key' => $type->slug(),
                'name' => $data['name'],
            ],
            [
                'source_config' => new AlertSourceConfig($data['source_config']),
                'definition_version' => $definitionVersion,
                'enabled_at' => now(),
                'disabled_at' => null,
            ],
        );
    }

    /**
     * @param array{
     *   schedule_type: ScheduleType,
     *   schedule_definition: string,
     *   timezone: string,
     *   data_params: array<string, mixed>,
     * } $data
     */
    private function writeSchedule(Alert $alert, array $data, ScheduleType $type, DateTimeZone $timezone): void
    {
        $paramsHash = AlertSchedule::dataParamsHash($data['data_params']);
        $schedule = AlertSchedule::query()->firstOrNew(
            [
                'alert_id' => $alert->id,
                'data_params_hash' => $paramsHash,
            ],
        );
        $schedule->alert()->associate($alert);
        $schedule->fill(
            [
                'schedule_type' => $type,
                'schedule_definition' => $data['schedule_definition'],
                'timezone' => $data['timezone'],
                'data_params' => $data['data_params'],
                'enabled_at' => now(),
                'disabled_at' => null,
            ],
        );
        if (!$schedule->exists || $schedule->next_run_at === null) {
            $schedule->next_run_at = CarbonImmutable::instance(
                (new CronExpression($data['schedule_definition']))->getNextRunDate(
                    now($timezone),
                    0,
                    false,
                    $data['timezone'],
                ),
            );
        }
        $schedule->save();

        // Keep only this schedule enabled for the alert.
        AlertSchedule::query()
            ->where('alert_id', $alert->id)
            ->whereNot('id', $schedule->id)
            ->whereNull('disabled_at')
            ->update(['disabled_at' => now()]);
    }

    /**
     * @param array<int, array{enabled: bool}> $roles
     */
    private function writeRecipients(Alert $alert, array $roles): void
    {
        /*
         * Preserve existing recipients when rerunning the seeder.
         */
        $alert->roles()->syncWithoutDetaching($roles);
    }
}
