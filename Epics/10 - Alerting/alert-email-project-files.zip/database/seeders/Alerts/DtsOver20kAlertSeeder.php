<?php
declare(strict_types=1);

namespace Database\Seeders\Alerts;

use App\Enums\Alerts\AlertType;
use App\Enums\Alerts\ScheduleType;

final class DtsOver20kAlertSeeder extends AbstractAlertSeeder
{
    protected function seedData(): array
    {
        return [
            'alert' => [
                'type_key' => AlertType::DtsOver20k,
                'name' => 'Trackers with DTS-1 or DTS-3 Orders over $20K',
                'source_config' => [],
            ],
            'schedule' => [
                'schedule_type' => ScheduleType::Cron,
                'schedule_definition' => '0 4 * * *',
                'timezone' => 'America/New_York',
                'data_params' => ['minimum_dts_total' => 20_000],
            ],
            'recipient_roles' => [590, 'DTSPM', 'VPSSO'],
        ];
    }
}
