<?php

declare(strict_types=1);

namespace Database\Seeders;

// use Illuminate\Database\Console\Seeds\WithoutModelEvents;
use Database\Seeders\AllRivers\LateFeeInvoiceSeeder;
use Database\Seeders\Navigation\CustomerServiceNavigationSeeder;
use Illuminate\Database\Seeder;

class DatabaseSeeder extends Seeder
{
    /**
     * Seed the application's database.
     */
    public function run(): void
    {

        $this->call([
            POSubmissionSeeder::class,
            LateFeeInvoiceSeeder::class,
            CpqApiUserSeeder::class,
            GitLabTimeTrackingPermissionSeeder::class,
            EmailPermissionsSeeder::class,
            DiscrepancyDashboardPermissionsSeeder::class,
            PendingSpecialOrderPermissionsSeeder::class,
            EmailDashboardNavigationSeeder::class,
            VendorCcReceiptPermissionsSeeder::class,
            VendorSetupPermissionsSeeder::class,
            OutboundTrackingPermissionsSeeder::class,
            WarehouseRouterPermissionsSeeder::class,
            ContractorQuotePermissionsSeeder::class,
            MasterQuotePermissionsSeeder::class,
            MasterProjectPermissionsSeeder::class,
            PortalUserManagementPermissionsSeeder::class,
            AmTerritoryManagementPermissionsSeeder::class,
            CustomerServiceNavigationSeeder::class,
        ]);
    }
}
