<?php
declare(strict_types = 1);

namespace Database\Seeders;

use App\Enums\Navigation\NavLinkType;
use App\Enums\Navigation\NavTarget;
use App\Enums\PermissionCode;
use App\Models\Navigation\Navigation;
use App\Models\Permission;
use Database\Seeders\Navigation\Traits\ResolvesNavigationAccess;
use Illuminate\Database\Seeder;

class EmailDashboardNavigationSeeder extends Seeder
{
    use ResolvesNavigationAccess;

    public function run(): void {
        $navigation = Navigation::updateOrCreate(
            ['slug' => 'email-dashboard'],
            [
                'parent_id' => null,
                'label' => 'Email Dashboard',
                'type' => NavLinkType::SIDEBAR,
                'target' => NavTarget::INTERNAL,
                'link' => 'email-dashboard.index',
                'icon' => 'envelope-open',
                'sort_order' => 200,
                'is_active' => true,
            ],
        );

        $permissions = Permission::query()
            ->where('code', PermissionCode::MailableAll->slug())
            ->orWhere('code', 'like', 'mailable-%')
            ->get();

        $this->syncNavigationPermissions($navigation, $permissions);
    }
}
