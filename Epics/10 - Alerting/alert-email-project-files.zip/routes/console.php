<?php

use App\Jobs\Auth\PruneSyntheticBrowserUsersJob;
use App\Jobs\Discrepancies\SyncTrackingAddedJob;
use App\Jobs\Invoices\GenerateApDocumentReviewDailySummary;
use App\Jobs\Locks\PruneExpiredResourceLocks;
use App\Jobs\Portal\QueuePortalBillToBillingSyncsJob;
use App\Jobs\SalesforceSync\DispatchSalesforceSync;
use App\Jobs\SalesforceSync\DispatchSalesforceTrueUp;
use App\Jobs\SendMonthlyInvoicedStorageReceivablesExport;
use Illuminate\Support\Facades\Schedule;

// Disabled pending validation: this job can deactivate portal users based on Salesforce parent-network data.
// use App\Jobs\Portal\DeactivateUsersOutsideParentIdnJob;

$isNewrivers = fn (): bool => config('scheduler.server') === 'newrivers';
$isDocrivers = fn (): bool => config('scheduler.server') === 'docrivers';
$isMobiWorkQueueEnabled = fn(): bool => $isNewrivers() && config('mobiwork_sync.queue_enabled');
$displayTimezone = config('app.display_timezone');

Schedule::everyFifteenSeconds()
    ->onOneServer()
    ->withoutOverlapping()
    ->environments(['production'])
    ->when($isNewrivers)
    ->group(function (): void {
        Schedule::command('cpq:poll');
        Schedule::command('cpq:orders');
        Schedule::command('cpq:aplus');
        Schedule::command('aplus:orders');
    });

Schedule::command('po-submissions:send-rejected-reminders')
    ->hourly()
    ->withoutOverlapping()
    ->onOneServer()
    ->environments(['production'])
    ->when($isNewrivers);

Schedule::command('po-submissions:notify-long-hold')
    ->hourly()
    ->withoutOverlapping()
    ->onOneServer()
    ->environments(['production'])
    ->when($isNewrivers);

Schedule::everyFiveMinutes()
    ->withoutOverlapping()
    ->onOneServer()
    ->environments(['production'])
    ->when($isDocrivers)
    ->group(function (): void {
        Schedule::command('documents:discover');
        Schedule::command('invoices:queue-validation');
        Schedule::command('invoices:requeue-blocked-vouching');
    });

Schedule::command('aplussync:check-health');

// Schedule::command('orders:queue-special-order-po-creation')
//     ->everyFiveMinutes()
//     ->withoutOverlapping()
//     ->onOneServer()
//     ->environments(['production'])
//     ->when($isDocrivers);

Schedule::command('aplussync:run --hash')
    ->everyTwoMinutes()
    ->withoutOverlapping()
    ->onOneServer()
    ->environments(['production'])
    ->when($isDocrivers);

Schedule::command('aplussync:run')
    ->everyTwoMinutes()
    ->withoutOverlapping()
    ->onOneServer()
    ->environments(['production'])
    ->when($isDocrivers);

Schedule::command('aplussync:prune-history')
    ->dailyAt('05:00')
    ->timezone($displayTimezone)
    ->withoutOverlapping()
    ->onOneServer()
    ->environments(['production'])
    ->when($isDocrivers);

Schedule::command('aplussync:send-daily-status')
    ->dailyAt('05:15')
    ->timezone($displayTimezone)
    ->withoutOverlapping()
    ->onOneServer()
    ->environments(['production'])
    ->when($isDocrivers);

Schedule::command('pmhubsync:run')
    ->everyTwoMinutes()
    ->withoutOverlapping()
    ->onOneServer()
    ->environments(['production'])
    ->when($isDocrivers);

Schedule::job(new DispatchSalesforceSync)
    ->everyTwoMinutes()
    ->withoutOverlapping()
    ->onOneServer()
    ->environments(['production'])
    ->when($isNewrivers);

Schedule::job(new DispatchSalesforceTrueUp)
    ->dailyAt('03:00')
    ->timezone('America/New_York')
    ->withoutOverlapping()
    ->onOneServer()
    ->environments(['production'])
    ->when($isNewrivers);

Schedule::command('cpqsync:run')
    ->everyTwoMinutes()
    ->withoutOverlapping()
    ->onOneServer()
    ->environments(['production'])
    ->when($isNewrivers);

Schedule::command('cpqsync:send-daily-status')
    ->dailyAt('05:15')
    ->timezone('America/New_York')
    ->withoutOverlapping()
    ->onOneServer()
    ->environments(['production'])
    ->when($isNewrivers);

Schedule::job(new GenerateApDocumentReviewDailySummary)
    ->dailyAt('00:00')
    ->timezone($displayTimezone)
    ->onOneServer()
    ->environments(['production'])
    ->when($isNewrivers);

Schedule::job(new SendMonthlyInvoicedStorageReceivablesExport)
    ->monthlyOn(1, '06:00')
    ->timezone($displayTimezone)
    ->withoutOverlapping()
    ->onOneServer()
    ->environments(['production'])
    ->when($isNewrivers);

Schedule::command('invoices:calculate-vendor-number-patterns')
    ->dailyAt('04:00')
    ->timezone($displayTimezone)
    ->withoutOverlapping()
    ->onOneServer()
    ->runInBackground()
    ->environments(['production'])
    ->when($isDocrivers);

Schedule::command('callsheet:counts')
    ->dailyAt('00:05')
    ->timezone($displayTimezone)
    ->withoutOverlapping(60)
    ->onOneServer()
    ->runInBackground()
    ->environments(['production'])
    ->when($isNewrivers);

Schedule::command('portal:queue-local-billto-syncs')
    ->hourly()
    ->timezone(config('scheduler.portal_local_billto_sync.timezone', $displayTimezone))
    ->withoutOverlapping()
    ->onOneServer()
    ->environments(['production'])
    ->when(fn (): bool => $isDocrivers() && (bool) config('scheduler.portal_local_billto_sync.enabled'));

Schedule::job(new QueuePortalBillToBillingSyncsJob)
    ->hourly()
    ->timezone($displayTimezone)
    ->withoutOverlapping()
    ->onOneServer()
    ->environments(['production'])
    ->when($isDocrivers);

Schedule::job(new PruneExpiredResourceLocks)
    ->everyFiveMinutes()
    ->withoutOverlapping()
    ->onOneServer()
    ->environments(['production'])
    ->when($isNewrivers);

Schedule::job(new PruneSyntheticBrowserUsersJob)
    ->environments(['production'])
    ->everyThirtyMinutes()
    ->withoutOverlapping()
    ->onOneServer()
    ->when($isNewrivers);

// Disabled pending validation: do not automatically deactivate portal users.
// Schedule::job(new DeactivateUsersOutsideParentIdnJob)
//     ->dailyAt('01:00')
//     ->timezone($displayTimezone)
//     ->withoutOverlapping()
//     ->onOneServer()
//     ->environments(['production'])
//     ->when($isDocrivers);

Schedule::command('ldap:sync-active-users')
    ->dailyAt('09:00')
    ->environments(['production'])
    ->withoutOverlapping()
    ->onOneServer();

Schedule::command('form-rivers:process-spool')
    ->environments(['production'])
    ->timezone($displayTimezone)
    ->everyFifteenSeconds()
    ->withoutOverlapping()
    ->onOneServer()
    ->when($isDocrivers);

Schedule::command('pmhub:send-dts-tracker-assignment-alert')
    ->dailyAt('11:00')
    ->timezone($displayTimezone)
    ->weekdays()
    ->withoutOverlapping()
    ->onOneServer()
    ->environments(['production'])
    ->when($isNewrivers);

Schedule::command('alerts:send-billing-hold-over-seven-days')
    ->weeklyOn(1, '06:00')
    ->timezone($displayTimezone)
    ->withoutOverlapping()
    ->onOneServer()
    ->environments(['production'])
    ->when($isNewrivers);

Schedule::command('alerts:dispatch-due')
    ->everyMinute()
    ->withoutOverlapping()
    ->onOneServer()
    ->environments(['production'])
    ->when($isNewrivers);

Schedule::command('queue:dispatch-recoveries')
    ->everyMinute()
    ->environments(['staging'])
    ->timezone($displayTimezone)
    ->withoutOverlapping()
    ->onOneServer();

Schedule::command('item-types:send-submission-decision-digest')
    ->dailyAt('17:00')
    ->timezone($displayTimezone)
    ->weekdays()
    ->withoutOverlapping()
    ->onOneServer()
    ->environments(['production'])
    ->when($isNewrivers);

Schedule::command('item-types:send-pending-review-digest')
    ->weeklyOn(5, '17:00')
    ->timezone($displayTimezone)
    ->withoutOverlapping()
    ->onOneServer()
    ->environments(['production'])
    ->when($isNewrivers);

Schedule::command('bpo:daily-sync')
    ->dailyAt('07:00')
    ->timezone($displayTimezone)
    ->withoutOverlapping()
    ->onOneServer()
    ->environments(['production'])
    ->when($isNewrivers);

Schedule::job(new SyncTrackingAddedJob)
    ->dailyAt('00:00')
    ->timezone($displayTimezone)
    ->withoutOverlapping()
    ->onOneServer()
    ->environments(['production'])
    ->when($isNewrivers);

Schedule::command('gitlab:sync')
    ->hourly()
    ->withoutOverlapping()
    ->onOneServer()
    ->environments(['production'])
    ->when(fn (): bool => $isNewrivers() && ! empty(config('services.gitlab.groups')));

Schedule::command('gitlab:backfill-task-parent-rollups')
    ->hourlyAt(40)
    ->withoutOverlapping()
    ->onOneServer()
    ->environments(['production'])
    ->when(fn (): bool => $isNewrivers() && ! empty(config('services.gitlab.groups')));

Schedule::command('gitlab:sync --all-branches')
    ->dailyAt('02:10')
    ->timezone($displayTimezone)
    ->withoutOverlapping()
    ->onOneServer()
    ->environments(['production'])
    ->when(fn (): bool => $isNewrivers() && ! empty(config('services.gitlab.groups')));

Schedule::command('dropship-shipment-notifications:send daily')
    ->dailyAt('18:00')
    ->timezone($displayTimezone)
    ->withoutOverlapping()
    ->onOneServer()
    ->environments(['production'])
    ->when($isDocrivers);

Schedule::command('dropship-shipment-notifications:send weekly')
    ->weeklyOn(5, '18:30')
    ->timezone($displayTimezone)
    ->withoutOverlapping()
    ->onOneServer()
    ->environments(['production'])
    ->when($isDocrivers);

Schedule::command('app:alert-pm-customer-need-by-date')
    ->dailyAt('08:00')
    ->timezone($displayTimezone)
    ->withoutOverlapping()
    ->onOneServer()
    ->environments(['production'])
    ->when($isNewrivers);
