<?php

use App\Http\Controllers\Auth\LoginController;
use App\Http\Controllers\Auth\LogoutController;
use App\Http\Controllers\Web\AllRivers\InvoiceLateFeeController;
use App\Http\Controllers\Web\AllRivers\OrderDetailController;
use App\Http\Controllers\Web\AllRivers\VendorCreditCardReceiptFileController;
use App\Http\Controllers\Web\AmTerritoryManagementController;
use App\Http\Controllers\Web\PayModeController;
use App\Http\Controllers\Web\PrinterController;
use App\Http\Controllers\Web\SpecialtyAmAssignmentManagementController;
use App\Http\Controllers\Web\AssignPermissionController;
use App\Http\Controllers\Web\AssignRoleController;
use App\Http\Controllers\Web\BlanketPoController;
use App\Http\Controllers\Web\BusinessUnitController;
use App\Http\Controllers\Web\DataManagementController;
use App\Http\Controllers\Web\DepartmentController;
use App\Http\Controllers\Web\Dev\BecomeSessionController;
use App\Http\Controllers\Web\EmailDashboardController;
use App\Http\Controllers\Web\FormRivers\FormRiversFileController;
use App\Http\Controllers\Web\HealthCheckController;
use App\Http\Controllers\Web\HistoricalOrderStorageController;
use App\Http\Controllers\Web\InvoicedStorageReviewController;
use App\Http\Controllers\Web\InvoicePdfController;
use App\Http\Controllers\Web\InvoicePdfViewerController;
use App\Http\Controllers\Web\ItemTypesManagementController;
use App\Http\Controllers\Web\LateFeeController;
use App\Http\Controllers\Web\PermissionController;
use App\Http\Controllers\Web\PortalUserManageController;
use App\Http\Controllers\Web\POSubmissionController;
use App\Http\Controllers\Web\POSubmissions\POSubmissionIncompleteController;
use App\Http\Controllers\Web\Reports\GitLabDeveloperWorkSummaryController;
use App\Http\Controllers\Web\Reports\GitLabTimeDashboardController;
use App\Http\Controllers\Web\Reports\GitLabTimeDeveloperController;
use App\Http\Controllers\Web\Reports\GitLabTimeEpicController;
use App\Http\Controllers\Web\Reports\GitLabTimeExportController;
use App\Http\Controllers\Web\Reports\GitLabTimeIssueController;
use App\Http\Controllers\Web\RoleController;
use App\Http\Controllers\Web\StorageCalculationsReviewController;
use App\Http\Controllers\Web\UserController;
use App\Http\Controllers\Web\WarehouseRouterOverrideController;
use App\Http\Controllers\Web\WebtoolsController;
use App\Http\Middleware\AmTerritoryManagementAccess;
use App\Http\Middleware\ApDocumentReviewAccess;
use App\Http\Middleware\Authenticate;
use App\Http\Middleware\ContractorQuoteAccess;
use App\Http\Middleware\DataManagementAccess;
use App\Http\Middleware\DiscrepancyDashboardAccess;
use App\Http\Middleware\EmailDashboardAccess;
use App\Http\Middleware\EmailMessageAccess;
use App\Http\Middleware\GitLabAccess;
use App\Http\Middleware\InvoiceLateFeeAccess;
use App\Http\Middleware\ItemTypesManagementAccess;
use App\Http\Middleware\MasterProjectAccess;
use App\Http\Middleware\MasterQuoteAccess;
use App\Http\Middleware\MasterQuoteAdminAccess;
use App\Http\Middleware\OutboundTrackingAccess;
use App\Http\Middleware\PendingSpecialOrderAccess;
use App\Http\Middleware\PmHubDirectLineImporterAccess;
use App\Http\Middleware\PortalUserManagementAccess;
use App\Http\Middleware\PoSubmissionAccess;
use App\Http\Middleware\VendorCcReceiptsAccess;
use App\Http\Middleware\VendorSetupAccess;
use App\Http\Middleware\WarehouseRouterAccess;
use App\Livewire\ContractorQuotes\CategorizeLines;
use App\Livewire\ContractorQuotes\ExportToCpq;
use App\Livewire\ContractorQuotes\GroupLines;
use App\Livewire\ContractorQuotes\IngestQuote;
use App\Livewire\ContractorQuotes\QuoteBuilder;
use App\Livewire\ContractorQuotes\QuotesIndex;
use App\Livewire\ContractorQuotes\TrimQuote;
use App\Livewire\DataManagement\SpreadsheetImport as DataManagementSpreadsheetImport;
use App\Livewire\ItemTypeManagmentSpreadsheetImport as ItemTypesSpreadsheetImport;
use App\Livewire\MasterQuotes\MasterQuoteBuilder;
use App\Livewire\MasterQuotes\MasterQuoteConfigurations;
use App\Livewire\MasterQuotes\MasterQuoteHistory;
use App\Livewire\MasterQuotes\MasterQuoteShow;
use App\Livewire\OutboundTracking\Index as OutboundTrackingIndex;
use App\Livewire\SupplierFreightRequests\SupplierFreightRequestInterface;
use App\Livewire\WarehousePayroll\SpreadsheetImport as WarehousePayrollSpreadsheetImport;
use App\Models\ContractorQuotes\ContractorQuoteHeader;
use App\Models\Invoice;
use App\Models\MasterProject;
use App\Models\Workflow;
use App\Repositories\Interfaces\APlus\VendorRepositoryInterface;
use App\Http\Middleware\InfrastructureAccess;
use Illuminate\Cookie\Middleware\AddQueuedCookiesToResponse;
use Illuminate\Cookie\Middleware\EncryptCookies;
use Illuminate\Foundation\Http\Middleware\VerifyCsrfToken;
use Illuminate\Http\Request;
use Illuminate\Routing\Middleware\SubstituteBindings;
use Illuminate\Session\Middleware\StartSession;
use Illuminate\Support\Facades\Route;
use Illuminate\View\Middleware\ShareErrorsFromSession;

Route::get('/login', function (Request $request) {
    return redirect()->route('login', $request->query());
});

Route::get('/temp_allrivers/getOrderDetail.php', [OrderDetailController::class, 'show'])
    ->withoutMiddleware([
        EncryptCookies::class,
        AddQueuedCookiesToResponse::class,
        StartSession::class,
        ShareErrorsFromSession::class,
        VerifyCsrfToken::class,
        SubstituteBindings::class,
    ]);
Route::get('/allrivers/getOrderDetail.php', [OrderDetailController::class, 'show'])
    ->withoutMiddleware([
        EncryptCookies::class,
        AddQueuedCookiesToResponse::class,
        StartSession::class,
        ShareErrorsFromSession::class,
        VerifyCsrfToken::class,
        SubstituteBindings::class,
    ]);

require __DIR__ . '/session.php';

Route::prefix('auth')->group(function () {
    Route::get('/login', [LoginController::class, 'showLoginForm'])->name('login');
    Route::post('/login', [LoginController::class, 'handleLogin']);
    Route::post('/logout', [LogoutController::class, 'logout'])->name('logout');
});

Route::middleware(['web', 'auth'])->group(function () {
    Route::get('/', function () {
        // Redirect to dashboard
        return redirect()->route('dashboard');
    })->name('home');

    Route::get('/dashboard', function () {
        return view('pages.dashboard.index');
    })->name('dashboard');

    Route::middleware([MasterProjectAccess::class])->group(function () {
        Route::view('/master-projects', 'pages.master-project.index')
            ->name('master-projects.index');

        Route::get('/master-projects/{masterProject}/edit', function (MasterProject $masterProject) {
            return view('pages.master-project.edit', compact('masterProject'));
        })
            ->name('master-projects.edit');
    });

    Route::prefix('master-quotes')
        ->name('master-quotes.')
        ->middleware(MasterQuoteAccess::class)
        ->group(function () {
            Route::get('/', MasterQuoteBuilder::class)->name('index');
            Route::get('/history', MasterQuoteHistory::class)->name('quotes.index');
            Route::get('/history/{masterQuote}', MasterQuoteShow::class)->name('quotes.show');

            Route::middleware(MasterQuoteAdminAccess::class)->group(function () {
                Route::get('/configurations', MasterQuoteConfigurations::class)->name('configurations');
            });
        });

    Route::view('/notifications', 'pages.notifications.index')
        ->name('notifications.index');

    Route::view('/test/reverb', 'pages.test.test-event-listener')
        ->name('test.reverb');

    Route::prefix('webtools')
        ->name('webtools.')
        ->group(function () {
            $slugPattern = '[[:alpha:]][[:alnum:]-]*(?<!-$)$';

            Route::get('/dashboard/{navigation}', [WebtoolsController::class, 'showDashboardLegacy'])
                ->whereNumber('navigation')
                ->name('dashboard.legacy');
            Route::get('/dashboard/{slug}', [WebtoolsController::class, 'showDashboard'])
                ->where('slug', $slugPattern)
                ->name('dashboard');

            Route::get('/tool/{navigation}', [WebtoolsController::class, 'showToolLegacy'])
                ->whereNumber('navigation')
                ->name('tool.legacy');
            Route::get('/tool/{slug}', [WebtoolsController::class, 'showTool'])
                ->where('slug', $slugPattern)
                ->name('tool');
        });

    Route::prefix('email-dashboard')
        ->name('email-dashboard.')
        ->middleware(EmailDashboardAccess::class)
        ->group(function () {
            Route::get('/', [EmailDashboardController::class, 'index'])->name('index');
            Route::get('/message/{email}', [EmailDashboardController::class, 'message'])
                ->middleware(EmailMessageAccess::class)
                ->name('message');
            Route::get('/message/{email}/attachments/{index}/{location}', [EmailDashboardController::class, 'attachment'])
                ->whereNumber('index')
                ->whereIn('location', ['LV', 'TS'])
                ->middleware(EmailMessageAccess::class)
                ->name('attachment');
        });

    Route::middleware([PoSubmissionAccess::class])->prefix('po-submissions')->group(function () {
        Route::get('/', [POSubmissionController::class, 'index'])->name('po-submissions.index');
        Route::get('/incomplete/{oracle_id}', [POSubmissionIncompleteController::class, 'show'])
            ->name('po-submissions.incomplete');
    });

    Route::get('/po-attachments/{attachment}/download', [POSubmissionController::class, 'download'])
        ->name('po-attachments.download');
    Route::get('/po-attachments/{attachment}/inline', [POSubmissionController::class, 'inline'])
        ->name('po-attachments.inline');

    Route::prefix('vendor-cc-receipts')
        ->name('vendor-cc-receipts.')
        ->middleware([VendorCcReceiptsAccess::class])
        ->group(function () {
            Route::view('/', 'pages.vendor-cc-receipts.index')
                ->name('index');

            Route::get('/{id}', [VendorCreditCardReceiptFileController::class, 'show'])
                ->name('show');
        });

    Route::middleware([VendorSetupAccess::class])
        ->group(function () {
            Route::view('/vendor-setup', 'pages.vendor-setup.index')
                ->name('vendor-setup.index');

            Route::get('/vendor-setup/vendors/search',
                function (Request $request, VendorRepositoryInterface $vendorRepository) {
                    $term = (string)$request->query('term', '');
                    $page = max(1, (int)$request->query('page', 1));
                    $perPage = max(1, (int)$request->query('per_page', 100));

                    return response()->json($vendorRepository->searchOptionsPageByTerm($term, $page, $perPage));
                })->name('vendor-setup.vendor-search');
        });

    Route::get('/warehouse-payroll/import', WarehousePayrollSpreadsheetImport::class)
        ->name('warehouse-payroll.import');

    Route::prefix('business-unit')
        ->as('business_unit.')
        ->group(function () {
            Route::get('/', [BusinessUnitController::class, 'index'])->name('index');
            Route::get('/create', [BusinessUnitController::class, 'create'])->name('create');
            Route::post('/create', [BusinessUnitController::class, 'store'])->name('store');
            Route::get('/{business_unit}/edit', [BusinessUnitController::class, 'edit'])->name('edit');
            Route::put('/{business_unit}/edit', [BusinessUnitController::class, 'update'])->name('update');

            Route::prefix('/{business_unit}/departments')
                ->as('department.')
                ->group(function () {
                    Route::get('/', [DepartmentController::class, 'index'])->name('index');
                    Route::get('/create', [DepartmentController::class, 'create'])->name('create');
                    Route::post('/create', [DepartmentController::class, 'store'])->name('store');
                    Route::get('/{department}', [DepartmentController::class, 'show'])->name('show');
                    Route::get('/{department}/edit', [DepartmentController::class, 'edit'])->name('edit');
                    Route::put('/{department}/edit', [DepartmentController::class, 'update'])->name('update');
                });

            Route::prefix('/printers')
                ->as('printer.')
                ->group(function () {
                    Route::get('/', [PrinterController::class, 'index'])->name('index');
                });
        });

    Route::prefix('authorization')
        ->as('authorization.')
        ->group(function () {
            Route::prefix('role')
                ->as('role.')
                ->group(function () {
                    Route::get('/', [RoleController::class, 'index'])->name('index');
                    Route::post('/create', [RoleController::class, 'store'])->name('store');
                    Route::put('/{role}/edit', [RoleController::class, 'update'])->name('update');
                    Route::post('/{role}/assign-permission', [AssignPermissionController::class, 'setRole'])
                        ->name('assign_permission.store');
                });

            Route::prefix('permission')
                ->as('permission.')
                ->group(function () {
                    Route::get('/', [PermissionController::class, 'index'])->name('index');
                    Route::post('/create', [PermissionController::class, 'store'])->name('store');
                    Route::put('/{permission}/edit', [PermissionController::class, 'update'])->name('update');
                });
        });

    Route::prefix('employee')
        ->as('employee.')
        ->group(function () {
            Route::get('/', [UserController::class, 'index'])->name('index');
            Route::post('/{user}/assign-role', [AssignRoleController::class, 'setRole'])->name('assign_role.store');
            Route::post('/{user}/assign-permission', [AssignPermissionController::class, 'setUser'])
                ->name('assign_permission.store');
        });

    Route::prefix('accounting')
        ->as('accounting.')
        ->group(function () {
            Route::middleware([InvoiceLateFeeAccess::class])->prefix('customer')
                ->as('customer.')
                ->group(function () {
                    Route::prefix('invoice')
                        ->as('invoice.')
                        ->group(function () {
                            Route::get('late-fee', [InvoiceLateFeeController::class, 'index'])->name('late_fee.index');
                            Route::post('late-fee', [InvoiceLateFeeController::class, 'search'])->name('late_fee.search');
                            Route::get('late-fee/{customer}', [InvoiceLateFeeController::class, 'show'])->name('late_fee.show');
                            Route::post('late-fee/{customer}/update', [InvoiceLateFeeController::class, 'update'])
                                ->name('late_fee.update');
                            Route::post('late-fee/{invoice}/reset', [InvoiceLateFeeController::class, 'reset'])
                                ->name('late_fee.reset');
                            Route::get('late-fee/{date}/bulk', [InvoiceLateFeeController::class, 'showBulk'])
                                ->name('late_fee.bulk');
                            Route::post('late-fee/{date}/bulk', [InvoiceLateFeeController::class, 'updateBulk'])
                                ->name('late_fee.bulk_update');
                            Route::get('late-fee/{invoice}/download', [InvoiceLateFeeController::class, 'downloadInvoice'])
                                ->name('late_fee.invoice.download');
                            Route::get('late-fee/download/excel', [InvoiceLateFeeController::class, 'download'])
                                ->name('late_fee.download');
                            Route::get('late-fee/{customer}/download-excel', [InvoiceLateFeeController::class, 'download'])
                                ->name('late_fee.download.customer');
                        });
                });

            Route::prefix('vendor')
                ->as('vendor.')
                ->group(function () {
                    Route::prefix('pay-mode')
                        ->as('pay-mode.')
                        ->group(function() {
                            Route::get('/', [PayModeController::class, 'index'])->name('index');
                            Route::get('/{payment}/download', [PayModeController::class, 'download'])->name('download');
                            Route::post('/combine', [PayModeController::class, 'combine'])->name('combine');
                            Route::get('/open-invoices', [PayModeController::class, 'openInvoice'])->name('open-invoice');
                        });
                });
        });

    Route::middleware([AmTerritoryManagementAccess::class])
        ->group(function () {
            Route::prefix('am-territories')
                ->name('am-territories.')
                ->group(function () {
                    Route::get('/', [AmTerritoryManagementController::class, 'index'])->name('index');
                    Route::get('/export', [AmTerritoryManagementController::class, 'export'])->name('export');
                    Route::get('/managers', [AmTerritoryManagementController::class, 'managerDirectoryPage'])->name('manager-directory');
                    Route::get('/managers/{accountManager}', [AmTerritoryManagementController::class, 'managerWorkspace'])->name('manager-workspace');
                    Route::get('/states/{type}/{state}/zip-3', [AmTerritoryManagementController::class, 'zip3Workspace'])->name('zip3-workspace');
                    Route::post('/states/{type}/{state}/zip-3', [AmTerritoryManagementController::class, 'createZip3Territory'])->name('create-zip3-territory');
                    Route::post('/states/{type}/{state}/zip-3/zip-5', [AmTerritoryManagementController::class, 'createZip5Exception'])->name('create-zip5-exception');
                    Route::post('/states/{type}/{state}/zip-3/{zip3}/zip-5/{territory}/delete', [AmTerritoryManagementController::class, 'deleteZipFiveException'])->name('delete-zip5-exception');
                    Route::get('/history', [AmTerritoryManagementController::class, 'history'])->name('history');
                    Route::get('/cleanup-report', [AmTerritoryManagementController::class, 'zipFiveCleanupReport'])->name('cleanup-report');
                    Route::post('/cleanup-report/orphans/unassigned/{type}/{zip3}', [AmTerritoryManagementController::class, 'deleteUnassignedOrphanZipFiveGroup'])->name('delete-unassigned-orphan-zip5-group');
                    Route::post('/cleanup-report/orphans/{state}/{type}/{zip3}', [AmTerritoryManagementController::class, 'cleanupOrphanZipFiveGroup'])->name('cleanup-orphan-zip5-group');
                    Route::post('/reassign-state', [AmTerritoryManagementController::class, 'reassignState'])->name('reassign-state');
                    Route::post('/reassign-zip', [AmTerritoryManagementController::class, 'reassignZip'])->name('reassign-zip');
                });
        });

    Route::middleware([ItemTypesManagementAccess::class])
        ->group(function () {
            // Redirect for old /item-types-management and /vendor-specialties endpoints
            foreach (['item-types-management', 'vendor-specialties'] as $legacyPath) {
                Route::get('/' . $legacyPath, function (Request $request) {
                    return redirect()->route('item-types-management.index', $request->query());
                });
            }

            Route::prefix('sit-portal')
                ->name('item-types-management.')
                ->group(function () {
                    Route::get('/', [ItemTypesManagementController::class, 'index'])->name('index');
                    Route::get('/import', ItemTypesSpreadsheetImport::class)->name('import');
                    Route::get('/download', [ItemTypesManagementController::class, 'download'])->name('download');
                    Route::get('/download-data', [ItemTypesManagementController::class, 'downloadData'])->name('download-data');
                    Route::get('/vendors/search', [ItemTypesManagementController::class, 'vendorSearch'])
                        ->name('vendor-search');
                    Route::get('/create', [ItemTypesManagementController::class, 'create'])->name('create');
                    Route::get('/{itemType}/edit', [ItemTypesManagementController::class, 'edit'])
                        ->whereNumber('itemType')
                        ->name('edit');
                    Route::delete('/{itemType}', [ItemTypesManagementController::class, 'destroy'])
                        ->whereNumber('itemType')
                        ->name('destroy');
                    Route::post('/upsert', [ItemTypesManagementController::class, 'upsert'])->name('upsert');
                    Route::post('/upsert-force-all', [ItemTypesManagementController::class, 'upsertForceAll'])
                        ->name('upsert-force-all');
                    Route::post('/upsert-force-specific', [ItemTypesManagementController::class, 'upsertForceSpecific'])
                        ->name('upsert-force-specific');
                    Route::post('/bulk-update', [ItemTypesManagementController::class, 'bulkUpdate'])
                        ->name('bulk-update');
                    Route::post('/bulk-delete', [ItemTypesManagementController::class, 'bulkDelete'])
                        ->name('bulk-delete');
                    Route::post('/pending/{row}/approve', [ItemTypesManagementController::class, 'approvePendingRow'])
                        ->name('pending.approve');
                    Route::post('/pending/{row}/reject', [ItemTypesManagementController::class, 'rejectPendingRow'])
                        ->name('pending.reject');
                    Route::post('/pending/{row}/delete', [ItemTypesManagementController::class, 'deletePendingRow'])
                        ->name('pending.delete');
                    Route::post('/pending/{row}/approve-with-all-replace',
                        [ItemTypesManagementController::class, 'approvePendingRowByReplacingWithAll'])
                        ->name('pending.approve-with-all-replace');
                    Route::post('/pending/{row}/approve-with-specific-replace',
                        [ItemTypesManagementController::class, 'approvePendingRowByReplacingWithSpecific'])
                        ->name('pending.approve-with-specific-replace');
                    Route::post('/pending/bulk-approve', [ItemTypesManagementController::class, 'bulkApprovePending'])
                        ->name('pending.bulk-approve');
                    Route::post('/pending/bulk-reject', [ItemTypesManagementController::class, 'bulkRejectPending'])
                        ->name('pending.bulk-reject');
                    Route::post('/pending/bulk-approve-all',
                        [ItemTypesManagementController::class, 'bulkApproveAllPending'])
                        ->name('pending.bulk-approve-all');
                    Route::post('/pending/bulk-reject-all',
                        [ItemTypesManagementController::class, 'bulkRejectAllPending'])
                        ->name('pending.bulk-reject-all');
                    Route::post('/pending/bulk-delete', [ItemTypesManagementController::class, 'bulkDeletePending'])
                        ->name('pending.bulk-delete');
                });
        });

    Route::middleware([DataManagementAccess::class])
        ->prefix('data-management')
        ->name('data-management.')
        ->group(function () {
            Route::get('/', [DataManagementController::class, 'index'])->name('index');
            Route::get('/admin', [DataManagementController::class, 'admin'])->name('admin');
            Route::post('/admin', [DataManagementController::class, 'storeAdmin'])->name('admin.store');
            Route::get('/{table}/create', [DataManagementController::class, 'create'])->name('create');
            Route::post('/{table}/create', [DataManagementController::class, 'store'])->name('store');
            Route::get('/{table}', [DataManagementController::class, 'index'])->name('table');
            Route::get('/{table}/import', DataManagementSpreadsheetImport::class)->name('import');
            Route::get('/{table}/export', [DataManagementController::class, 'export'])->name('export');
            Route::post('/{table}/import', [DataManagementController::class, 'import'])->name('import.upload');
            Route::post('/{table}/bulk-update', [DataManagementController::class, 'bulkUpdate'])->name('bulk-update');
            Route::put('/{table}/{record}', [DataManagementController::class, 'update'])->name('update');
            Route::delete('/{table}/{record}', [DataManagementController::class, 'destroy'])->name('destroy');
        });

    Route::get('/orders/historical/storage', [HistoricalOrderStorageController::class, 'index'])
        ->name('ohs.index');

    Route::get('/orders/storage-calculation', [StorageCalculationsReviewController::class, 'index'])
        ->name('osc.index');

    Route::get('/orders/invoiced-storage-review', [InvoicedStorageReviewController::class, 'index'])
        ->name('invoiced_storage_review.index');

    Route::prefix('api/exports')->name('api.exports.')->group(function () {
        Route::post('/invoiced-storage-receivals',
            [\App\Http\Controllers\Api\ExportController::class, 'storeInvoicedStorageReceivals'])
            ->name('store.invoiced-storage-receivals');
        Route::get('/{id}', [\App\Http\Controllers\Api\ExportController::class, 'show'])->name('show');
        Route::get('/{id}/download', [\App\Http\Controllers\Api\ExportController::class, 'download'])->name('download');
    });

    Route::prefix('exports')->name('exports.')->middleware(['auth'])->group(function () {
        Route::middleware([\App\Http\Middleware\StorageReceivalsReportAccess::class])->group(function () {
            Route::get('/invoiced-storage-receivals',
                [\App\Http\Controllers\Web\ExportRequestController::class, 'create'],
            )->name('invoiced-storage-receivals.create');

            Route::post('/invoiced-storage-receivals',
                [\App\Http\Controllers\Web\ExportRequestController::class, 'store'],
            )->name('invoiced-storage-receivals.store');
        });

        Route::get('/download/{export}',
            \App\Http\Controllers\Web\ExportDownloadController::class,
        )->name('download');
    });

    Route::get('/supplier-freight-requests', SupplierFreightRequestInterface::class)
        ->name('supplier-freight-requests.index');
    Route::prefix('gitlab')->name('gitlab.')->middleware([GitLabAccess::class])->group(function () {
        Route::get('/time-tracking', [GitLabTimeDashboardController::class, 'index'])->name('time-tracking');
        Route::get('/time-tracking/export', [GitLabTimeExportController::class, 'export'])->name('time-tracking.export');
        Route::get('/time-tracking/epics/{epic}', [GitLabTimeEpicController::class, 'show'])->name('time-tracking.epics.show');
        Route::get('/time-tracking/developers/{developer}', [GitLabTimeDeveloperController::class, 'show'])
            ->whereNumber('developer')
            ->name('time-tracking.developers.show');
        Route::get('/tech-staff-summaries', [GitLabDeveloperWorkSummaryController::class, 'index'])->name('tech-staff-summaries.index');
        Route::get('/tech-staff-summaries/developers/{developer}', [GitLabDeveloperWorkSummaryController::class, 'developer'])
            ->whereNumber('developer')
            ->name('tech-staff-summaries.developers.index');
        Route::get('/tech-staff-summaries/{summary}', [GitLabDeveloperWorkSummaryController::class, 'show'])->name('tech-staff-summaries.show');
        Route::get('/time-tracking/issues/{issue}', [GitLabTimeIssueController::class, 'show'])->name('time-tracking.issues.show');
        Route::view('/reviewers', 'pages.gitlab.reviewers')->name('reviewers');
        Route::view('/releases', 'pages.gitlab.releases')->name('releases');
    });

    Route::prefix('infrastructure')->name('infrastructure.')->middleware([InfrastructureAccess::class])->group(function () {
        Route::view('/server-management', 'pages.infrastructure.server-management')->name('server-management');
        Route::view('/server-management/create', 'pages.infrastructure.create-server')->name('server-management.create');
        Route::view('/server-management/reconfigure/{targetHostName}', 'pages.infrastructure.reconfigure-server')->name('server-management.reconfigure');
    });

    Route::get('/supplier-freight-requests', SupplierFreightRequestInterface::class)->name('supplier-freight-requests.index');
    Route::get('/supplier-freight-requests/history', function () {
        $oracleId = request('oracle_id');
        $requests = \App\Models\SupplierFreightRequest::where('oracle_id', $oracleId)->latest()->get();

        return view('pages.supplier-freight-requests.history', compact('requests', 'oracleId'));
    })->name('supplier-freight-requests.history');

    Route::get('/supplier-freight-requests/submitted', function () {
        $ids = explode(',', request('ids', ''));
        $requests = \App\Models\SupplierFreightRequest::whereIn('id', $ids)->get();

        return view('pages.supplier-freight-requests.submitted', compact('requests'));
    })->name('supplier-freight-requests.submitted');

    Route::middleware([PmHubDirectLineImporterAccess::class])->group(function () {
        Route::view('/pm-hub/direct-line-importer', 'pages.pm-hub.direct-line-importer.index')
            ->name('pm-hub.direct-line-importer.index');
    });

    Route::prefix('discrepancies')
        ->name('discrepancies.')
        ->middleware([DiscrepancyDashboardAccess::class])
        ->group(function () {
            Route::view('/', 'pages.discrepancies.index')->name('index');
            Route::view('/add', 'pages.discrepancies.add')->name('add');
            Route::view('/{discrepancy}', 'pages.discrepancies.add')
                ->whereNumber('discrepancy')
                ->name('view');
        });

    Route::prefix('purchasing-callsheet')
        ->name('purchasing-callsheet.')
        ->group(function () {
            Route::view('/', 'pages.purchasing-callsheet.index')->name('index');
        });

    Route::get('/outbound-tracking', OutboundTrackingIndex::class)
        ->middleware(OutboundTrackingAccess::class)
        ->name('outbound-tracking.index');

    Route::prefix('purchasing-special-order-pending')
        ->name('purchasing-special-order-pending.')
        ->middleware([PendingSpecialOrderAccess::class])
        ->group(function () {
            Route::view('/', 'pages.purchasing-special-order-pending.index')->name('index');
        });

    Route::prefix('ap-document-review')
        ->name('ap-document-review.')
        ->middleware([ApDocumentReviewAccess::class])
        ->group(function () {
            Route::view('/invoices', 'pages.ap-document-review.invoices.index')
                ->name('invoices.index');

            Route::get('/invoices/{invoice}', function (Invoice $invoice) {
                return view('pages.ap-document-review.invoices.show', [
                    'invoice' => $invoice,
                    'view' => request('view'),
                    'tab' => request('tab'),
                    'search' => request('search'),
                    'includeVouched' => request('includeVouched'),
                ]);
            })->name('invoices.show');

            Route::get('/invoices/{invoice}/viewer', [InvoicePdfViewerController::class, 'show'])
                ->name('invoices.viewer');

            Route::get('/invoices/{invoice}/pdf', [InvoicePdfController::class, 'show'])
                ->name('invoices.pdf');
        });

    Route::prefix('admin')
        ->name('admin.')
        ->group(function () {
            Route::view('/workflows', 'pages.admin.workflows.index')->name('workflows.index');
            Route::get('/workflows/{workflow}', function (Workflow $workflow) {
                return view('pages.admin.workflows.show', compact('workflow'));
            })->name('workflows.show');

            Route::prefix('warehouse-router')
                ->name('warehouse-router.')
                ->middleware([WarehouseRouterAccess::class])
                ->group(function () {
                    Route::get('/overrides', [WarehouseRouterOverrideController::class, 'index'])
                        ->name('overrides.index');
                    Route::get('/overrides/create', [WarehouseRouterOverrideController::class, 'create'])
                        ->name('overrides.create');
                    Route::post('/overrides', [WarehouseRouterOverrideController::class, 'store'])
                        ->name('overrides.store');
                    Route::get('/overrides/{override}/edit', [WarehouseRouterOverrideController::class, 'edit'])
                        ->name('overrides.edit');
                    Route::put('/overrides/{override}', [WarehouseRouterOverrideController::class, 'update'])
                        ->name('overrides.update');
                    Route::patch('/overrides/{override}/activate',
                        [WarehouseRouterOverrideController::class, 'activate'])->name('overrides.activate');
                    Route::patch('/overrides/{override}/inactivate',
                        [WarehouseRouterOverrideController::class, 'inactivate'])->name('overrides.inactivate');
                    Route::delete('/overrides/{override}', [WarehouseRouterOverrideController::class, 'destroy'])
                        ->name('overrides.destroy');
                    Route::post('/settings', [WarehouseRouterOverrideController::class, 'updateSettings'])
                        ->name('settings.update');
                    Route::get('/projects/options', [WarehouseRouterOverrideController::class, 'projectOptions'])
                        ->name('overrides.project-options');
                    Route::get('/projects/lookup', [WarehouseRouterOverrideController::class, 'projectLookup'])
                        ->name('overrides.project-lookup');
                });
        });

    Route::prefix('portal-user-management')->middleware(PortalUserManagementAccess::class)->group(function () {
        Route::get('/', [PortalUserManageController::class, 'index'])->name('portal-user-management.index');
    });

    Route::prefix('contractor-quotes')->name('contractor-quotes.')
        ->middleware(ContractorQuoteAccess::class)
        ->group(callback: function () {
            Route::get('/', QuotesIndex::class)->name('index');
            Route::get('/{contractorQuoteId}', function (int $contractorQuoteId) {
                ContractorQuoteHeader::query()->findOrFail($contractorQuoteId);

                return redirect()->route('contractor-quotes.overview', [
                    'contractorQuoteId' => $contractorQuoteId,
                ]);
            })->whereNumber('contractorQuoteId');
            Route::get('/{contractorQuoteId}/overview', QuoteBuilder::class)
                ->whereNumber('contractorQuoteId')
                ->name('overview');
            Route::get('/oracle-id/{oracleId}', IngestQuote::class)
                ->whereNumber('oracleId')
                ->name('new');
            Route::get('/{contractorQuoteId}/categorization', CategorizeLines::class)
                ->name('categorization');
            Route::get('/{contractorQuoteId}/download-pdf', [QuoteBuilder::class, 'downloadPdf'])
                ->name('download-pdf');
            Route::get('/{contractorQuoteId}/grouping', GroupLines::class)
                ->name('grouping');
            Route::get('/{contractorQuoteId}/export-to-cpq', ExportToCpq::class)
                ->name('export-to-cpq');
            Route::get('/{contractorQuoteId}/trim', TrimQuote::class)
                ->name('trim-quote');
        });

    Route::view('email-alert-review', 'pages.alert-audit.index')->name('email-alert-review.index');

    Route::prefix('billing-hub')
        ->name('billing-hub.')
        ->group(function () {
            Route::get('/blanket-po', [BlanketPoController::class, 'index'])->name('blanket-po.index');
            Route::get('/monthly-storage', [BlanketPoController::class, 'billingDashboard'])
                ->name('monthly-storage.index');
        });

    Route::prefix('document-generation')
        ->as('document-generation.')
        ->group(function () {
            Route::get('/', [FormRiversFileController::class, 'index'])->name('index');
            Route::post('/search', [FormRiversFileController::class, 'search'])->name('search');
            Route::get('/{file}/show', [FormRiversFileController::class, 'show'])->name('show');
        });

    Route::get('/forbidden', function () {
        $message = request()->query('message', 'Forbidden.');
        abort(403, $message);
    })->name('forbidden');

    Route::prefix('dev')
        ->middleware('auth')
        ->name('dev.')
        ->group(function () {
            Route::get('/become-user', [BecomeSessionController::class, 'index'])->name('become-user.index');
            Route::post('/become-user', [BecomeSessionController::class, 'store'])->name('become-user.store');
            Route::post('/become-user/role', [BecomeSessionController::class, 'storeRole'])
                ->name('become-user.role.store');
            Route::post('/become-user/restore', [BecomeSessionController::class, 'restore'])
                ->name('become-user.restore');
        });
});

// Public (web-only) route to access the new Portal User Lookup component page
Route::middleware(['web'])->group(function () {
    Route::get('/portal/user-lookup', function () {
        return view('pages.portal.user-lookup');
    })->name('portal.user-lookup');
});

Route::get('/health', HealthCheckController::class)->withoutMiddleware([
    Authenticate::class,
    VerifyCsrfToken::class,
]);

Route::prefix('late-fees')->name('late-fees.')->group(function () {
    Route::get('/', [LateFeeController::class, 'index'])->name('index'); // search
    Route::get('/customer/{customer}', [LateFeeController::class, 'edit'])->name('edit'); // edit screen
    Route::post('/customer/{customer}/update', [LateFeeController::class, 'update'])
        ->name('update'); // payments/forgiveness/grace_days
});
