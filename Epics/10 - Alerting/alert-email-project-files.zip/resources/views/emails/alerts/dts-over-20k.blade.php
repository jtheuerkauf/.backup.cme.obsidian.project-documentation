@extends('emails.layouts.base')

@section('content')
    @php
        $withinTwoWeeks = $rows->filter(fn (array $row) => $row['within_two_weeks']);
        $otherRows = $rows->reject(fn (array $row) => $row['within_two_weeks']);
        $tableStyle = 'width:100%; border-collapse:collapse; margin:14px 0 18px; font-size:14px;';
        $headerStyle = 'padding:8px; text-align:left; border:1px solid #dddddd; background:#f5f7fa; vertical-align:top;';
        $cellStyle = 'padding:8px; text-align:left; border:1px solid #dddddd; vertical-align:top;';
    @endphp

    <p style="margin:0 0 14px; color:#6b7280; font-size:12px;">Generated {{ $generatedAt->format('m/d/Y g:i A T') }}</p>

    @foreach ([
        ['heading' => 'Trackers with DTS-1 or DTS-3 Orders over $20K (Within 2 Weeks)', 'rows' => $withinTwoWeeks],
        ['heading' => 'Trackers with DTS-1 or DTS-3 Orders over $20K', 'rows' => $otherRows],
    ] as $group)
        <h2>{{ $group['heading'] }}</h2>
        <table role="presentation" style="{{ $tableStyle }}">
            <thead><tr>
                @foreach (['Tracker #', 'Tracker Created Date', 'Warehouse', 'Project Manager', 'Project Specialist', 'Account Manager', 'Customer Name', 'Address', 'DTS Total Cost', 'Customer Need By Date'] as $heading)
                    <th style="{{ $headerStyle }}">{{ $heading }}</th>
                @endforeach
            </tr></thead>
            <tbody>
                @forelse ($group['rows'] as $row)
                    <tr>
                        <td style="{{ $cellStyle }}"><a href="https://pmhub.cme360.com/trackers/{{ $row['tracker_id'] }}">{{ $row['tracker_number'] }}</a></td>
                        <td style="{{ $cellStyle }}">{{ $row['tracker_created_date'] }}</td><td style="{{ $cellStyle }}">{{ $row['warehouse'] }}</td>
                        <td style="{{ $cellStyle }}">{{ $row['logistics_coordinator_name'] }}</td><td style="{{ $cellStyle }}">{{ $row['project_specialist_name'] }}</td><td style="{{ $cellStyle }}">{{ $row['account_manager_name'] }}</td>
                        <td style="{{ $cellStyle }}">{{ $row['customer_name'] }}</td><td style="{{ $cellStyle }}">{{ $row['address_1'] }}<br>{{ $row['city'] }}, {{ $row['state'] }} {{ $row['zip'] }}</td>
                        <td style="{{ $cellStyle }}">${{ number_format($row['dts_total_cost'], 2) }}@if ($row['previous_dts_total_cost'] !== null && $row['dts_total_cost'] > $row['previous_dts_total_cost']) (Increased ${{ number_format($row['dts_total_cost'] - $row['previous_dts_total_cost'], 2) }}) @endif</td>
                        <td style="{{ $cellStyle }}">{{ $row['customer_need_by_date'] }}</td>
                    </tr>
                @empty
                    <tr><td colspan="10" style="{{ $cellStyle }}">No trackers match this section.</td></tr>
                @endforelse
            </tbody>
        </table>
    @endforeach
@endsection
