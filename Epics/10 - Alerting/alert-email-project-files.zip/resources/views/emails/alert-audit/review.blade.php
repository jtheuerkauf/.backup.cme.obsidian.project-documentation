@extends('emails.layouts.base-dark')

@section('title', 'Review PowerBI Report and Email Alerts')

@section('content')
<p>Email Alert Owners,</p>

<p>Please review this PowerBI report and the Email Alerts that you are the owner of.</p>
<p>
    The second tab named “Alert Trends” is most important and should be where you are focused on your alerts and where you can see the alerts that you are the owner of.
    Please review each alert that you are the owner of.  You should check the alerts you own for the following:
</p>
<ul>
    <li>Accurate name</li>
    <li>Accurate description and can it be improved?</li>
    <li>Accurate frequency – is it properly tagged as repeating or single (one-time) alerts – does the frequency type make sense?</li>
    <li>The report shows how many times the alert tripped in the last 90 days, and each preceding period.  Is the frequency it is hitting and the % change acceptable?  If it is 0, is the alert working as intended?</li>
    <li>Accurate “owner” identified (the owner should always be a person – not a group)</li>
    <li>Is there an alert you receive that is not on the list?</li>
</ul>
<p>
    The first tab, named “Alert Overview”, in the PBI report gives you day-by-day specifics and you can figure out the exact dates your alerts hit.
    If your alert stopped working – you will be able to see the last time it ran on this tab.
</p>

<p>Any request for updating your alert should be emailed directly to <a href="mailto:devrequests@cmecorp.com">devrequests@cmecorp.com</a></p>

<p style="width:100%;text-align: center;">
    <x-interact.a-button
        href="{{ route('email-alert-review.index') }}"
        target="_blank" rel="noopener noreferrer"
        color="text-white bg-blue-600 hover:bg-blue-700">
        <strong>Review Alert</strong>
    </x-interact.a-button>
</p>

<p>Regards,<br>CME Team</p>
@endsection
