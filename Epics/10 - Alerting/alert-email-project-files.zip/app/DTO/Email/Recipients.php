<?php
declare(strict_types=1);

namespace App\DTO\Email;

use Countable;
use Illuminate\Contracts\Support\Arrayable;
use IteratorAggregate;
use Traversable;

/** @implements Arrayable<int, Recipient> */
final readonly class Recipients implements Arrayable, Countable, IteratorAggregate
{
    /**
     * @var list<Recipient>
     */
    private array $recipients;

    public function __construct(
        Recipient ...$recipients,
    ) {
        $this->recipients = $recipients;
    }

    /**
     * @yield Recipient
     */
    public function getIterator(): Traversable
    {
        yield from $this->recipients;
    }

    public function count(): int
    {
        return count($this->recipients);
    }

    /**
     * @return list<Recipient>
     */
    public function toArray(): array
    {
        return $this->recipients;
    }
}
