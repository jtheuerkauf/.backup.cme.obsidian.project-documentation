<?php
declare(strict_types=1);

namespace App\DTO\Email;

use App\Enums\Email\EmailType;

/** One fully resolved message boundary, ready for mail assembly. */
final readonly class EmailBuildRequest
{
    /** @param array<string, mixed> $viewData */
    public function __construct(
        public string $boundaryKey,
        public EmailType $type,
        public Recipients $recipients,
        public string $subject,
        public string $template,
        public array $viewData,
        public ?string $relatedType = null,
        public ?int $relatedId = null,
    ) {}
}
