<?php
declare(strict_types=1);

namespace App\DTO\Email;

use InvalidArgumentException;

final readonly class EmailAddress
{
    public function __construct(
        public string $address,
    ) {
        if (!filter_var($address, FILTER_VALIDATE_EMAIL)) {
            throw new InvalidArgumentException('Invalid email address');
        }
    }
}
