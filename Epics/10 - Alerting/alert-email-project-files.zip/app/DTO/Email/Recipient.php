<?php
declare(strict_types=1);

namespace App\DTO\Email;

use Stringable;

final readonly class Recipient implements Stringable
{
    public function __construct(
        public EmailAddress $email,
        public string $name,
    ) {}

    public function formatted(): string
    {
        return $this->name . ' <' . $this->email->address . '>';
    }

    public function __toString(): string
    {
        return $this->formatted();
    }
}
