<?php
declare(strict_types=1);

namespace App\DTO\Alerts;

use Illuminate\Contracts\Support\Arrayable;

/** @implements Arrayable<string, mixed> */
final readonly class AlertSourceConfig implements Arrayable
{
    /** @param array<string, mixed> $source */
    public function __construct(public array $source) {}

    /** @param array<string, mixed> $source */
    public static function fromArray(array $source): self
    {
        return new self($source);
    }

    /** @return array<string, mixed> */
    public function toArray(): array
    {
        return $this->source;
    }
}
