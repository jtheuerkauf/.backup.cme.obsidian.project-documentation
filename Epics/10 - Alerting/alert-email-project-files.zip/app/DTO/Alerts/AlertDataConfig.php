<?php
declare(strict_types=1);

namespace App\DTO\Alerts;

use Illuminate\Contracts\Support\Arrayable;
use InvalidArgumentException;

/** @implements Arrayable<string, array<string, mixed>> */
final readonly class AlertDataConfig implements Arrayable
{
    /**
     * @param array<string, mixed> $sourceConfig
     * @param array<string, mixed> $dataParams
     */
    public function __construct(
        public array $sourceConfig,
        public array $dataParams,
    ) {}

    /** @param array<string, mixed> $config */
    public static function fromArray(array $config): self
    {
        $sourceConfig = $config['source_config'] ?? null;
        $dataParams = $config['data_params'] ?? null;

        if (! (is_array($sourceConfig) && is_array($dataParams))) {
            throw new InvalidArgumentException('Alert data config requires array "source_config" and "data_params" sections.');
        }

        return new self($sourceConfig, $dataParams);
    }

    /** @return array{source_config: array<string, mixed>, data_params: array<string, mixed>} */
    public function toArray(): array
    {
        return ['source_config' => $this->sourceConfig, 'data_params' => $this->dataParams];
    }
}
