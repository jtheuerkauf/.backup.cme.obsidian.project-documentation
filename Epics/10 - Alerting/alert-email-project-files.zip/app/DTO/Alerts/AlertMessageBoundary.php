<?php
declare(strict_types=1);

namespace App\DTO\Alerts;

use App\DTO\Email\Recipients;

/** The data and audience for exactly one alert message. */
final readonly class AlertMessageBoundary
{
    /** @param list<array<string, mixed>> $rows */
    public function __construct(
        public string $key,
        public array $rows,
        public Recipients $recipients,
    ) {}
}
