<?php
declare(strict_types=1);

namespace App\DTO\Alerts;

use Countable;

/** @phpstan-type PreviewRow list<string> */
final readonly class AlertPreview implements Countable
{
    /**
     * @param list<string>     $headers
     * @param list<PreviewRow> $rows
     */
    public function __construct(
        public array $headers = [],
        public array $rows = [],
    ) {}

    public function count(): int
    {
        return count($this->rows);
    }
}
