<?php
declare(strict_types=1);

namespace App\DTO\Alerts;

use App\Mail\BuiltMail;
use App\Models\Alerts\AlertRun;

/** Collection and processing outcome with the messages queued for this run. */
final readonly class AlertRunOutcome
{
    /** @param list<BuiltMail> $messages */
    public function __construct(
        public AlertRun $run,
        public array $messages = [],
    ) {}
}
