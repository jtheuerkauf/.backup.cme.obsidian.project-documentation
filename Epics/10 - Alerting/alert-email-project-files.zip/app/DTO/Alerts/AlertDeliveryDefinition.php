<?php
declare(strict_types=1);

namespace App\DTO\Alerts;

use App\Services\Alerts\Interfaces\AlertBoundaryPlanner;
use App\Services\Alerts\Interfaces\AlertEmailDataFormatter;
use App\View\Emails\EmailView;

final readonly class AlertDeliveryDefinition
{
    public function __construct(
        public AlertBoundaryPlanner $boundaryPlanner,
        public AlertEmailDataFormatter $formatter,
        public EmailView $view,
    ) {}
}
