<?php

namespace App\Enums;

use App\Enums\Interfaces\DisplayableEnum;
use App\Enums\Traits\Displayable;

enum ProcessStatus: string implements DisplayableEnum
{
    use Displayable;

    case Empty = 'empty';
    case Failed = 'failed';
    case Invalid = 'invalid';
    case Partial = 'partial';
    case Queued = 'queued';
    case Running = 'running';
    case Skipped = 'skipped';
    case Succeeded = 'succeeded';

    public function exit(): int
    {
        return match ($this) {
            self::Succeeded => 0,
            self::Failed => 1,
            default => 2,
        };
    }

    public function display(): string
    {
        return mb_strtolower($this->name);
    }
}
