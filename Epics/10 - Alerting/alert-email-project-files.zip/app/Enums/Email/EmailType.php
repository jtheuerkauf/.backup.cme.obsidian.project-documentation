<?php
declare(strict_types=1);

namespace App\Enums\Email;

use App\Enums\Interfaces\DisplayableEnum;
use App\Enums\Interfaces\SluggableEnum;
use App\Enums\Traits\Displayable;
use App\Enums\Traits\Sluggable;
use App\Mail\Alert\CustomerNeedByDateAlertMail;
use App\Mail\AlertAuditVerifyMail;
use App\Mail\APlusSyncDailyStatusMail;
use App\Mail\APlusSyncOverdueAlertMail;
use App\Mail\BillingHoldAlertMail;
use App\Mail\BlanketPoLowBalanceMail;
use App\Mail\DropshipShipmentNotificationMail;
use App\Mail\DtsOver20kAlertMail;
use App\Mail\DtsTrackerAssignmentMail;
use App\Mail\ExportCompletedMail;
use App\Mail\FluCommentSubmittedMail;
use App\Mail\FormRivers\InvoiceDiscountErrorMail;
use App\Mail\FormRivers\InvoiceIssueMail;
use App\Mail\FormRivers\InvoiceTotalMismatchMail;
use App\Mail\FormRivers\OrderAcknowledgementErrorMail;
use App\Mail\FormRivers\OrderAcknowledgementIssueMail;
use App\Mail\FormRivers\OrderAcknowledgementMail;
use App\Mail\FormRivers\OrderInvoiceMail;
use App\Mail\GenericAlertMail;
use App\Mail\GitLabDeveloperWorkSummaryMail;
use App\Mail\ItemTypePendingReviewDigestMail;
use App\Mail\ItemTypeSubmissionDecisionDigestMail;
use App\Mail\MonthlyInvoicedStorageReceivablesExportMail;
use App\Mail\Portal\CustomerNotificationMail;
use App\Mail\Portal\EmailVerificationMail;
use App\Mail\Portal\GenericNotificationMail;
use App\Mail\Portal\HelpRequestMail;
use App\Mail\Portal\OrderNotificationMail;
use App\Mail\Portal\PasswordResetMail;
use App\Mail\Portal\WelcomeMail;
use App\Mail\POSubmissionDismissedMail;
use App\Mail\POSubmissionIncompleteMail;
use App\Mail\POSubmissionIncompleteReminderMail;
use App\Mail\POSubmissionLongHoldMail;
use App\Mail\POSubmissionOnHoldMail;
use App\Mail\POSubmissionRejectedMail;
use App\Mail\POSubmissionRejectedReminderMail;
use App\Mail\POSubmissionResumedMail;
use App\Mail\SupplierFreightRequestMail;
use App\Mail\SyncSummaryMail;
use Illuminate\Mail\Mailable;
use InvalidArgumentException;

enum EmailType: string implements DisplayableEnum, SluggableEnum
{
    use Displayable;
    use Sluggable;

    case APlusSyncDailyStatus = 'a-plus-sync-daily-status';
    case APlusSyncOverdueAlert = 'a-plus-sync-overdue-alert';
    case AlertAuditVerify = 'alert-audit-verify';
    case BillingHoldAlert = 'billing-hold-alert';
    case BlanketPOLowBalance = 'blanket-po-low-balance';
    case CustomerNeedByDateAlert = 'customer-need-by-date-alert';
    case DropshipShipmentNotification = 'dropship-shipment-notification';
    case DTSOver20kAlert = 'dts-over20k-alert';
    case DTSTrackerAssignment = 'dts-tracker-assignment';
    case ExportCompleted = 'export-completed';
    case FLUCommentSubmitted = 'flu-comment-submitted';
    case InvoiceDiscountError = 'invoice-discount-error';
    case InvoiceIssue = 'invoice-issue';
    case InvoiceTotalMismatch = 'invoice-total-mismatch';
    case OrderAcknowledgementError = 'order-acknowledgement-error';
    case OrderAcknowledgementIssue = 'order-acknowledgement-issue';
    case OrderAcknowledgement = 'order-acknowledgement';
    case OrderInvoice = 'order-invoice';
    case GenericAlert = 'generic-alert';
    case GitlabDeveloperWorkSummary = 'gitlab-developer-work-summary';
    case ItemTypePendingReviewDigest = 'item-type-pending-review-digest';
    case ItemTypeSubmissionDecisionDigest = 'item-type-submission-decision-digest';
    case MonthlyInvoicedStorageReceivablesExport = 'monthly-invoiced-storage-receivables-export';
    case POSubmissionDismissed = 'po-submission-dismissed';
    case POSubmissionIncomplete = 'po-submission-incomplete';
    case POSubmissionIncompleteReminder = 'po-submission-incomplete-reminder';
    case POSubmissionLongHold = 'po-submission-long-hold';
    case POSubmissionOnHold = 'po-submission-on-hold';
    case POSubmissionRejected = 'po-submission-rejected';
    case POSubmissionRejectedReminder = 'po-submission-rejected-reminder';
    case POSubmissionResumed = 'po-submission-resumed';
    case PortalCustomerNotification = 'portal-customer-notification';
    case PortalEmailVerification = 'portal-email-verification';
    case PortalGenericNotification = 'portal-generic-notification';
    case PortalHelpRequest = 'portal-help-request';
    case PortalOrderNotification = 'portal-order-notification';
    case PortalPasswordReset = 'portal-password-reset';
    case PortalWelcome = 'portal-welcome';
    case SupplierFreightRequest = 'supplier-freight-request';
    case SyncSummary = 'sync-summary';

    public const ALERTS = [
        self::APlusSyncOverdueAlert,
        self::BillingHoldAlert,
        self::CustomerNeedByDateAlert,
        self::DTSOver20kAlert,
        self::GenericAlert,
    ];

    public const INVOICES = [
        self::InvoiceDiscountError,
        self::InvoiceIssue,
        self::InvoiceTotalMismatch,
    ];

    public const ORDERS = [
        self::OrderAcknowledgement,
        self::OrderAcknowledgementError,
        self::OrderAcknowledgementIssue,
        self::OrderInvoice,
    ];

    public const PO_SUBMISSION = [
        self::POSubmissionDismissed,
        self::POSubmissionIncomplete,
        self::POSubmissionIncompleteReminder,
        self::POSubmissionLongHold,
        self::POSubmissionOnHold,
        self::POSubmissionRejected,
        self::POSubmissionRejectedReminder,
        self::POSubmissionResumed,
    ];

    public const PORTAL = [
        self::PortalCustomerNotification,
        self::PortalEmailVerification,
        self::PortalGenericNotification,
        self::PortalHelpRequest,
        self::PortalOrderNotification,
        self::PortalPasswordReset,
        self::PortalWelcome,
    ];

    /**
     * Add customized display strings where the internal parse() method doesn't produce the desired output.
     */
    public function display(string $separator = ' '): string
    {
        return match ($this) {
            self::APlusSyncDailyStatus => 'APlus Sync Daily Status',
            self::APlusSyncOverdueAlert => 'APlus Sync Overdue Alert',
            self::DTSOver20kAlert => 'DTS Over 20k Alert',
            default => $this->parse($separator),
        };
    }

    public function permissionCode(): string
    {
        return match ($this) {
            // Preserve the permission slug that existing roles already hold.
            self::DTSOver20kAlert => 'mailable-dts-over20k-alert',
            default => 'mailable-'.$this->slug(),
        };
    }

    /** The family identifies ownership without constraining a mail's Blade view. */
    public function family(): EmailFamily
    {
        return match ($this) {
            self::APlusSyncOverdueAlert, self::AlertAuditVerify, self::BillingHoldAlert,
            self::BlanketPOLowBalance, self::CustomerNeedByDateAlert, self::DTSOver20kAlert,
            self::DTSTrackerAssignment, self::GenericAlert => EmailFamily::Alert,

            self::InvoiceDiscountError, self::InvoiceIssue, self::InvoiceTotalMismatch,
            self::OrderAcknowledgement, self::OrderAcknowledgementError,
            self::OrderAcknowledgementIssue, self::OrderInvoice => EmailFamily::FormRivers,

            self::ItemTypePendingReviewDigest, self::ItemTypeSubmissionDecisionDigest => EmailFamily::ItemType,

            self::POSubmissionDismissed, self::POSubmissionIncomplete,
            self::POSubmissionIncompleteReminder, self::POSubmissionLongHold,
            self::POSubmissionOnHold, self::POSubmissionRejected,
            self::POSubmissionRejectedReminder, self::POSubmissionResumed => EmailFamily::POSubmission,

            self::PortalCustomerNotification, self::PortalEmailVerification,
            self::PortalGenericNotification, self::PortalHelpRequest,
            self::PortalOrderNotification, self::PortalPasswordReset,
            self::PortalWelcome => EmailFamily::Portal,

            self::APlusSyncDailyStatus, self::DropshipShipmentNotification,
            self::ExportCompleted, self::FLUCommentSubmitted,
            self::GitlabDeveloperWorkSummary, self::MonthlyInvoicedStorageReceivablesExport,
            self::SupplierFreightRequest, self::SyncSummary => EmailFamily::General,
        };
    }

    /**
     * @return class-string<Mailable>
     *
     * @deprecated To be removed when all App\Mail classes have been safely replaced with an EmailType.
     */
    public function mailableClass(): string
    {
        $class = array_search($this, self::MAILABLE_CLASS_REPLACEMENTS, true);

        if ($class === false) {
            throw new InvalidArgumentException("Unmapped email type: {$this->name} has no Mail class");
        }

        return $class;
    }

    /**
     * @deprecated To be removed when all App\Mail classes have been safely replaced with an EmailType.
     */
    public static function fromMailableClass(string $class): ?self
    {
        return self::MAILABLE_CLASS_REPLACEMENTS[$class] ?? null;
    }

    /**
     * @deprecated To be removed when all App\Mail classes have been safely replaced with an EmailType.
     */
    public static function mailableClassReplacements(): array
    {
        return array_map(fn (self $case) => $case->slug(), self::MAILABLE_CLASS_REPLACEMENTS);
    }

    /**
     * @deprecated To be removed when all App\Mail classes have been safely replaced with an EmailType.
     */
    private const MAILABLE_CLASS_REPLACEMENTS = [
        APlusSyncDailyStatusMail::class => self::APlusSyncDailyStatus,
        APlusSyncOverdueAlertMail::class => self::APlusSyncOverdueAlert,
        AlertAuditVerifyMail::class => self::AlertAuditVerify,
        BillingHoldAlertMail::class => self::BillingHoldAlert,
        BlanketPoLowBalanceMail::class => self::BlanketPOLowBalance,
        CustomerNeedByDateAlertMail::class => self::CustomerNeedByDateAlert,
        DropshipShipmentNotificationMail::class => self::DropshipShipmentNotification,
        DtsOver20kAlertMail::class => self::DTSOver20kAlert,
        DtsTrackerAssignmentMail::class => self::DTSTrackerAssignment,
        ExportCompletedMail::class => self::ExportCompleted,
        FluCommentSubmittedMail::class => self::FLUCommentSubmitted,
        InvoiceDiscountErrorMail::class => self::InvoiceDiscountError,
        InvoiceIssueMail::class => self::InvoiceIssue,
        InvoiceTotalMismatchMail::class => self::InvoiceTotalMismatch,
        OrderAcknowledgementErrorMail::class => self::OrderAcknowledgementError,
        OrderAcknowledgementIssueMail::class => self::OrderAcknowledgementIssue,
        OrderAcknowledgementMail::class => self::OrderAcknowledgement,
        OrderInvoiceMail::class => self::OrderInvoice,
        GenericAlertMail::class => self::GenericAlert,
        GitLabDeveloperWorkSummaryMail::class => self::GitlabDeveloperWorkSummary,
        ItemTypePendingReviewDigestMail::class => self::ItemTypePendingReviewDigest,
        ItemTypeSubmissionDecisionDigestMail::class => self::ItemTypeSubmissionDecisionDigest,
        MonthlyInvoicedStorageReceivablesExportMail::class => self::MonthlyInvoicedStorageReceivablesExport,
        POSubmissionDismissedMail::class => self::POSubmissionDismissed,
        POSubmissionIncompleteMail::class => self::POSubmissionIncomplete,
        POSubmissionIncompleteReminderMail::class => self::POSubmissionIncompleteReminder,
        POSubmissionLongHoldMail::class => self::POSubmissionLongHold,
        POSubmissionOnHoldMail::class => self::POSubmissionOnHold,
        POSubmissionRejectedMail::class => self::POSubmissionRejected,
        POSubmissionRejectedReminderMail::class => self::POSubmissionRejectedReminder,
        POSubmissionResumedMail::class => self::POSubmissionResumed,
        CustomerNotificationMail::class => self::PortalCustomerNotification,
        EmailVerificationMail::class => self::PortalEmailVerification,
        GenericNotificationMail::class => self::PortalGenericNotification,
        HelpRequestMail::class => self::PortalHelpRequest,
        OrderNotificationMail::class => self::PortalOrderNotification,
        PasswordResetMail::class => self::PortalPasswordReset,
        WelcomeMail::class => self::PortalWelcome,
        SupplierFreightRequestMail::class => self::SupplierFreightRequest,
        SyncSummaryMail::class => self::SyncSummary,
    ];
}
