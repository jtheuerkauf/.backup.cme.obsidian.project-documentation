<?php
declare(strict_types=1);

namespace App\Enums\Email;

enum EmailFamily: string
{
    case Alert = 'alert';
    case FormRivers = 'form-rivers';
    case ItemType = 'item-type';
    case POSubmission = 'po-submission';
    case Portal = 'portal';
    case General = 'general';

    public static function fromMailableClass(string $class): ?self
    {
        return EmailType::fromMailableClass($class)?->family();
    }
}
