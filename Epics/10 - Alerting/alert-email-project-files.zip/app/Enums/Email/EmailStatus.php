<?php
declare(strict_types=1);

namespace App\Enums\Email;

use App\Enums\Traits\BaseEnum;
use App\Models\Email;
use DateTimeInterface;

enum EmailStatus: string
{
    use BaseEnum;

    case Queued = 'queued';
    case Processing = 'processing';
    case Sent = 'sent';
    case Failed = 'failed';

    private const FINALIZED = [self::Failed, self::Sent];

    public function label(): string
    {
        return ucfirst($this->value);
    }

    public function isFinalized(): bool
    {
        return in_array($this, self::FINALIZED, true);
    }

    public function displayLabel(int $attempts = 0): string
    {
        return $this === self::Processing
            ? sprintf('%s (%d tries)', $this->label(), $attempts)
            : $this->label();
    }

    public function foregroundColor(int $attempts = 0): string
    {
        return '#ffffff';
    }

    public function backgroundColor(int $attempts = 0): string
    {
        return match ($this) {
            self::Queued => '#4b5563',
            self::Processing => $attempts > 2 ? '#c2410c' : '#a16207',
            self::Sent => '#15803d',
            self::Failed => '#b91c1c',
        };
    }

    public function style(int $attempts = 0): string
    {
        return sprintf(
            'color: %s; background-color: %s;',
            $this->foregroundColor($attempts),
            $this->backgroundColor($attempts),
        );
    }

    public function latestUpdate(Email $email): ?DateTimeInterface
    {
        return match ($this) {
            self::Queued => $email->queued_at,
            self::Processing => $email->last_attempted_at,
            self::Sent => $email->sent_at,
            self::Failed => $email->last_attempted_at ?? $email->queued_at,
        };
    }
}
