<?php
declare(strict_types=1);

namespace App\Enums\Alerts;

use App\Enums\Interfaces\DisplayableEnum;
use App\Enums\Interfaces\SluggableEnum;
use App\Enums\Traits\Displayable;
use App\Enums\Traits\Sluggable;

/**
 * @extends \BackedEnum
 */
enum AlertType: string implements SluggableEnum, DisplayableEnum
{
    use Displayable {
        display as traitDisplay;
    }
    use Sluggable;

    case DtsOver20k = 'dts-over-20k';

    public function slug(string $separator = '-'): string
    {
        return match ($this) {
            self::DtsOver20k => 'dts-over-20k',
        };
    }

    public function display(): string
    {
        return match ($this) {
            self::DtsOver20k => 'DTS Over 20k',
            default => $this->traitDisplay(),
        };
    }
}
