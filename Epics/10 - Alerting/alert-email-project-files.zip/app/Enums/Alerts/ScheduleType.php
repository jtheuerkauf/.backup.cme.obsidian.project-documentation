<?php

namespace App\Enums\Alerts;

enum ScheduleType: string
{
    case Cron = 'cron';
}
