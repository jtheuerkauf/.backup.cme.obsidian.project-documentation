<?php
declare(strict_types=1);

namespace App\Queries\Dashboards;

use App\Enums\Email\EmailType;
use App\Enums\Email\EmailStatus;
use App\Models\Email;
use App\Queries\BaseQuery;
use App\Traits\Normalizers\EmailTextNormalizer;
use Carbon\CarbonImmutable;
use Illuminate\Database\Eloquent\Builder;
use SortDirection;

final class EmailSearchQuery extends BaseQuery
{
    use EmailTextNormalizer;

    protected function baseQuery(): Builder|Email
    {
        return Email::query();
    }

    /**
     * @param  list<EmailType>  $allowedMailables
     */
    public function searchQuery(
        array $allowedMailables,
        ?EmailType $mailable,
        string $search,
        string $address,
        ?CarbonImmutable $dateFrom,
        ?CarbonImmutable $dateTo,
    ): Builder {
        $search = $this->normalizeSearch($search);

        return $this->query
            ->with(['generatedBy:id,name,email', 'relatedRecord'])
            ->whereIn('mailable', $allowedMailables)
            ->when(
                (bool) $mailable,
                fn (Builder $query) => $query->where('mailable', $mailable),
            )
            ->when(
                (bool) $search,
                function (Builder $query) use ($search): void {
                    $like = $this->searchToLike($search);
                    $query->where(
                        function (Builder $searchQuery) use ($like): void {
                            $searchQuery
                                ->whereLike('body_search', $like)
                                ->orWhereLike('subject_search', $like);
                            $this->orWhereJsonSearch($searchQuery, 'attachments', $like, '$[*].name');
                        },
                    );
                },
            )
            ->when(
                (bool) $address,
                function (Builder $query) use ($address): void {
                    $like = '%'.addcslashes($address, '%_\\').'%';
                    $query->where(
                        function (Builder $addressQuery) use ($like): void {
                            foreach (['to', 'cc', 'bcc', 'reply_to'] as $field) {
                                $this->orWhereJsonSearch($addressQuery, $field, $like, '$[*]');
                            }

                            $addressQuery
                                ->orWhereLike('from_email', $like)
                                ->orWhereHas(
                                    'generatedBy',
                                    fn (Builder $userQuery) => $userQuery
                                        ->whereLike('email', $like)
                                        ->orWhereLike('name', $like),
                                );
                        },
                    );
                },
            )
            ->when(
                (bool) $dateFrom,
                fn (Builder $query) => $query->whereRaw(
                    $this->latestUpdateExpression().' >= ?',
                    [$dateFrom->startOfDay()],
                ),
            )
            ->when(
                (bool) $dateTo,
                fn (Builder $query) => $query->whereRaw(
                    $this->latestUpdateExpression().' <= ?',
                    [$dateTo->endOfDay()],
                ),
            );
    }

    public function applyStatus(?EmailStatus $status): self
    {
        if ($status === null) {
            return $this;
        }

        $this->query->where('status', $status);

        return $this;
    }

    public function applyEmailSorting(string $sortBy, SortDirection $direction): self
    {
        $dir = $direction === SortDirection::Ascending ? 'asc' : 'desc';

        match ($sortBy) {
            'latest_update' => $this->query->orderByRaw($this->latestUpdateExpression() . ' ' . $dir),
            'from' => $this->query->orderBy('from_email', $dir),
            'subject' => $this->query->orderBy('subject', $dir),
        };

        return $this;
    }

    public function normalizeSortBy(?string $sortBy): string
    {
        return array_first(array_intersect([$sortBy, 'latest_update'], ['from', 'latest_update', 'subject']));
    }

    private function latestUpdateExpression(): string
    {
        return <<<'SQL'
            CASE
                WHEN sent_at IS NOT NULL
                THEN
                    sent_at
                WHEN COALESCE(error_code, error_message) IS NOT NULL OR status = 'failed'
                THEN
                    last_attempted_at
                WHEN last_attempted_at IS NOT NULL
                THEN
                    last_attempted_at
                ELSE queued_at
            END
            SQL;
    }

    private function normalizeSearch(string $search): string
    {
        $search = preg_replace('/[^\p{L}\p{N}*]+/u', ' ', $search) ?? $search;
        $search = preg_replace('/\s+/u', ' ', $search) ?? $search;

        return trim($search);
    }

    private function searchToLike(string $search): string
    {
        $search = trim($search, '*');
        $search = addcslashes($search, '%_\\');
        $search = preg_replace('/\*+/', '%', $search) ?? $search;

        return '%'.$search.'%';
    }

    private function orWhereJsonSearch(Builder $query, string $column, string $like, string $path): void
    {
        if ($query->getConnection()->getDriverName() !== 'mysql') {
            $query->orWhereLike($column, $like);

            return;
        }

        $query->orWhereRaw(
            "JSON_SEARCH(`{$column}`, 'one', ?, NULL, ?) IS NOT NULL",
            [$like, $path],
        );
    }
}
