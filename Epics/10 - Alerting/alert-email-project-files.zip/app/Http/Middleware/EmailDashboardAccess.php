<?php

namespace App\Http\Middleware;

use App\Services\Email\EmailAccessService;
use Closure;
use Illuminate\Http\Request;
use Symfony\Component\HttpFoundation\Response;

final class EmailDashboardAccess
{
    public function __construct(
        private readonly EmailAccessService $access,
    ) {}

    public function handle(Request $request, Closure $next): Response
    {
        $user = $request->user();
        abort_unless((bool) $user, 403);
        abort_if($this->access->allowedMailables($user) === [], 403);

        return $next($request);
    }
}
