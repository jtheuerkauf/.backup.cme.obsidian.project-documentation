<?php
declare(strict_types=1);

namespace App\Http\Middleware;

use App\Models\Email;
use App\Services\Email\EmailAccessService;
use Closure;
use Illuminate\Http\Request;
use Symfony\Component\HttpFoundation\Response;

final class EmailMessageAccess
{
    public function __construct(
        private readonly EmailAccessService $access,
    ) {}

    public function handle(Request $request, Closure $next): Response
    {
        $email = $request->route('email');

        abort_unless($email instanceof Email, 404);
        abort_unless($this->access->canView($request->user(), $email->mailable), 403);

        return $next($request);
    }
}
