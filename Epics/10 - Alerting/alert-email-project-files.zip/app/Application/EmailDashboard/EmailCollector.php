<?php
declare(strict_types=1);

namespace App\Application\EmailDashboard;

use App\Enums\Email\EmailStatus;
use App\Models\User;
use App\Queries\Dashboards\EmailSearchQuery;
use App\Services\Email\EmailAccessService;
use SortDirection;

final readonly class EmailCollector
{
    public function __construct(
        public EmailAccessService $access,
        public EmailSearchQuery $search,
    ) {}

    public function execute(User $user, Filters $filters): ViewData
    {
        $allowedMailables = $this->access->allowedMailables($user);
        $sortBy = $this->search->normalizeSortBy($filters->sortBy);
        $direction = $filters->direction;
        $sortColumns = [
            'subject' => new SortColumn('subject', SortDirection::Ascending, $sortBy, $direction),
            'from' => new SortColumn('from', SortDirection::Ascending, $sortBy, $direction),
            'latest_update' => new SortColumn('latest_update', SortDirection::Descending, $sortBy, $direction),
        ];

        $this->search->searchQuery(
            allowedMailables: $allowedMailables,
            mailable: $filters->mailable,
            search: $filters->search,
            address: $filters->address,
            dateFrom: $filters->dateFrom,
            dateTo: $filters->dateTo,
        );

        $counts = ['all' => $this->search->clone()->count()];
        foreach (EmailStatus::cases() as $status) {
            $counts[$status->value] = $this->search
                ->clone()
                ->applyStatus($status)
                ->count();
        }

        $emails = $this->search
            ->applyStatus($filters->status)
            ->applyEmailSorting($sortBy, $direction)
            ->paginate($filters->perPage)
            ->withQueryString();

        return new ViewData(
            emails: $emails,
            counts: $counts,
            mailable: $filters->mailable,
            status: $filters->status,
            search: $filters->search,
            address: $filters->address,
            dateFrom: $filters->dateFrom?->format('Y-m-d'),
            dateTo: $filters->dateTo?->format('Y-m-d'),
            statuses: EmailStatus::cases(),
            sortBy: $sortBy,
            direction: $direction,
            sortColumns: $sortColumns,
            allowedMailables: $allowedMailables,
        );
    }
}
