<?php

namespace App\Listeners\Email;

use App\Enums\Email\EmailStatus;
use App\Models\Alerts\AlertRun;
use App\Models\Email;
use App\Services\Alerts\AlertMessageSnapshot;
use Illuminate\Mail\Events\MessageSending;
use Illuminate\Support\Facades\DB;

class MarkIntentEmailSending
{
    public function handle(MessageSending $event): void
    {
        $intentId = $this->resolveIntentId($event->message);

        if ($intentId === null) {
            return;
        }

        $messageIdHeader = $event->message->getHeaders()->get('Message-ID');
        $messageId = $messageIdHeader ? trim((string) $messageIdHeader->getBodyAsString()) : null;

        $updates = [
            'status' => EmailStatus::Processing,
            'last_attempted_at' => now(),
            'updated_at' => now(),
        ];

        if ($messageId !== '') {
            $updates['message_id'] = $messageId;
        }

        Email::query()
            ->whereKey($intentId)
            ->update(array_merge($updates, [
                'attempts' => DB::raw('attempts + 1'),
            ]));
        $intent = Email::query()->find($intentId);
        if ($intent?->related_type === AlertRun::class) {
            app(AlertMessageSnapshot::class)->record($intent);
        }
    }

    private function resolveIntentId(\Symfony\Component\Mime\Email $message): ?int
    {
        $intentIdHeader = $message->getHeaders()->get('X-Email-Intent-Id');

        if (! $intentIdHeader) {
            return null;
        }

        $intentId = (int) trim((string) $intentIdHeader->getBodyAsString());

        return $intentId > 0 ? $intentId : null;
    }
}
