<?php

namespace App\Listeners\Email;

use App\Models\Alerts\AlertRun;
use App\Models\Email;
use App\Services\Alerts\AlertMessageSnapshot;
use Illuminate\Mail\Events\MessageSent;

class MarkIntentEmailSent
{
    public function handle(MessageSent $event): void
    {
        $intentId = $this->resolveIntentId($event->message);

        if ($intentId === null) {
            return;
        }

        $messageIdHeader = $event->message->getHeaders()->get('Message-ID');
        $messageId = $messageIdHeader ? trim((string) $messageIdHeader->getBodyAsString()) : null;

        $updates = [
            'status' => 'sent',
            'sent_at' => now(),
            'error_code' => null,
            'error_message' => null,
        ];

        if ($messageId !== '') {
            $updates['message_id'] = $messageId;
        }

        Email::query()
            ->whereKey($intentId)
            ->update($updates);
        $intent = Email::query()->find($intentId);
        if ($intent?->related_type === AlertRun::class) {
            app(AlertMessageSnapshot::class)->record($intent);
        }
    }

    private function resolveIntentId(\Symfony\Component\Mime\Email $message): ?int
    {
        $intentIdHeader = $message->getHeaders()->get('X-Email-Intent-Id');

        if (! $intentIdHeader) {
            return null;
        }

        $intentId = (int) trim((string) $intentIdHeader->getBodyAsString());

        return $intentId > 0 ? $intentId : null;
    }
}
