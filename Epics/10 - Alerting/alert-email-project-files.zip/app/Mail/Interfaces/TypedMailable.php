<?php
declare(strict_types=1);

namespace App\Mail\Interfaces;

use App\Enums\Email\EmailType;

interface TypedMailable
{
    public function emailType(): EmailType;

    public function relatedType(): ?string;

    public function relatedId(): ?int;
}
