<?php
declare(strict_types=1);

namespace App\Mail\Builders\Alert;

use App\DTO\Email\EmailBuildRequest;
use App\Enums\Email\EmailFamily;
use App\Mail\Builders\MailBuilder;
use Illuminate\Mail\Mailables\Address;

final class AlertMailBuilder extends MailBuilder
{
    public function family(): EmailFamily
    {
        return EmailFamily::Alert;
    }

    protected function replyTo(EmailBuildRequest $request): Address
    {
        return new Address('devrequests@cmecorp.com', 'Dev Requests');
    }
}
