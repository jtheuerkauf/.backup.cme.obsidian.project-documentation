<?php
declare(strict_types=1);

namespace App\Mail\Builders;

use App\DTO\Email\EmailBuildRequest;
use App\Enums\Email\EmailFamily;
use App\Mail\BuiltMail;
use Illuminate\Mail\Mailables\Address;
use InvalidArgumentException;

abstract class MailBuilder
{
    abstract public function family(): EmailFamily;

    final public function build(EmailBuildRequest $request): BuiltMail
    {
        if ($request->recipients->count() === 0) {
            throw new InvalidArgumentException('A mail build request requires recipients.');
        }

        $mail = new BuiltMail($request, $this->replyTo($request));
        $this->address($mail, $request);

        return $mail;
    }

    protected function address(BuiltMail $mail, EmailBuildRequest $request): void
    {
        foreach ($request->recipients as $recipient) {
            $mail->to($recipient->email->address, $recipient->name);
        }
    }

    protected function replyTo(EmailBuildRequest $request): ?Address
    {
        return null;
    }
}
