<?php

namespace App\Mail\Transport;

use App\DTO\Email\EmailAttachmentDTO;
use App\Enums\Email\EmailType;
use App\Enums\Email\EmailStatus;
use App\Jobs\Email\EmailSendFailedEscalationJob;
use App\Models\Email;
use App\Services\API\Graph\GraphApiClient;
use Illuminate\Support\Facades\Log;
use Symfony\Component\Mailer\SentMessage;
use Symfony\Component\Mailer\Transport\AbstractTransport;
use Symfony\Component\Mime\Email as SymfonyEmail;
use Symfony\Component\Mime\MessageConverter;
use Throwable;

class MicrosoftGraphTransport extends AbstractTransport
{
    public function __construct(
        protected GraphApiClient $graphClient,
    ) {
        parent::__construct();
    }

    protected function doSend(SentMessage $message): void
    {
        // Enforce queued sending by logging a warning if called synchronously
        // Standard Laravel queued mailables run via the console (queue:work)
        if (!app()->runningInConsole() && !app()->runningUnitTests()) {
            Log::warning(
                'Synchronous email sending detected via Microsoft Graph. Call sites should use Mail::to()->queue() instead.',
            );
        }

        $email = MessageConverter::toEmail($message->getOriginalMessage());

        $from = $this->resolveFrom($email);
        $to = $this->asEmailArray($email->getTo());
        $cc = $this->asEmailArray($email->getCc());
        $bcc = $this->asEmailArray($email->getBcc());
        $replyTo = $this->asEmailArray($email->getReplyTo());
        $subject = $email->getSubject() ?: '(no subject)';

        $htmlBody = $email->getHtmlBody();
        $textBody = $email->getTextBody();

        $attachments = $this->getAttachments($email);

        $messageIdHeader = $email->getHeaders()->get('Message-ID');
        $messageId = $messageIdHeader?->getBodyAsString();
        $emailTypeHeader = $email->getHeaders()->get('X-Email-Type');
        $emailType = $emailTypeHeader ? trim($emailTypeHeader->getBodyAsString()) : 'system.generic';
        $intentIdHeader = $email->getHeaders()->get('X-Email-Intent-Id');
        $generatedById = $intentIdHeader ? (int) trim($intentIdHeader->getBodyAsString()) : null;
        $mailableClass = EmailType::tryFrom($this->resolveTextHeader($email, 'X-Email-Mailable'));
        $relatedType = $this->resolveTextHeader($email, 'X-Email-Related-Type');
        $relatedId = $this->resolveNumericHeader($email, 'X-Email-Related-Id');

        // Try to find if we've already attempted to send this message
        $emailRecord = null;

        if ($generatedById) {
            $intentRecord = Email::query()->find($generatedById);

            if ($intentRecord) {
                if (!$intentRecord->email_type && $emailType !== '') {
                    $intentRecord->email_type = $emailType;
                }

                if (!$intentRecord->message_id && $messageId) {
                    $intentRecord->message_id = $messageId;
                }

                if (!$intentRecord->mailable && $mailableClass) {
                    $intentRecord->mailable = $mailableClass;
                }

                if (!$intentRecord->related_type && $relatedType) {
                    $intentRecord->related_type = $relatedType;
                }

                if (!$intentRecord->related_id && $relatedId) {
                    $intentRecord->related_id = $relatedId;
                }

                if ($intentRecord->isDirty()) {
                    $intentRecord->save();
                }

                $emailRecord = $intentRecord;
            } else {
                Log::warning(
                    'Email intent ID header provided but no matching email row found; falling back to transport-created record',
                    [
                        'generated_by_id' => $generatedById,
                        'subject' => $subject,
                    ],
                );
            }
        }

        $existingRecord = null;
        if (!$emailRecord && $messageId) {
            $existingRecord = Email::where('message_id', $messageId)
                ->where('status', EmailStatus::Failed)
                ->latest()
                ->first();
        }

        if (!$emailRecord) {
            if ($existingRecord) {
                $emailRecord = $existingRecord;
                $emailRecord->update(
                    [
                        'status' => EmailStatus::Processing,
                        'attempts' => $emailRecord->attempts + 1,
                        'last_attempted_at' => now(),
                    ],
                );
            } else {
                $emailRecord = Email::createWithBody(
                    [
                        'provider' => 'msgraph',
                        'email_type' => $emailType !== '' ? $emailType : 'system.generic',
                        'mailable' => $mailableClass,
                        'related_type' => $relatedType,
                        'related_id' => $relatedId,
                        'generated_by_id' => null,
                        'model_action_log_id' => null,
                        'from_email' => $from,
                        'to' => $to,
                        'cc' => $cc,
                        'bcc' => $bcc,
                        'reply_to' => $replyTo,
                        'subject' => $subject,
                        'body_html' => $htmlBody,
                        'attachments' => $attachments['metadata'],
                        'message_id' => $messageId,
                        'status' => EmailStatus::Processing,
                        'attempts' => 1,
                        'queued_at' => now(),
                        'last_attempted_at' => now(),
                    ],
                );
            }
        }

        Log::info(
            "Sending email via Microsoft Graph",
            [
                'from' => $from,
                'subject' => $subject,
                'to_count' => count($to),
                'cc_count' => count($cc),
                'bcc_count' => count($bcc),
            ],
        );

        try {
            $this->graphClient->sendMail(
                fromMailbox: $from,
                to: $to,
                subject: $subject,
                body: $htmlBody ?: $textBody ?: '',
                options: array_filter(
                    [
                        'cc' => $cc,
                        'bcc' => $bcc,
                        'replyTo' => $replyTo,
                        'bodyType' => $htmlBody ? 'HTML' : 'Text',
                        'attachments' => $attachments['payload'],
                    ],
                ),
            );

            $emailRecord->update(
                [
                    'status' => EmailStatus::Sent,
                    'sent_at' => now(),
                ],
            );
        } catch (Throwable $e) {
            $emailRecord->update(
                [
                    'status' => EmailStatus::Failed,
                    'error_code' => method_exists($e, 'getCode') ? $e->getCode() : null,
                    'error_message' => $e->getMessage(),
                ],
            );

            Log::error(
                "Microsoft Graph mail delivery failed",
                [
                    'email_id' => $emailRecord->id,
                    'from' => $from,
                    'subject' => $subject,
                    'to_count' => count($to),
                    'error' => $e->getMessage(),
                ],
            );

            $this->handleEscalation($emailRecord);

            throw $e;
        }
    }

    protected function resolveFrom(SymfonyEmail $email): string
    {
        $from = $email->getFrom();

        if (!empty($from)) {
            return $from[0]->getAddress();
        }

        return config('services.msgraph.from_mailbox') ?? config('mail.from.address');
    }

    protected function asEmailArray(array $addresses): array
    {
        return array_map(fn($address) => $address->getAddress(), $addresses);
    }

    /**
     * @param \Symfony\Component\Mime\Email $email
     *
     * @return array{
     *     metadata: EmailAttachmentDTO[],
     *     payload: array{
     *         name: string,
     *         contentType: string,
     *         contentBytes: string,
     *         contentId: string|null,
     *         isInline: bool,
     *     }[],
     * }
     */
    protected function getAttachments(SymfonyEmail $email): array
    {
        $metadata = [];
        $payload = [];

        foreach ($email->getAttachments() as $attachment) {
            $headers = $attachment->getPreparedHeaders();

            $name = $headers->getHeaderParameter('Content-Disposition', 'filename')
                ?: $headers->getHeaderParameter('Content-Type', 'name')
                    ?: 'attachment';

            $contentType = $attachment->getMediaType() . '/' . $attachment->getMediaSubtype();

            $contentId = $headers->getHeaderBody('Content-ID');
            $disposition = $headers->getHeaderBody('Content-Disposition');
            $isInline = $disposition && str_contains($disposition, 'inline');

            $body = $attachment->getBody();

            // ✅ Symfony may give you a stream resource. Gmail will fail if you base64_encode() the resource.
            if (is_resource($body)) {
                rewind($body);
                $content = stream_get_contents($body);
            } else {
                $content = $body;
            }

            $metadata[] = EmailAttachmentDTO::fromArray(
                [
                'name' => $name,
                'contentType' => $contentType,
                'size' => strlen($content),
                'contentId' => $contentId,
                'isInline' => $isInline,
                ]
            );

            $payload[] = [
                'name' => $name,
                'contentType' => $contentType,
                'contentBytes' => base64_encode($content),
                'contentId' => $contentId,
                'isInline' => $isInline,
            ];
        }

        return [
            'metadata' => $metadata,
            'payload' => $payload,
        ];
    }

    protected function handleEscalation(Email $email): void
    {
        if ($email->attempts >= 3) {
            Log::critical(
                "ESCALATION: Email delivery failed after multiple attempts via Microsoft Graph",
                [
                    'email_id' => $email->id,
                    'subject' => $email->subject,
                    'to' => $email->to,
                    'attempts' => $email->attempts,
                ],
            );

            EmailSendFailedEscalationJob::dispatch($email);
        }
    }

    private function resolveTextHeader(SymfonyEmail $email, string $name): ?string
    {
        $header = $email->getHeaders()->get($name);

        if (!$header) {
            return null;
        }

        $value = trim($header->getBodyAsString());

        return $value === '' ? null : $value;
    }

    private function resolveNumericHeader(SymfonyEmail $email, string $name): ?int
    {
        $value = $this->resolveTextHeader($email, $name);

        if ($value === null || !ctype_digit($value)) {
            return null;
        }

        $normalized = (int)$value;

        return $normalized > 0 ? $normalized : null;
    }

    public function __toString(): string
    {
        return 'msgraph';
    }
}
