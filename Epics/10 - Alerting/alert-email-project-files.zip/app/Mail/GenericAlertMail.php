<?php
declare(strict_types = 1);

namespace App\Mail;

use Illuminate\Bus\Queueable;
use Illuminate\Contracts\Queue\ShouldQueue;
use Illuminate\Mail\Mailable;
use Illuminate\Mail\Mailables\Address;
use Illuminate\Mail\Mailables\Content;
use Illuminate\Mail\Mailables\Envelope;
use Illuminate\Queue\SerializesModels;

/**
 * A reusable alert envelope. Alert-specific jobs provide a subject, a Blade
 * view, and the data required by that view rather than requiring a mailable
 * class for each alert.
 *
 * @todo This needs more abstraction. It should probably be as close to an abstract class as possible.
 *       Keep core functionality here, move shared "custom" features to traits.
 */
class GenericAlertMail extends Mailable implements ShouldQueue
{
    use Queueable;
    use SerializesModels;

    /**
     * @param array<string, mixed> $alertData
     */
    public function __construct(
        public string $subjectLine,
        public string $viewName,
        public array  $alertData = [],
    ) {}

    public function envelope(): Envelope
    {
        return new Envelope(
            replyTo: [new Address('devrequests@cmecorp.com', 'Dev Requests')],
            subject: $this->subjectLine,
        );
    }

    public function content(): Content
    {
        return new Content(view: $this->viewName, with: $this->alertData);
    }

    /**
     * TODO: Email + FormRiversFile restricts messages to 1 attachment.
     *       We need to revisit this structure to allow for multiple attachments.
     *
     * @see \App\Models\Email
     */
    public function attachments(): array
    {
        return [];
    }
}
