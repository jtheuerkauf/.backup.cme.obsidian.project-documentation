<?php
declare(strict_types=1);

namespace App\Mail;

use App\DTO\Email\EmailBuildRequest;
use App\Enums\Email\EmailStatus;
use App\Enums\Email\EmailType;
use App\Mail\Interfaces\TypedMailable;
use App\Models\Alerts\AlertRun;
use App\Models\Email;
use App\Services\Alerts\AlertMessageSnapshot;
use Illuminate\Bus\Queueable;
use Illuminate\Contracts\Queue\ShouldQueue;
use Illuminate\Mail\Mailable;
use Illuminate\Mail\Mailables\Address;
use Illuminate\Mail\Mailables\Content;
use Illuminate\Mail\Mailables\Envelope;
use Illuminate\Mail\Mailables\Headers;
use Illuminate\Queue\SerializesModels;
use Throwable;

/** A message assembled from a resolved request; it contains no alert queries or routing rules. */
final class BuiltMail extends Mailable implements ShouldQueue, TypedMailable
{
    use Queueable, SerializesModels;

    private ?int $intentEmailId = null;

    public function __construct(
        private readonly EmailBuildRequest $request,
        private readonly ?Address $replyToAddress = null,
    ) {}

    public function emailType(): EmailType
    {
        return $this->request->type;
    }

    public function relatedType(): ?string
    {
        return $this->request->relatedType;
    }

    public function relatedId(): ?int
    {
        return $this->request->relatedId;
    }

    public function boundaryKey(): string
    {
        return $this->request->boundaryKey;
    }

    public function withIntent(int $emailId): self
    {
        $this->intentEmailId = $emailId;

        return $this;
    }

    public function envelope(): Envelope
    {
        return new Envelope(
            subject: $this->request->subject,
            replyTo: $this->replyToAddress ? [$this->replyToAddress] : [],
        );
    }

    public function content(): Content
    {
        return new Content(view: $this->request->template, with: $this->request->viewData);
    }

    public function headers(): Headers
    {
        $text = [
            'X-Email-Mailable' => $this->request->type->value,
            'X-Email-Type' => $this->request->type->value,
        ];
        if ($this->request->relatedType !== null) {
            $text['X-Email-Related-Type'] = $this->request->relatedType;
        }
        if ($this->request->relatedId !== null) {
            $text['X-Email-Related-Id'] = (string) $this->request->relatedId;
        }
        if ($this->intentEmailId !== null) {
            $text['X-Email-Intent-Id'] = (string) $this->intentEmailId;
        }

        return new Headers(text: $text);
    }

    public function failed(Throwable $exception): void
    {
        if ($this->intentEmailId === null) {
            return;
        }

        $email = Email::query()->find($this->intentEmailId);
        if ($email === null) {
            return;
        }
        $email->update(
            [
                'status' => EmailStatus::Failed,
                'error_code' => (string) $exception->getCode(),
                'error_message' => $exception->getMessage(),
            ],
        );
        if ($email->related_type === AlertRun::class) {
            app(AlertMessageSnapshot::class)->record($email);
        }
    }
}
