<?php
declare(strict_types=1);

namespace App\Mail;

use App\Enums\Alerts\AlertType;
use App\Services\Alerts\AlertsRegistry;
use Carbon\CarbonImmutable;
use Illuminate\Support\Collection;

/**
 * The concrete queued mailable and persisted-intent identity for the DTS
 * over-$20K alert.
 */
final class DtsOver20kAlertMail extends GenericAlertMail
{
    /** @param Collection<int, array<string, mixed>> $rows */
    public function __construct(Collection $rows, CarbonImmutable $generatedAt, ?string $subjectLine = null)
    {
        parent::__construct(
            $subjectLine ?? app(AlertsRegistry::class)->mailSubject(AlertType::DtsOver20k),
            'emails.alerts.dts-over-20k',
            [
                'rows' => $rows,
                'generatedAt' => $generatedAt,
            ],
        );
    }
}
