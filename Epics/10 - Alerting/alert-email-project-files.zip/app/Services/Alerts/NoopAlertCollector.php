<?php

namespace App\Services\Alerts;

use App\DTO\Alerts\AlertDataConfig;
use App\DTO\Alerts\AlertPreview;
use App\Models\Alerts\Alert;
use App\Models\Alerts\AlertRun;
use App\Services\Alerts\Interfaces\AlertCollector;

final class NoopAlertCollector implements AlertCollector
{
    private ?array $result = null;

    public function validate(AlertDataConfig $dataConfig): void {}

    public function preview(Alert $alert, AlertDataConfig $dataConfig): AlertPreview
    {
        return new AlertPreview();
    }

    public function collect(Alert $alert, AlertRun $run, AlertDataConfig $dataConfig): void
    {
        $this->result = ['status' => \App\Enums\ProcessStatus::Empty, 'context' => []];
    }

    public function result(): array
    {
        return $this->result ?? throw new \LogicException('Collect before reading the result.');
    }
}
