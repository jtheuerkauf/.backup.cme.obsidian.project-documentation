<?php
declare(strict_types=1);

namespace App\Services\Alerts;

use App\DTO\Alerts\AlertDataConfig;
use App\Models\Alerts\AlertRun;
use App\Services\Alerts\Interfaces\AlertCollector;
use App\Services\Alerts\Interfaces\AlertExecutionStrategy;
use App\Services\Alerts\Interfaces\AlertRunProcessor;

final readonly class StandardAlertExecutionStrategy implements AlertExecutionStrategy
{
    /**
     * @param array<string, mixed> $context
     *
     * @return array{result: array<string, mixed>, processor_context: array<string, mixed>}
     */
    public function execute(
        AlertCollector $collector,
        AlertRun $run,
        AlertDataConfig $dataConfig,
        array $context,
        ?AlertRunProcessor $processor,
    ): array {
        $collector->collect($run->alert, $run, $dataConfig);
        $processorContext = $processor?->process($collector, $run) ?? [];

        return [
            'result' => $collector->result(),
            'processor_context' => $processorContext,
        ];
    }
}
