<?php
declare(strict_types=1);

namespace App\Services\Alerts;

use App\DTO\Alerts\AlertDataConfig;
use App\DTO\Alerts\AlertPreview;
use App\DTO\Alerts\AlertRunOutcome;
use App\DTO\Email\EmailAddress;
use App\DTO\Email\Recipient;
use App\DTO\Email\Recipients;
use App\Enums\ProcessStatus;
use App\Mail\Builders\Alert\AlertMailBuilder;
use App\Models\Alerts\Alert;
use App\Models\Alerts\AlertRun;
use App\Models\Alerts\AlertSchedule;
use Illuminate\Support\Str;
use Throwable;

final readonly class AlertRunner
{
    public function __construct(
        private AlertsRegistry $registry,
        private AlertRecipientResolver $recipientResolver,
        private AlertExecutionStrategyResolver $executionStrategyResolver,
        private AlertDeliveryPlanner $deliveryPlanner,
        private AlertMailBuilder $mailBuilder,
        private AlertMessageDispatcher $messageDispatcher,
    ) {}

    public function run(AlertRun $run, bool $test = false): AlertRunOutcome
    {
        $run->loadMissing('alert.roles', 'schedule');
        $context = [];
        $executionStatus = ProcessStatus::Failed;
        try {
            $dataConfig = $run->schedule->dataConfig($run->alert);
            $context = $run->context ?? $this->baseContext($run, $dataConfig, $test);
            if (! $run->alert->isEnabled() || ! $run->schedule->isEnabled()) {
                $run->update(
                    [
                        'status' => ProcessStatus::Failed,
                        'context' => array_merge(
                            $context,
                            ['error' => ['message' => 'Alert or schedule is disabled.']],
                        ),
                        'completed_at' => now(),
                        'error_summary' => 'Alert or schedule is disabled.',
                    ],
                );

                return new AlertRunOutcome($run);
            }

            $collector = $this->registry->collector($run->alert->type_key);
            if ($run->alert->definition_version !== $this->registry->definitionVersion($run->alert->type_key)) {
                throw new UnknownAlertType('Alert definition version is unsupported.');
            }
            $collector->validate($dataConfig);

            AlertRun::query()
                ->whereKey($run->id)
                ->whereNull('started_at')
                ->update(['started_at' => now()]);
            $run->update(['status' => ProcessStatus::Running]);
            $run->refresh();
            $processor = $this->registry->runProcessor($run->alert->type_key);
            $execution = $this->executionStrategyResolver
                ->resolve($collector)
                ->execute($collector, $run, $dataConfig, $context, $processor);
            $result = $execution['result'];
            $processorContext = $execution['processor_context'];
            $executionStatus = ProcessStatus::Partial;
            $context = $run->context ?? $context;
            $context = array_merge($context, $processorContext);
            $recipients = $this->recipientsFor($run->alert, $test);
            $requests = $this->deliveryPlanner->plan($collector, $run, $recipients);
            $messages = array_map($this->mailBuilder->build(...), $requests);
            $plannedAddresses = [];
            foreach ($requests as $request) {
                foreach ($request->recipients as $recipient) {
                    $plannedAddresses[strtolower($recipient->email->address)] = true;
                }
            }
            $recipientCount = $requests === [] ? $recipients->count() : count($plannedAddresses);
            $hasRecipients = $recipientCount > 0;
            $this->messageDispatcher->dispatch($run, $requests, $messages);
            $context = $run->refresh()->context ?? $context;
            /**
             * @formatter:off
             */
            $run->update([
                'status' => $hasRecipients ? $result['status'] : ProcessStatus::Skipped,
                'context' => array_merge(
                    $context,
                    $result['context'] ?? [],
                    $processorContext,
                    [
                        'recipient_count' => $recipientCount,
                        'recipient_mode' => $test ? 'test' : 'roles',
                        'planned_message_count' => count($messages),
                        'planned_boundary_keys' => array_map(
                            static fn ($request): string => $request->boundaryKey,
                            $requests,
                        ),
                        ...($hasRecipients ? [] : ['skip_reason' => 'No deliverable recipients.']),
                    ],
                ),
                'completed_at' => now(),
                'error_summary' => null,
            ]);
            /**
             * @formatter:on
             */

            return new AlertRunOutcome($run, $messages);
        } catch (Throwable $exception) {
            [$exceptionStatus, $exceptionContext] = $exception instanceof AlertRunExecutionException
                ? [$exception->status, $exception->context]
                : [$executionStatus, ['error' => ['message' => substr($exception->getMessage(), 0, 255)]]];
            /**
             * @formatter:off
             */
            $run->update([
                'status' => $exceptionStatus,
                'context' => array_merge(
                    $run->context ?? [],
                    $context,
                    $exceptionContext,
                ),
                'completed_at' => now(),
                'error_summary' => substr($exception->getMessage(), 0, 255),
            ]);
            /**
             * @formatter:on
             */

            return new AlertRunOutcome($run);
        }
    }

    public function recipientCount(Alert $alert, bool $test = false): int
    {
        return $this->recipientsFor($alert, $test)->count();
    }

    public function preview(AlertSchedule $schedule): AlertPreview
    {
        $schedule->loadMissing('alert');
        $alert = $schedule->alert;
        $collector = $this->registry->collector($alert->type_key);
        if ($alert->definition_version !== $this->registry->definitionVersion($alert->type_key)) {
            throw new UnknownAlertType('Alert definition version is unsupported.');
        }
        $dataConfig = $schedule->dataConfig($alert);
        $collector->validate($dataConfig);

        return $collector->preview($alert, $dataConfig);
    }

    private function recipientsFor(Alert $alert, bool $test): Recipients
    {
        if (! $test) {
            return $this->recipientResolver->resolve($alert);
        }

        return new Recipients(
            new Recipient(
                new EmailAddress('alert-test-'.Str::uuid().'@example.test'),
                'Alert test recipient',
            ),
        );
    }

    /** @return array<string, mixed> */
    private function baseContext(AlertRun $run, AlertDataConfig $dataConfig, bool $test): array
    {
        return [
            'alert_type' => $run->alert->type_key->slug(),
            'definition_version' => $run->alert->definition_version,
            'trigger_type' => 'schedule',
            'scheduled_for' => $run->scheduled_for->toIso8601String(),
            'schedule' => [
                'id' => $run->schedule->id,
                'type' => $run->schedule->schedule_type->value,
                'definition' => $run->schedule->schedule_definition,
                'timezone' => $run->schedule->timezone,
            ],
            'data_config' => $dataConfig->toArray(),
            'data_config_hash' => $run->schedule->data_params_hash,
            'recipient_roles' => $run->alert->roles
                ->filter(static fn ($role): bool => $role->pivot->enabled)
                ->map(static fn ($role): array => [
                    'id' => $role->id,
                    'code' => $role->code,
                    'name' => $role->name,
                ])
                ->values()
                ->all(),
            'recipient_count' => 0,
            'recipient_mode' => $test ? 'test' : 'roles',
            'email_count' => 0,
            'matched_row_count' => null,
            'source_stats' => [],
            'summary' => [],
            'payload' => ['item_keys' => []],
        ];
    }
}
