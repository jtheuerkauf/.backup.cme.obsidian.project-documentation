<?php
declare(strict_types=1);

namespace App\Services\Alerts;

use App\DTO\Email\EmailBuildRequest;
use App\DTO\Email\Recipients;
use App\Models\Alerts\AlertRun;
use App\Services\Alerts\Interfaces\AlertCollector;
use UnexpectedValueException;

final readonly class AlertDeliveryPlanner
{
    public function __construct(private AlertsRegistry $registry) {}

    /** @return list<EmailBuildRequest> */
    public function plan(AlertCollector $collector, AlertRun $run, Recipients $recipients): array
    {
        $definition = $this->registry->deliveryDefinition($run->alert->type_key);
        if ($definition === null) {
            return [];
        }

        $requests = [];
        $boundaryKeys = [];
        foreach ($definition->boundaryPlanner->boundaries($collector, $run, $recipients) as $boundary) {
            if ($boundary->key === '' || isset($boundaryKeys[$boundary->key])) {
                throw new UnexpectedValueException('Alert message boundaries require distinct, nonempty keys.');
            }
            if ($boundary->recipients->count() === 0) {
                throw new UnexpectedValueException("Alert message boundary [{$boundary->key}] has no recipients.");
            }
            $boundaryKeys[$boundary->key] = true;

            $requests[] = new EmailBuildRequest(
                boundaryKey: $boundary->key,
                type: $definition->view->emailType(),
                recipients: $boundary->recipients,
                subject: $definition->view->subject($run),
                template: $definition->view->template(),
                viewData: $definition->formatter->format($boundary, $run),
                relatedType: AlertRun::class,
                relatedId: $run->exists ? (int) $run->getKey() : null,
            );
        }

        return $requests;
    }
}
