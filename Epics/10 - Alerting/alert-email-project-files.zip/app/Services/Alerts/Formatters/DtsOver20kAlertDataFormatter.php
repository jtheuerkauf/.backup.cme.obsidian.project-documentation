<?php
declare(strict_types=1);

namespace App\Services\Alerts\Formatters;

use App\DTO\Alerts\AlertMessageBoundary;
use App\Models\Alerts\AlertRun;
use App\Services\Alerts\Interfaces\AlertEmailDataFormatter;
use Carbon\CarbonImmutable;

final readonly class DtsOver20kAlertDataFormatter implements AlertEmailDataFormatter
{
    public function format(AlertMessageBoundary $boundary, AlertRun $run): array
    {
        return [
            'rows' => collect($boundary->rows),
            'generatedAt' => CarbonImmutable::instance($run->started_at ?? now()),
        ];
    }
}
