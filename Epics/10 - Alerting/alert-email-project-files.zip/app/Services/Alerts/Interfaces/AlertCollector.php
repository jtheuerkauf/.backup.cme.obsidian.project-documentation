<?php

namespace App\Services\Alerts\Interfaces;

use App\DTO\Alerts\AlertDataConfig;
use App\DTO\Alerts\AlertPreview;
use App\Models\Alerts\Alert;
use App\Models\Alerts\AlertRun;

interface AlertCollector
{
    public function validate(AlertDataConfig $dataConfig): void;

    public function preview(Alert $alert, AlertDataConfig $dataConfig): AlertPreview;

    public function collect(Alert $alert, AlertRun $run, AlertDataConfig $dataConfig): void;

    /** @return array<string, mixed> */
    public function result(): array;
}
