<?php
declare(strict_types=1);

namespace App\Services\Alerts\Interfaces;

use App\DTO\Alerts\AlertMessageBoundary;
use App\DTO\Email\Recipients;
use App\Models\Alerts\AlertRun;

interface AlertBoundaryPlanner
{
    /** @return list<AlertMessageBoundary> */
    public function boundaries(AlertCollector $collector, AlertRun $run, Recipients $recipients): array;
}
