<?php
declare(strict_types=1);

namespace App\Services\Alerts\Interfaces;

use App\DTO\Alerts\AlertMessageBoundary;
use App\Models\Alerts\AlertRun;

interface AlertEmailDataFormatter
{
    /** @return array<string, mixed> */
    public function format(AlertMessageBoundary $boundary, AlertRun $run): array;
}
