<?php
declare(strict_types=1);

namespace App\Services\Alerts\Interfaces;

use App\Models\Alerts\AlertRun;

interface AlertRunProcessor
{
    /** @return array<string, mixed> Additional run context. */
    public function process(
        AlertCollector $collector,
        AlertRun $run,
    ): array;
}
