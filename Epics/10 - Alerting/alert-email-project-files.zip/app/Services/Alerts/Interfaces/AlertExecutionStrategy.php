<?php
declare(strict_types=1);

namespace App\Services\Alerts\Interfaces;

use App\DTO\Alerts\AlertDataConfig;
use App\Models\Alerts\AlertRun;

interface AlertExecutionStrategy
{
    /**
     * @param array<string, mixed> $context
     *
     * @return array{result: array<string, mixed>, processor_context: array<string, mixed>}
     */
    public function execute(
        AlertCollector $collector,
        AlertRun $run,
        AlertDataConfig $dataConfig,
        array $context,
        ?AlertRunProcessor $processor,
    ): array;
}
