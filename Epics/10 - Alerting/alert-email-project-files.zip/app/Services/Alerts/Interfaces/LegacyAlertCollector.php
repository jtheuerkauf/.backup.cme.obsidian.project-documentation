<?php
declare(strict_types=1);

namespace App\Services\Alerts\Interfaces;

interface LegacyAlertCollector extends AlertCollector
{
    /** @param array<string, mixed> $result */
    public function restoreResult(array $result): void;
}
