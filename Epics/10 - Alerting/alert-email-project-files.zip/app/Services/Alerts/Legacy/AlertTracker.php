<?php
declare(strict_types=1);

namespace App\Services\Alerts\Legacy;

use App\Enums\Alerts\AlertType;
use App\Models\Alerts\Alert;
use App\Models\Alerts\AlertRun;
use App\Models\AllRivers\AlertTracking;
use App\Services\Alerts\AlertsRegistry;
use Illuminate\Support\Facades\DB;

final readonly class AlertTracker
{
    public static function alertTrackingName(AlertType $alertType): string
    {
        return app(AlertsRegistry::class)->legacyTrackingName($alertType);
    }

    public function track(
        Alert $alert,
        AlertRun $run,
        int $lineCount,
        array $legacyState = [],
    ): bool {
        $reporting = [
            ...app(AlertsRegistry::class)->legacyReporting($alert->type_key),
            'displayName' => $alert->name,
        ];
        $name = self::alertTrackingName($alert->type_key);
        $date = $run->started_at?->toDateString() ?? $run->scheduled_for->toDateString();
        $database = (new AlertTracking())->getConnection();
        $payloadHash = hash(
            'sha256',
            json_encode(
                [
                    'name' => $name,
                    'run_date' => $date,
                    'line_count' => $lineCount,
                    'state' => $legacyState,
                ],
                JSON_THROW_ON_ERROR,
            ),
        );

        return $database->transaction(
            function() use (
                $database,
                $run,
                $name,
                $date,
                $lineCount,
                $legacyState,
                $payloadHash,
                $reporting,
                $alert,
            ): bool
            {
                $inserted = $database->table('alert_run_legacy_receipts')->insertOrIgnore(
                    [
                        'idempotency_key' => $run->idempotency_key,
                        'name' => $name,
                        'run_date' => $date,
                        'line_count' => $lineCount,
                        'payload_hash' => $payloadHash,
                    ],
                );
                if ($inserted === 0) {
                    $receipt = $database
                        ->table('alert_run_legacy_receipts')
                        ->where('idempotency_key', $run->idempotency_key)
                        ->first();
                    if ($receipt === null || $receipt->payload_hash !== $payloadHash) {
                        throw new \RuntimeException('Legacy receipt conflicts with this run snapshot.');
                    }

                    return false;
                }

                if ($alert->type_key === AlertType::DtsOver20k && $legacyState !== []) {
                    $database->table('dtsOver14KAlert')->upsert(
                        $legacyState,
                        ['trackerNumber'],
                        ['dtsTotalCost', 'customerNeedByDate', 'lastAlertDate'],
                    );
                }

                $database->table('alertTracking')->upsert(
                    [
                        [
                            'name' => $name,
                            'runDate' => $date,
                            'runCount' => $lineCount,
                            'totalRunCount' => 1,
                            'lineCount' => $lineCount,
                        ],
                    ],
                    ['name', 'runDate'],
                    [
                        'runCount' => DB::raw('runCount + ' . $lineCount),
                        'totalRunCount' => DB::raw('totalRunCount + 1'),
                        'lineCount' => DB::raw('lineCount + ' . $lineCount),
                    ],
                );

                $database->table('dimReporting')->upsert(
                    [
                        ['name' => $name] + $reporting + ['createdDate' => $date],
                    ],
                    ['name'],
                    ['displayName', 'description', 'frequency', 'ownerEmail', 'requestorEmail'],
                );

                return true;
            },
        );
    }
}
