<?php
declare(strict_types=1);

namespace App\Services\Alerts\Legacy;

use App\DTO\Alerts\AlertDataConfig;
use App\Enums\ProcessStatus;
use App\Models\Alerts\AlertRun;
use App\Services\Alerts\AlertRunExecutionException;
use App\Services\Alerts\Interfaces\AlertRunProcessor;
use App\Services\Alerts\Interfaces\LegacyAlertCollector;
use Illuminate\Support\Facades\DB;
use RuntimeException;
use Throwable;

final readonly class AlertRunner
{
    /**
     * @param array<string, mixed> $context
     *
     * @return array{result: array<string, mixed>, processor_context: array<string, mixed>}
     */
    public function run(
        LegacyAlertCollector $collector,
        AlertRun $run,
        AlertDataConfig $dataConfig,
        array $context,
        ?AlertRunProcessor $processor,
    ): array {
        if (isset($run->context['collection_snapshot'])) {
            $result = $this->storedResult($run);
            $collector->restoreResult($result);
        } else {
            $collector->collect($run->alert, $run, $dataConfig);
            $result = $this->storeResult(
                $run,
                $context,
                $collector->result(),
            );
            $collector->restoreResult($result);
        }

        try {
            if ($processor === null) {
                throw new RuntimeException('A legacy alert requires a run processor.');
            }

            $processorContext = $processor->process($collector, $run);
        } catch (Throwable $exception) {
            $summary = substr($exception->getMessage(), 0, 255);
            throw new AlertRunExecutionException(
                $summary,
                ProcessStatus::Partial,
                ['legacy_write' => ['status' => 'failed', 'error' => $summary]],
                $exception,
            );
        }

        return ['result' => $result, 'processor_context' => $processorContext];
    }

    /** @return array<string, mixed> */
    private function storeResult(AlertRun $run, array $context, array $result): array
    {
        DB::transaction(
            function() use ($run, $context, $result): void
            {
                $lockedRun = AlertRun::query()->lockForUpdate()->findOrFail($run->id);
                if (isset($lockedRun->context['collection_snapshot'])) {
                    return;
                }

                DB::table('alert_run_legacy_payloads')->insert(
                    [
                        'alert_run_id' => $run->id,
                        'payload' => json_encode([
                            'rows' => $result['rows'] ?? [],
                            'legacy_state' => $result['legacy_state'] ?? [],
                        ], JSON_THROW_ON_ERROR),
                    ],
                );
                $lockedRun->update(
                    [
                        'context' => array_merge(
                            $context,
                            $result['context'] ?? [],
                            [
                                'collection_snapshot' => [
                                    'status' => $result['status']->value,
                                    'context' => $result['context'] ?? [],
                                ],
                            ],
                        ),
                    ],
                );
            },
        );

        $run->refresh();

        return $this->storedResult($run);
    }

    /** @return array<string, mixed> */
    private function storedResult(AlertRun $run): array
    {
        $snapshot = $run->context['collection_snapshot'];
        $payload = DB::table('alert_run_legacy_payloads')
            ->where('alert_run_id', $run->id)
            ->value('payload');
        if ($payload === null) {
            throw new RuntimeException('Legacy collection snapshot is missing its payload.');
        }

        $collected = json_decode($payload, true, 512, JSON_THROW_ON_ERROR);
        // Payloads saved before collector ownership contained only legacy state.
        if (array_is_list($collected)) {
            $collected = ['legacy_state' => $collected, 'rows' => []];
        }

        return [
            'status' => ProcessStatus::from($snapshot['status']),
            'context' => $snapshot['context'],
            'rows' => $collected['rows'] ?? [],
            'legacy_state' => $collected['legacy_state'] ?? [],
        ];
    }
}
