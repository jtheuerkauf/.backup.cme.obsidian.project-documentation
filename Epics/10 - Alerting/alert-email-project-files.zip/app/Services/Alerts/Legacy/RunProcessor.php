<?php
declare(strict_types=1);

namespace App\Services\Alerts\Legacy;

use App\Models\Alerts\AlertRun;
use App\Models\AllRivers\AlertTracking;
use App\Services\Alerts\Interfaces\AlertCollector;
use App\Services\Alerts\Interfaces\AlertRunProcessor;
use App\Services\Alerts\Interfaces\LegacyAlertCollector;
use InvalidArgumentException;

final readonly class RunProcessor implements AlertRunProcessor
{
    public function __construct(
        private AlertTracker $tracker,
    ) {}

    public function process(
        AlertCollector $collector,
        AlertRun $run,
    ): array {
        if (!$collector instanceof LegacyAlertCollector) {
            throw new InvalidArgumentException('Legacy alert runs require a LegacyAlertCollector.');
        }

        $result = $collector->result();
        $applied = $this->tracker->track(
            $run->alert,
            $run,
            (int) ($result['context']['matched_row_count'] ?? 0),
            $result['legacy_state'] ?? [],
        );

        return [
            'legacy_write' => [
                'status' => $applied ? 'succeeded' : 'already_applied',
                'connection' => (new AlertTracking())->getConnectionName(),
            ],
        ];
    }
}
