<?php
declare(strict_types=1);

namespace App\Services\Alerts\BoundaryPlanners;

use App\DTO\Alerts\AlertMessageBoundary;
use App\DTO\Email\Recipients;
use App\Models\Alerts\AlertRun;
use App\Services\Alerts\Interfaces\AlertBoundaryPlanner;
use App\Services\Alerts\Interfaces\AlertCollector;
use UnexpectedValueException;

final readonly class BroadcastAlertBoundaryPlanner implements AlertBoundaryPlanner
{
    public function boundaries(AlertCollector $collector, AlertRun $run, Recipients $recipients): array
    {
        if ($recipients->count() === 0) {
            return [];
        }

        $rows = $collector->result()['rows'] ?? [];
        if (! is_array($rows)) {
            throw new UnexpectedValueException('Collected alert rows must be an array.');
        }

        return $rows === [] ? [] : [new AlertMessageBoundary('all', array_values($rows), $recipients)];
    }
}
