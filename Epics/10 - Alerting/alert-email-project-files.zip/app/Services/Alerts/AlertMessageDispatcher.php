<?php
declare(strict_types=1);

namespace App\Services\Alerts;

use App\DTO\Email\EmailBuildRequest;
use App\Enums\Email\EmailStatus;
use App\Mail\BuiltMail;
use App\Models\Alerts\AlertRun;
use App\Models\Email;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Mail;
use Throwable;

/** Persists each alert email intent before queueing its built message. */
final readonly class AlertMessageDispatcher
{
    public function __construct(
        private AlertMessageSnapshot $snapshot,
    ) {}

    /**
     * @param  list<EmailBuildRequest>  $requests
     * @param  list<BuiltMail>  $messages
     */
    public function dispatch(AlertRun $run, array $requests, array $messages): void
    {
        foreach ($requests as $index => $request) {
            $message = $messages[$index];
            $intent = DB::transaction(
                function () use ($run, $request, $message): Email {
                    $dedupeKey = "alert-run:{$run->id}:".hash('sha256', $request->boundaryKey);
                    $existing = Email::query()->where('dedupe_key', $dedupeKey)->first();
                    if ($existing !== null) {
                        return $existing;
                    }

                    $intent = Email::createWithBody(
                        [
                            'provider' => config('mail.default') === 'msgraph' ? 'msgraph' : config('mail.default'),
                            'email_type' => $request->type->value,
                            'mailable' => $request->type,
                            'related_type' => AlertRun::class,
                            'related_id' => $run->id,
                            'from_email' => config('mail.from.address'),
                            'to' => array_map(
                                static fn ($recipient): string => $recipient->email->address,
                                $request->recipients->toArray(),
                            ),
                            'cc' => [],
                            'bcc' => [],
                            'reply_to' => ['devrequests@cmecorp.com'],
                            'subject' => $request->subject,
                            'body_html' => $message->render(),
                            'status' => EmailStatus::Queued,
                            'attempts' => 0,
                            'dedupe_key' => $dedupeKey,
                            'context' => [
                                'alert_run_id' => $run->id,
                                'boundary_key' => $request->boundaryKey,
                            ],
                        ],
                    );
                    $this->snapshot->record($intent);

                    return $intent;
                },
            );

            if ($intent->queued_at !== null) {
                $this->snapshot->record($intent);

                continue;
            }

            try {
                if ($intent->status === EmailStatus::Failed) {
                    $intent->update(
                        [
                            'status' => EmailStatus::Queued,
                            'error_code' => null,
                            'error_message' => null,
                        ],
                    );
                    $this->snapshot->record($intent);
                }
                Mail::queue($message->withIntent($intent->id)->afterCommit());
                $intent->refresh();
                $intent->update(['queued_at' => now()]);
                $this->snapshot->record($intent);
            } catch (Throwable $exception) {
                $intent->update(
                    [
                        'status' => EmailStatus::Failed,
                        'error_message' => $exception->getMessage(),
                    ],
                );
                $this->snapshot->record($intent);

                throw $exception;
            }
        }
    }
}
