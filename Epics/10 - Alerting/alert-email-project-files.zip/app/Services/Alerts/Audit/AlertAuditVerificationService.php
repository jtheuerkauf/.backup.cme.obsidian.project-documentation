<?php

namespace App\Services\Alerts\Audit;

use App\Models\AlertAudit;
use App\Models\AlertAuditVerification;
use App\Models\AllRivers\AlertTracking;
use Illuminate\Support\Collection;
use Illuminate\Support\Facades\DB;

class AlertAuditVerificationService
{
    public function handleAudit(): Collection
    {
        $this->syncAlertTracking();

        return $this->generateAlertsToAuditByCadence();
    }

    /**
     * Add any new Alerts, not already listed, in AlertAudit
     *
     * @return void
     */
    protected function syncAlertTracking(): void
    {
        $currentAlertAudits = AlertAudit::query()->pluck('name')->toArray();
        $newAlertTrackers = AlertTracking::query()
            ->select('name')
            ->distinct()
            ->whereNotIn('name', $currentAlertAudits)
            ->whereRaw("YEAR(runDate) = " . now()->year)
            ->get();

        foreach ($newAlertTrackers as $newAlertTracker) {
            $newAlert = AlertAudit::query()->create([
                'name' => $newAlertTracker->name,
            ]);

            // New Alerts have there created_at cleared so that it will display as newly added in the Admin
            $newAlert->created_at = null;
            $newAlert->save();
        }
    }

    /**
     * Update and return any Alerts to Audit on the cadence.
     * Default: February 10th
     *
     * @return Collection
     */
    protected function generateAlertsToAuditByCadence(): Collection
    {
        $alertTrackingResults = AlertTracking::query()
            ->from('alertTracking as t')
            ->with('dimReporting')
            ->join(
                DB::raw("
                    (
                        SELECT name, MAX(runDate) AS max_runDate
                        FROM alertTracking
                        WHERE YEAR(runDate) = " . now()->year . "
                        GROUP BY name
                    ) latest
                "),
                function ($join) {
                    $join->on('latest.name', '=', 't.name')
                        ->on('latest.max_runDate', '=', 't.runDate');
                }
            )
            ->get()
            ->groupBy('name');

        $currentAlertAudits = AlertAudit::query()->with('auditVerifications')->get();
        $alertsToAudit = [];

        foreach ($currentAlertAudits as $alertAudit) {
            $cadenceInDaysFromLastVerified = $alertAudit->last_verified?->addDays($alertAudit->cadence_in_days);
            if (!$cadenceInDaysFromLastVerified || $cadenceInDaysFromLastVerified >= now()) {
                $lastAlertRan = $alertTrackingResults->get($alertAudit->name);

                if ($lastAlertRan) {
                    foreach ($lastAlertRan as $alertRan) {
                        foreach ($alertRan->dimReporting as $dimReport) {
                            AlertAuditVerification::query()->create([
                                'name' => $alertRan->name,
                                'owner_email' => $dimReport->ownerEmail,
                                'requester_email' => $dimReport->requestorEmail,
                            ]);

                            $alertsToAudit[$dimReport->ownerEmail][] = [
                                'name' => $alertRan->name,
                                'display_name' => $dimReport->displayName,
                                'owner_email' => $dimReport->ownerEmail,
                            ];
                        }
                    }
                }
            }
        }

        return collect($alertsToAudit);
    }
}
