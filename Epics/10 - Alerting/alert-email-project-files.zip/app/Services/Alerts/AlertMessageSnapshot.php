<?php
declare(strict_types=1);

namespace App\Services\Alerts;

use App\Enums\Email\EmailStatus;
use App\Models\Alerts\AlertRun;
use App\Models\Email;
use Illuminate\Support\Facades\DB;

/** Records each queued message boundary and its later transport outcome on its run. */
final readonly class AlertMessageSnapshot
{
    public function record(Email $email): void
    {
        $boundaryKey = $email->context['boundary_key'] ?? null;
        if ($email->related_type !== AlertRun::class || !is_int($email->related_id) || !is_string($boundaryKey)) {
            return;
        }

        DB::transaction(
            function() use ($email, $boundaryKey): void
            {
                $run = AlertRun::query()->lockForUpdate()->find($email->related_id);
                if ($run === null) {
                    return;
                }

                $context = $run->context ?? [];
                $messages = $context['email_messages'] ?? [];
                $messages[$boundaryKey] = [
                    'email_id' => $email->id,
                    'status' => $email->status === EmailStatus::Queued && $email->queued_at === null
                        ? 'pending'
                        : $email->status->value,
                    'queued_at' => $email->queued_at?->toIso8601String(),
                    'sent_at' => $email->sent_at?->toIso8601String(),
                    'error' => $email->error_message,
                ];
                $run->update(
                    [
                        'context' => array_merge(
                            $context,
                            [
                                'email_count' => count($messages),
                                'email_messages' => $messages,
                            ],
                        ),
                    ],
                );
            },
        );
    }
}
