<?php
declare(strict_types=1);

namespace App\Services\Alerts;

use App\DTO\Email\EmailAddress;
use App\DTO\Email\Recipient;
use App\DTO\Email\Recipients;
use App\Models\Alerts\Alert;
use App\Models\Datasync\AdpUser;
use App\Models\User;
use Illuminate\Database\Query\JoinClause;

final readonly class AlertRecipientResolver
{
    public function resolve(Alert $alert): Recipients
    {
        $modelHasRolesTable = config('permission.table_names.model_has_roles');
        $modelKey = config('permission.column_names.model_morph_key', 'model_id');
        $rolePivotKey = config('permission.column_names.role_pivot_key') ?? 'role_id';

        $candidates = User::query()
            ->select(['users.id', 'users.name'])
            ->selectRaw('LOWER(users.email) AS email')
            ->distinct()
            ->join(
                "$modelHasRolesTable AS mhr",
                fn(JoinClause $join) => $join
                    ->on('users.id', "mhr.$modelKey")
                    ->where('mhr.model_type', User::class),
            )
            ->join(
                'alert_role_recipients AS arr',
                fn(JoinClause $join) => $join
                    ->on('arr.role_id', "mhr.$rolePivotKey")
                    ->where(
                        [
                            'arr.alert_id' => $alert->id,
                            'arr.enabled' => true,
                        ],
                    ),
            )
            ->whereRaw("NULLIF(users.email, '') IS NOT NULL")
            ->orderBy('email')
            ->get();

        if ($candidates->isEmpty()) {
            return new Recipients();
        }

        $activeWorkEmails = AdpUser::query()
            ->select([])
            ->selectRaw('LOWER(work_email) AS work_email')
            ->where('status', 'Active')
            ->whereIn('work_email', $candidates->pluck('email')->all())
            ->pluck('work_email')
            ->all();

        $recipients = [];
        /** @var User $user */
        foreach ($candidates as $user) {
            if (in_array($user->email, $activeWorkEmails, true)) {
                $recipients[] = new Recipient(
                    new EmailAddress($user->email),
                    $user->name,
                );
            }
        }

        return new Recipients(...$recipients);
    }
}
