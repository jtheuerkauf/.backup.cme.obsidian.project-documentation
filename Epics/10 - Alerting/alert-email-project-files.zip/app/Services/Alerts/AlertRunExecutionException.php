<?php
declare(strict_types=1);

namespace App\Services\Alerts;

use App\Enums\ProcessStatus;
use RuntimeException;
use Throwable;

final class AlertRunExecutionException extends RuntimeException
{
    /** @param array<string, mixed> $context */
    public function __construct(
        string $message,
        public readonly ProcessStatus $status,
        public readonly array $context,
        ?Throwable $previous = null,
    ) {
        parent::__construct($message, previous: $previous);
    }
}
