<?php
declare(strict_types=1);

namespace App\Services\Alerts;

use App\Services\Alerts\Interfaces\AlertCollector;
use App\Services\Alerts\Interfaces\AlertExecutionStrategy;
use App\Services\Alerts\Interfaces\LegacyAlertCollector;
use App\Services\Alerts\Legacy\LegacyAlertExecutionStrategy;

final readonly class AlertExecutionStrategyResolver
{
    public function __construct(
        private StandardAlertExecutionStrategy $standardStrategy,
        private LegacyAlertExecutionStrategy $legacyStrategy,
    ) {}

    public function resolve(AlertCollector $collector): AlertExecutionStrategy
    {
        return $collector instanceof LegacyAlertCollector
            ? $this->legacyStrategy
            : $this->standardStrategy;
    }
}
