<?php
declare(strict_types=1);

namespace App\Services\Alerts;

use App\DTO\Alerts\AlertDeliveryDefinition;
use App\Enums\Alerts\AlertType;
use App\Services\Alerts\Interfaces\AlertBoundaryPlanner;
use App\Services\Alerts\Interfaces\AlertEmailDataFormatter;
use App\View\Emails\EmailView;
use App\Services\Alerts\Interfaces\AlertCollector;
use App\Services\Alerts\Interfaces\AlertRunProcessor;
use ValueError;

final readonly class AlertsRegistry
{
    public function registry(): array
    {
        return config('alerts.registry', []);
    }

    public function definition(AlertType $type): array
    {
        return $this->registry()[$type->slug()] ?? [];
    }

    /**
     * @return array<string, AlertType>
     */
    public function typeKeys(): array
    {
        $keys = array_keys($this->registry());
        $pairs = [];
        try {
            foreach ($keys as $key) {
                $pairs[$key] = AlertType::from($key);
            }

            return $pairs;
        } catch (ValueError $e) {
            throw new UnknownAlertType(
                "Failed to retrieve alert type keys. Last key processed: {$key}",
                previous: $e,
            );
        }
    }

    /**
     * @return \App\Services\Alerts\Interfaces\LegacyAlertCollector|AlertCollector
     */
    public function collector(AlertType $type): AlertCollector
    {
        $definition = $this->definition($type);
        $collector = $definition['collector'] ?? null;

        if (!((is_string($collector) && is_a($collector, AlertCollector::class, true))
              || $collector instanceof AlertCollector
        )) {
            throw new UnknownAlertType("Unsupported Collector for alert type [{$type->slug()}].");
        }

        return is_string($collector) ? app($collector) : $collector;
    }

    public function runProcessor(AlertType $type): ?AlertRunProcessor
    {
        $processor = $this->definition($type)['run_processor'] ?? null;
        if ($processor === null) {
            return null;
        }
        if (!(
            (is_string($processor) && is_a($processor, AlertRunProcessor::class, true))
            || $processor instanceof AlertRunProcessor
        )) {
            throw new UnknownAlertType("Unsupported Run Processor for alert type [{$type->slug()}].");
        }

        return is_string($processor) ? app($processor) : $processor;
    }

    public function deliveryDefinition(AlertType $type): ?AlertDeliveryDefinition
    {
        $delivery = $this->definition($type)['email_delivery'] ?? null;
        if ($delivery === null) {
            return null;
        }
        if (! is_array($delivery)) {
            throw new UnknownAlertType("Unsupported email delivery definition for alert type [{$type->slug()}].");
        }

        $parts = [
            'boundary_planner' => AlertBoundaryPlanner::class,
            'formatter' => AlertEmailDataFormatter::class,
            'view' => EmailView::class,
        ];
        $resolved = [];
        foreach ($parts as $key => $contract) {
            $part = $delivery[$key] ?? null;
            if (! (is_string($part) && is_a($part, $contract, true)) && ! $part instanceof $contract) {
                throw new UnknownAlertType("Unsupported {$key} for alert type [{$type->slug()}].");
            }
            $resolved[$key] = is_string($part) ? app($part) : $part;
        }

        return new AlertDeliveryDefinition(
            $resolved['boundary_planner'],
            $resolved['formatter'],
            $resolved['view'],
        );
    }

    public function definitionVersion(AlertType $type): int
    {
        $definition = $this->definition($type);
        if (!isset($definition['definition_version'])) {
            throw new UnknownAlertType("Unsupported alert type [{$type->slug()}].");
        }

        return (int) $definition['definition_version'];
    }

    public function legacyTrackingName(AlertType $type): string
    {
        $name = $this->definition($type)['legacy_tracking_name'] ?? null;
        if (! is_string($name) || $name === '') {
            throw new UnknownAlertType("Unsupported legacy tracking name for alert type [{$type->slug()}].");
        }

        return $name;
    }

    public function mailSubject(AlertType $type): string
    {
        $subject = $this->definition($type)['mail_subject'] ?? null;
        if (! is_string($subject) || $subject === '') {
            throw new UnknownAlertType("Unsupported mail subject for alert type [{$type->slug()}].");
        }

        return $subject;
    }

    /** @return array{category: string, description: string, frequency: string, ownerEmail: string, requestorEmail: string} */
    public function legacyReporting(AlertType $type): array
    {
        $reporting = $this->definition($type)['legacy_reporting'] ?? null;
        $fields = ['category', 'description', 'frequency', 'ownerEmail', 'requestorEmail'];
        if (! is_array($reporting)) {
            throw new UnknownAlertType("Unsupported legacy reporting for alert type [{$type->slug()}].");
        }
        foreach ($fields as $field) {
            if (! isset($reporting[$field]) || ! is_string($reporting[$field])) {
                throw new UnknownAlertType("Unsupported legacy reporting for alert type [{$type->slug()}].");
            }
        }

        return array_intersect_key($reporting, array_flip($fields));
    }
}
