<?php

namespace App\Services\Alerts;

use DomainException;

final class UnknownAlertType extends DomainException
{
}
