<?php
declare(strict_types=1);

namespace App\Services\Alerts\Collectors\Legacy;

use App\DTO\Alerts\AlertDataConfig;
use App\DTO\Alerts\AlertPreview;
use App\Enums\ProcessStatus;
use App\Models\Alerts\Alert;
use App\Models\Alerts\AlertRun;
use App\Models\AllRivers\DtsOver14KAlert;
use App\Models\Datasync\AplusOrder;
use App\Models\Datasync\AplusOrderDetail;
use App\Models\Datasync\PMHubLineItem;
use App\Models\Datasync\PMHubOrderTracker;
use App\Models\Datasync\PMHubProfile;
use App\Models\Datasync\PMHubTracker;
use App\Services\Alerts\AlertsRegistry;
use App\Services\Alerts\Interfaces\LegacyAlertCollector;
use Carbon\CarbonImmutable;
use Illuminate\Support\Collection;
use Illuminate\Support\Facades\DB;

final class DtsOver20kAlertCollector implements LegacyAlertCollector
{
    private CarbonImmutable $originDate;

    /** @var Collection<int, array<string, mixed>> */
    private Collection $rows;

    /** @var null|array<string, mixed> */
    private ?array $result = null;

    public function __construct(
        ?CarbonImmutable $originDate = null,
    ) {
        $this->originDate = ($originDate ?? CarbonImmutable::today(config('app.timezone')))->startOfDay();
    }

    public function validate(AlertDataConfig $dataConfig): void
    {
        $minimumDtsTotal = $dataConfig->dataParams['minimum_dts_total'] ?? null;
        if (! is_numeric($minimumDtsTotal) || (float) $minimumDtsTotal <= 0) {
            throw new \InvalidArgumentException('DTS Over 20K alerts require a positive minimum_dts_total parameter.');
        }
    }

    public function collect(Alert $alert, AlertRun $run, AlertDataConfig $dataConfig): void
    {
        $this->result = null;
        unset($this->rows);
        $this->validate($dataConfig);
        $sourceStartedAt = microtime(true);
        $this->rows = $this->buildRows($dataConfig);
        $rows = $this->rows;
        $sourceDurationMs = (int) round((microtime(true) - $sourceStartedAt) * 1000);

        $this->result = [
            'status' => $rows->isEmpty() ? ProcessStatus::Empty : ProcessStatus::Succeeded,
            'rows' => $rows->values()->all(),
            'legacy_state' => $rows->map(
                fn(array $row): array => [
                    'trackerNumber' => $row['tracker_number'],
                    'dtsTotalCost' => $row['dts_total_cost'],
                    'customerNeedByDate' => $row['customer_need_by_date'],
                    'lastAlertDate' => $this->originDate->toDateString(),
                ],
            )->values()->all(),
            'context' => [
                'matched_row_count' => $rows->count(),
                'source_stats' => [[
                    'source' => app(AlertsRegistry::class)->legacyTrackingName($alert->type_key),
                    'connection' => (new AplusOrder())->getConnectionName(),
                    'row_count' => $rows->count(),
                    'duration_ms' => $sourceDurationMs,
                    'status' => 'succeeded',
                ]],
                'summary' => [
                    'minimum_dts_total' => (float) $dataConfig->dataParams['minimum_dts_total'],
                    'within_two_weeks_count' => $rows->where('within_two_weeks', true)->count(),
                ],
                'payload' => ['item_keys' => $rows->pluck('tracker_number')->values()->all()],
            ],
        ];
    }

    /** @return array<string, mixed> */
    public function result(): array
    {
        return $this->result ?? throw new \LogicException('Collect before reading the result.');
    }

    /** @return Collection<int, array<string, mixed>> */
    public function rows(): Collection
    {
        return $this->rows ?? throw new \LogicException('Collect before reading rows.');
    }

    /** @param array<string, mixed> $result */
    public function restoreResult(array $result): void
    {
        $this->rows = collect($result['rows'] ?? []);
        $this->result = $result;
    }

    public function preview(Alert $alert, AlertDataConfig $dataConfig): AlertPreview
    {
        $this->validate($dataConfig);
        $rows = $this->buildRows($dataConfig);

        return new AlertPreview(
            ['Tracker', 'DTS Total', 'Need By', 'Within Two Weeks'],
            $rows->map(
                static fn(array $row): array => [
                    $row['tracker_number'],
                    '$' . number_format($row['dts_total_cost'], 2),
                    $row['customer_need_by_date'] ?? '',
                    $row['within_two_weeks'] ? 'Yes' : 'No',
                ],
            )->all(),
        );
    }

    /**
     * Return alerts that have not been sent before, increased in value, or
     * have a previously-alerted need-by date within the next two weeks.
     *
     * @return Collection<int, array<string, mixed>>
     */
    public function buildRows(AlertDataConfig $dataConfig): Collection
    {
        $this->validate($dataConfig);
        $order = new AplusOrder();
        $detail = new AplusOrderDetail();
        $orderTracker = new PMHubOrderTracker();
        $tracker = new PMHubTracker();
        $lineItem = new PMHubLineItem();
        $profile = new PMHubProfile();
        $minimumDtsTotal = (float) $dataConfig->dataParams['minimum_dts_total'];
        $nullIfCastZeroDate = fn (string $field) => sprintf("NULLIF(CAST(%s AS CHAR), '0000-00-00')", $field);
        $needByDates = $lineItem->newQuery()
            ->select('trackerId')
            ->selectRaw("MIN({$nullIfCastZeroDate('customerNeedByDate')}) AS customer_need_by_date")
            ->where(function ($query): void {
                $query->where('itemSku', 'like', 'CESS-DTS-1%')
                    ->orWhere('itemSku', 'like', 'CESS-DTS-3%');
            })
            ->whereRaw("{$nullIfCastZeroDate('customerNeedByDate')} IS NOT NULL")
            ->groupBy('trackerId');

        $sql = $order
            ->newQuery()
            ->from($order->getTable().' AS orders')
            ->join($detail->getTable().' AS details', 'details.orderNumberGenKey', 'orders.orderNumberGenKey')
            ->join($orderTracker->getTable().' AS order_trackers', 'order_trackers.orderKey', 'orders.orderNumberKey')
            ->join($tracker->getTable().' AS trackers', 'trackers.trackerNumber', 'order_trackers.trackerNumber')
            ->leftJoinSub($needByDates, 'line_items', 'line_items.trackerId', 'trackers.trackerId')
            ->leftJoin($profile->getTable().' AS coordinators', 'coordinators.profileId', 'trackers.logisticsCoordinatorId')
            ->leftJoin($profile->getTable().' AS specialists', 'specialists.profileId', 'trackers.projectSpecialistId')
            ->leftJoin($profile->getTable().' AS managers', 'managers.profileId', 'trackers.accountManagerId')
            ->where(fn ($query) => $query
                ->whereLike('details.orderLineSKU', 'CESS-DTS-1%')
                ->orWhereLike('details.orderLineSKU', 'CESS-DTS-3%'),
            )
            ->where(fn ($query) => $query
                ->whereRaw("{$nullIfCastZeroDate('trackers.psCompDate')} IS NULL")
                ->orWhereRaw("{$nullIfCastZeroDate('trackers.lcCompDate')} IS NULL"),
            )
            ->where('trackers.deleted', false)
            ->groupBy([
                'trackers.trackerNumber',
                'trackers.trackerId',
                DB::raw($nullIfCastZeroDate('trackers.trackerCreatedDate')),
                'trackers.whName',
                'coordinators.firstName',
                'coordinators.lastName',
                'specialists.firstName',
                'specialists.lastName',
                'managers.firstName',
                'managers.lastName',
                'trackers.customerShipToName',
                'trackers.customerShipToAddress1',
                'trackers.customerShipToCity',
                'trackers.customerShipToState',
                'trackers.customerShipToZip',
                'line_items.customer_need_by_date',
            ])
            // SQLite treats aggregate comparisons differently unless the sum has numeric affinity.
            ->havingRaw('CAST(SUM(details.orderLineTotalCost) AS DECIMAL(12, 2)) >= ?', [$minimumDtsTotal])
            ->orderByDesc('trackers.trackerCreatedDate');
        // dd($sql->toRawSql());

        $candidates = $sql->get(
            [
                'trackers.trackerNumber AS tracker_number',
                'trackers.trackerId AS tracker_id',
                'trackers.trackerCreatedDate AS tracker_created_date',
                'trackers.whName AS warehouse',
                'coordinators.firstName AS logistics_coordinator_first_name',
                'coordinators.lastName AS logistics_coordinator_last_name',
                'specialists.firstName AS project_specialist_first_name',
                'specialists.lastName AS project_specialist_last_name',
                'managers.firstName AS account_manager_first_name',
                'managers.lastName AS account_manager_last_name',
                'trackers.customerShipToName AS customer_name',
                'trackers.customerShipToAddress1 AS address_1',
                'trackers.customerShipToCity AS city',
                'trackers.customerShipToState AS state',
                'trackers.customerShipToZip AS zip',
                DB::raw('SUM(details.orderLineTotalCost) AS dts_total_cost'),
                'line_items.customer_need_by_date',
            ]);

        if ($candidates->isEmpty()) {
            return $candidates;
        }

        $previousAlerts = DtsOver14KAlert::query()
            ->select(['trackerNumber', 'dtsTotalCost', 'lastAlertDate'])
            ->selectRaw("{$nullIfCastZeroDate('customerNeedByDate')} AS customerNeedByDate")
            ->whereIn('trackerNumber', $candidates->pluck('tracker_number')->all())
            ->get()
            ->keyBy('trackerNumber');

        $startOfDay = $this->originDate->startOfDay();
        $qualified = [];
        foreach ($candidates as $candidate) {
            $total = (float) $candidate->dts_total_cost;
            $needBy = $this->parseDate($candidate->customer_need_by_date);

            $previous = $previousAlerts->get($candidate->tracker_number);
            $needWithinTwoWeeks = $this->withinTwoWeeks($needBy, $startOfDay);
            if ($previous === null) {
                $previousTotal = null;
            } else {
                $previousTotal = (float) $previous->dtsTotalCost;

                // A tracker may alert once while its need-by date is outside
                // the two-week window and once when it enters that window.
                // lastAlertDate identifies which window the prior alert used.
                $lastAlertDate = $this->parseDate($previous->lastAlertDate);
                if ($this->withinTwoWeeks($needBy, $lastAlertDate) === $needWithinTwoWeeks) {
                    continue;
                }
            }

            $qualified[] = [
                'tracker_number' => (string) $candidate->tracker_number,
                'tracker_id' => (string) $candidate->tracker_id,
                'tracker_created_date' => $candidate->tracker_created_date,
                'warehouse' => (string) $candidate->warehouse,
                'logistics_coordinator_name' => trim(($candidate->logistics_coordinator_first_name ?? '').' '.($candidate->logistics_coordinator_last_name ?? '')),
                'project_specialist_name' => trim(($candidate->project_specialist_first_name ?? '').' '.($candidate->project_specialist_last_name ?? '')),
                'account_manager_name' => trim(($candidate->account_manager_first_name ?? '').' '.($candidate->account_manager_last_name ?? '')),
                'customer_name' => (string) $candidate->customer_name,
                'address_1' => (string) $candidate->address_1,
                'city' => (string) $candidate->city,
                'state' => (string) $candidate->state,
                'zip' => (string) $candidate->zip,
                'dts_total_cost' => $total,
                'previous_dts_total_cost' => $previousTotal,
                'customer_need_by_date' => $needBy?->toDateString(),
                'within_two_weeks' => $needWithinTwoWeeks,
            ];
        }

        return collect($qualified);
    }

    private function parseDate(mixed $value): ?CarbonImmutable
    {
        $value = trim((string) $value);

        return ($value === '' || $value === '0000-00-00') ? null : CarbonImmutable::parse($value)->startOfDay();
    }

    private function withinTwoWeeks(?CarbonImmutable $date, ?CarbonImmutable $dayOne): bool
    {
        return $dayOne === null || $date?->betweenIncluded($dayOne, $dayOne->addDays(14));
    }
}
