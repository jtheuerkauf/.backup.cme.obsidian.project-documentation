<?php

namespace App\Services\Email;

use App\DTO\Email\EmailAttachmentDTO;
use App\Enums\Email\EmailStatus;
use App\Jobs\Email\EmailSendFailedEscalationJob;
use App\Models\Email;
use App\Services\API\Graph\GraphApiClient;
use App\Support\Email\EmailMetadataResolver;
use Illuminate\Mail\Mailable;
use Illuminate\Support\Facades\Log;
use Throwable;

final readonly class EmailService
{
    public function __construct(
        protected GraphApiClient $graphClient,
        protected EmailMetadataResolver $metadataResolver,
    ) {}

    /**
     * Send an email using Graph API and log it.
     *
     * @param array       $context Business context for logging
     * @param null|string $from Override default from mailbox
     *
     * @throws \ReflectionException
     * @throws \Throwable
     */
    public function sendMailable(
        Mailable $mailable,
        array $context = [],
        ?string $from = null,
        bool $render = true,
    ): Email {
        $metadata = $this->metadataResolver->resolveFromMailable($mailable);

        $from ??= config('services.msgraph.from_mailbox') ?? config('mail.from.address');

        // Subject resolution (same as before)
        $subject = $mailable->subject;
        if (empty($subject) && method_exists($mailable, 'envelope')) {
            $envelope = $mailable->envelope();
            $subject = $envelope->subject;
        }
        if (empty($subject)) {
            $subject = '(no subject)';
        }

        $to = array_column($mailable->to, 'address');
        $cc = array_column($mailable->cc, 'address');
        $bcc = array_column($mailable->bcc, 'address');
        $replyTo = array_column($mailable->replyTo, 'address');
        if (empty($replyTo)) {
            $replyTo = ['no-reply@cmecorp.com'];
        }

        // Attachments
        $attachments = $this->getAllAttachments($mailable);

        // Rendering (optional)
        $bodyHtml = '';
        if ($render) {
            $bodyHtml = $mailable->render();
        }

        $emailRecord = Email::createWithBody([
            'email_type' => data_get($context, 'email_type', 'system.generic'),
            'from_email' => $from,
            'to' => $to,
            'cc' => $cc,
            'bcc' => $bcc,
            'reply_to' => $replyTo,
            'mailable' => $metadata['mailable'],
            'related_type' => $metadata['related_type'],
            'related_id' => $metadata['related_id'],
            'subject' => $subject,
            'body_html' => $bodyHtml,
            'attachments' => $attachments['metadata'] ?? [],
            'status' => EmailStatus::Processing,
            'context' => $context,
            'attempts' => 0,
        ]);

        return $this->sendEmailRecord($emailRecord, $attachments['payload'] ?? []);
    }

    /**
     * Send an existing email record.
     *
     * @param Email $email
     * @param array{
     *     name: string,
     *     content?: string,
     *     contentBytes?: string,
     *     contentId?: string,
     *     contentType?: string,
     *     isInline?: bool,
     * }[] $attachments
     *
     * @return Email
     */
    public function sendEmailRecord(Email $email, array $attachments = []): Email
    {
        $email->update(
            [
                'status' => EmailStatus::Processing,
                'last_attempted_at' => now(),
                'attempts' => $email->attempts + 1,
            ],
        );

        try {
            $this->graphClient->sendMail(
                fromMailbox: $email->from_email,
                to: $email->to,
                subject: $email->subject,
                body: $email->body_html ?? '',
                options: array_filter(
                    [
                        'cc' => $email->cc,
                        'bcc' => $email->bcc,
                        'replyTo' => $email->reply_to,
                        'importance' => $email->importance,
                        'attachments' => $attachments,
                    ],
                ),
            );

            $email->update(
                [
                    'status' => 'sent',
                    'sent_at' => now(),
                    'error_code' => null,
                    'error_message' => null,
                ],
            );
        } catch (Throwable $e) {
            $email->update(
                [
                    'status' => 'failed',
                    'error_code' => method_exists($e, 'getCode') ? $e->getCode() : null,
                    'error_message' => $e->getMessage(),
                ],
            );

            Log::error(
                "Email sending failed",
                [
                    'email_id' => $email->id,
                    'subject' => $email->subject,
                    'to' => $email->to,
                    'error' => $e->getMessage(),
                ],
            );

            // Handle escalation if needed
            $this->handleEscalation($email);

            throw $e;
        }

        return $email;
    }

    protected function getAllAttachments(Mailable $mailable): array
    {
        $metadata = [];
        $payload = [];

        // In Laravel, attachments are often stored in $mailable->attachments, $mailable->rawAttachments, etc.
        // It varies by Laravel version. For Laravel 9/10/11:

        // 1. Standard attachments added via attach()
        foreach ($mailable->attachments as $attachment) {
            // $attachment can be an array or an object depending on how it was added
            if (is_array($attachment)) {
                $file = $attachment['file'] ?? null;
                $options = $attachment['options'] ?? [];
                $name = $options['as'] ?? ($file ? basename($file) : 'attachment');
                $mime = $options['mime'] ?? ($file ? mime_content_type($file) : 'application/octet-stream');

                if ($file && file_exists($file)) {
                    $content = file_get_contents($file);
                    $metadata[] = ['name' => $name, 'contentType' => $mime, 'size' => strlen($content)];
                    $payload[] = [
                        'name' => $name,
                        'contentType' => $mime,
                        'contentBytes' => base64_encode($content),
                    ];
                }
            }
        }

        // 2. Raw attachments added via attachData()
        foreach ($mailable->rawAttachments as $attachment) {
            $data = $attachment['data'];
            $name = $attachment['name'];
            $options = $attachment['options'] ?? [];
            $mime = $options['mime'] ?? 'application/octet-stream';

            $metadata[] = ['name' => $name, 'contentType' => $mime, 'size' => strlen($data)];
            $payload[] = [
                'name' => $name,
                'contentType' => $mime,
                'contentBytes' => base64_encode($data),
            ];
        }

        return [
            'metadata' => array_map(EmailAttachmentDTO::fromArray(...), $metadata),
            'payload' => $payload,
        ];
    }

    protected function handleEscalation(Email $email): void
    {
        if ($email->attempts >= 3) {
            Log::critical(
                "CRITICAL: Email failed after multiple attempts",
                [
                    'email_id' => $email->id,
                    'subject' => $email->subject,
                    'to' => $email->to,
                    'context' => $email->context,
                ],
            );

            // Dispatch escalation job skeleton
            EmailSendFailedEscalationJob::dispatch($email);
        }
    }

    /**
     * @formatter:off
     */
    /**
     * @param list<string> $to
     * @param string $subject
     * @param string $bodyHtml
     * @param array<string, mixed> $context
     * @param null|string $from
     * @param list<string> $cc
     * @param list<string> $bcc
     * @param list<string> $replyTo
     * @param \App\DTO\Email\EmailAttachmentDTO[] $attachmentsMeta
     * @param array<string, string>[] $attachmentsPayload
     *
     * @return \App\Models\Email
     * @throws \Throwable
     */
    /**
     * @formatter:on
     */
    public function sendRendered(
        array $to,
        string $subject,
        string $bodyHtml,
        array $context = [],
        ?string $from = null,
        array $cc = [],
        array $bcc = [],
        array $replyTo = [],
        array $attachmentsMeta = [],
        array $attachmentsPayload = [],
    ): Email {
        $from ??= config('services.msgraph.from_mailbox') ?? config('mail.from.address');
        $mailable = $this->normalizeClassName(data_get($context, 'mailable'));
        $relatedType = $this->normalizeClassName(data_get($context, 'related_type'));
        $relatedId = $this->normalizeRelatedId(data_get($context, 'related_id'));

        if (empty($replyTo)) {
            $replyTo = ['no-reply@cmecorp.com'];
        }

        $emailRecord = Email::createWithBody(
            [
                'email_type' => data_get($context, 'email_type', 'system.generic'),
                'from_email' => $from,
                'to' => $to,
                'cc' => $cc,
                'bcc' => $bcc,
                'reply_to' => $replyTo,
                'mailable' => $mailable,
                'related_type' => $relatedType,
                'related_id' => $relatedId,
                'subject' => $subject ?: '(no subject)',
                'body_html' => $bodyHtml,
                'attachments' => $attachmentsMeta,
                'status' => EmailStatus::Processing,
                'context' => $context,
                'attempts' => 0,
            ],
        );

        return $this->sendEmailRecord($emailRecord, $attachmentsPayload);
    }

    private function normalizeClassName(mixed $value): ?string
    {
        if (!is_string($value)) {
            return null;
        }

        $trimmed = trim($value);

        return $trimmed === '' ? null : $trimmed;
    }

    private function normalizeRelatedId(mixed $value): ?int
    {
        if (is_int($value)) {
            return $value > 0 ? $value : null;
        }

        if (is_string($value) && ctype_digit($value)) {
            $normalized = (int)$value;

            return $normalized > 0 ? $normalized : null;
        }

        return null;
    }
}
