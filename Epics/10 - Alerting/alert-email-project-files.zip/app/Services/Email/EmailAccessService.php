<?php
declare(strict_types=1);

namespace App\Services\Email;

use App\Enums\Email\EmailType;
use App\Enums\PermissionCode;
use App\Models\User;

final readonly class EmailAccessService
{
    /**
     * @return list<EmailType>
     */
    public function allowedMailables(User $user): array
    {
        $codes = $this->getCodes($user);

        if ($this->hasAllAccess($user, $codes)) {
            return EmailType::cases();
        }

        $allowed = [];
        foreach (EmailType::cases() as $mailable) {
            if (in_array($mailable->permissionCode(), $codes, true)) {
                $allowed[] = $mailable;
            }
        }

        return $allowed;
    }

    public function canView(User $user, ?EmailType $mailable): bool
    {
        $codes = $this->getCodes($user);

        return $mailable !== null
               && ($this->hasAllAccess($user, $codes) || in_array($mailable->permissionCode(), $codes, true));
    }

    /**
     * @return list<string>
     */
    private function getCodes(User $user): array
    {
        return $user->getAllPermissions()->pluck('code')->filter()->all();
    }

    private function hasAllAccess(User $user, array $codes): bool
    {
        return in_array(PermissionCode::MailableAll->slug(), $codes, true)
               || $user->can(PermissionCode::AllAccess->slug());
    }
}
