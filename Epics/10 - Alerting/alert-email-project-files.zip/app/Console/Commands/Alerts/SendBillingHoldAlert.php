<?php

namespace App\Console\Commands\Alerts;

use App\Jobs\SendBillingHoldAlertJob;
use Illuminate\Console\Command;

class SendBillingHoldAlert extends Command
{
    protected $signature = 'alerts:send-billing-hold-over-seven-days
                            {--to=* : Override TO recipients}
                            {--cc=* : Override CC recipients}
                            {--min-days=7 : Minimum BH hold days required}
                            {--send-empty : Send email even when no rows qualify}';

    protected $description = 'Send Orders on (BH) Over 7 Days email alert';

    public function handle(): int
    {
        $to = collect($this->option('to'))
            ->map(fn ($email) => trim((string) $email))
            ->filter()
            ->values()
            ->all();

        $cc = collect($this->option('cc'))
            ->map(fn ($email) => trim((string) $email))
            ->filter()
            ->values()
            ->all();

        $minDays = (int) $this->option('min-days');
        if ($minDays < 0) {
            $minDays = 0;
        }

        dispatch(new SendBillingHoldAlertJob(
            $to ?: null,
            $cc ?: null,
            $minDays,
            (bool) $this->option('send-empty'),
        ))->onQueue('default');

        $this->info('Dispatched SendBillingHoldAlertJob');

        return self::SUCCESS;
    }
}
