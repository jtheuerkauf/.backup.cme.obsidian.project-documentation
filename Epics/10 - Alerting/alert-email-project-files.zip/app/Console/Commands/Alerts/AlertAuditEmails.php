<?php

namespace App\Console\Commands\Alerts;

use App\Mail\AlertAuditVerifyMail;
use App\Services\Alerts\Audit\AlertAuditVerificationService;
use Illuminate\Console\Command;
use Illuminate\Support\Facades\Log;
use Illuminate\Support\Facades\Mail;

class AlertAuditEmails extends Command
{
    protected $signature = 'app:alert-audit-emails';

    protected $description = 'Send emails to the owners of alerts that need review';

    public function handle(): void
    {
        $this->info('Starting Alert Audit...');
        Log::info('Alert Audit started', ['timestamp' => now()]);

        $allAlertsToSend = app(AlertAuditVerificationService::class)->handleAudit();

        $emailsSent = 0;
        $alertsAudited = 0;

        foreach ($allAlertsToSend as $email => $alerts) {
            Mail::to($email)->queue(new AlertAuditVerifyMail($alerts));

            $emailsSent++;
            $alertsAudited += count($alerts);
        }

        $this->info('Alert Audit Completed. Emails sent: ' . $emailsSent . '. Alerts Audited: ' . $alertsAudited);
        Log::info('Alert Audit complete', [
            'emails_sent' => $emailsSent,
            'alerts_audited' => $alertsAudited,
            'timestamp' => now(),
        ]);
    }
}
