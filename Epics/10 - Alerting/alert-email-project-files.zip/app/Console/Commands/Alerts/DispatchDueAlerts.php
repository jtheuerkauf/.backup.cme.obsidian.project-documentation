<?php

namespace App\Console\Commands\Alerts;

use App\Enums\Alerts\AlertType;
use App\Enums\ProcessStatus;
use App\Models\Alerts\AlertRun;
use App\Models\Alerts\AlertSchedule;
use App\Services\Alerts\AlertRunner;
use Carbon\CarbonImmutable;
use Cron\CronExpression;
use Illuminate\Console\Command;
use Illuminate\Database\Eloquent\Builder;
use Illuminate\Support\Facades\DB;
use Illuminate\Database\ConfigurationUrlParser;
use Symfony\Component\Console\Input\InputOption;

class DispatchDueAlerts extends Command
{
    protected $signature = <<<'SIG'
                  alerts:dispatch-due
                      {--dry-run : Preview matching due schedules without executing}
                      {--test : Run fully with a test recipient; requires local/testing, loopback write hosts, and a non-Graph mailer}
                  SIG;

    protected $description = 'Dispatch due alert schedules or preview their candidates and recipients.';

    protected $help = <<<'TXT'
                  --alert    Run only schedules for one alert-type-slug: --alert <alert-type-slug>
                  --dry-run  preview due schedules without writes or delivery.
                  --test     Perform a full run with a generated recipient. It is limited to local/testing,'
                             requires localhost or 127.0.0.1 hosts for the NewRivers and AllRivers write connections,
                             and refuses the MS Graph mailer.
                             For local email testing, configure MAIL_MAILER=smtp and point SMTP at Mailpit.
                  TXT;

    public function __construct()
    {
        parent::__construct();

        $this->addOption('alert', null, InputOption::VALUE_REQUIRED, 'Run only schedules for one alert-type-slug');
    }

    public function handle(AlertRunner $runner): int
    {
        $alertSlug = $this->option('alert');
        if ($alertSlug === '') {
            $this->error('The --alert option requires a non-empty alert type slug.');

            return self::INVALID;
        }
        if (!($alertSlug === null || $this->isAlertTypeSlug($alertSlug))) {
            $this->error("Unknown AlertType slug [$alertSlug].");

            return self::INVALID;
        }

        if ($this->option('test') && !($this->option('dry-run') || $this->testModeIsSafe())) {
            return self::FAILURE;
        }

        $schedules = AlertSchedule::with('alert')->due()->orderBy('id');
        if ($alertSlug) {
            $schedules->whereHas(
                'alert',
                fn(Builder $query): Builder => $query->where('type_key', $alertSlug),
            );
        }

        if ($this->option('dry-run')) {
            $scheduleCount = 0;
            $skippedCount = 0;
            $recipientCount = 0;
            $candidateCount = 0;
            $schedules->each(
            /**
             * @formatter:off
             */
                function(AlertSchedule $schedule) use (
                    $runner,
                    &$scheduleCount,
                    &$skippedCount,
                    &$recipientCount,
                    &$candidateCount,
                ): void {
                    /**
                     * @formatter:on
                     */
                    $preview = $runner->preview($schedule);
                    $count = $runner->recipientCount($schedule->alert, $this->option('test'));
                    $scheduleCount++;
                    $recipientCount += $count;
                    $candidateCount += $preview->count();
                    $this->info($schedule->alert->name);
                    $this->line("{$schedule->alert->name}: $count recipient(s)");

                    if ($count === 0) {
                        $skippedCount++;
                        $this->line('Delivery skipped: no deliverable recipients.');
                    }

                    if ($preview->headers !== []) {
                        $this->table($preview->headers, $preview->rows);
                    }
                },
            );
            $this->info(
                "Dry run: {$scheduleCount} due schedule(s), {$skippedCount} skipped for no recipients, "
                . "{$candidateCount} alert candidate(s), "
                . "{$recipientCount} recipient(s); no writes or delivery.",
            );

            return self::SUCCESS;
        }

        $schedules->each(
            function(AlertSchedule $schedule) use ($runner): void
            {
                $run = DB::transaction(
                    function() use ($schedule): ?AlertRun
                    {
                        $schedule = AlertSchedule::query()->lockForUpdate()->find($schedule->id);
                        if ($schedule === null
                            || !$schedule->isEnabled()
                            || ($schedule->next_run_at?->isFuture() ?? true)
                        ) {
                            return null;
                        }

                        $scheduledFor = $schedule->next_run_at;
                        $nextRunAt = CarbonImmutable::instance(
                            (new CronExpression($schedule->schedule_definition))
                                ->getNextRunDate($scheduledFor, 0, false, $schedule->timezone),
                        );
                        $schedule->update(['next_run_at' => $nextRunAt]);

                        /**
                         * @formatter:off
                         */
                        return AlertRun::create([
                            'alert_id' => $schedule->alert_id,
                            'alert_schedule_id' => $schedule->id,
                            'scheduled_for' => $scheduledFor,
                            'status' => ProcessStatus::Queued,
                            'idempotency_key' => "schedule:{$schedule->id}:{$scheduledFor->toIso8601String()}",
                        ]);
                        /**
                         * @formatter:onff
                         */
                    },
                );
                if ($run !== null) {
                    $runner->run($run, $this->option('test'));
                }
            },
        );

        return self::SUCCESS;
    }

    private function isAlertTypeSlug(string $slug): bool
    {
        foreach (AlertType::cases() as $type) {
            if ($type->slug() === $slug) {
                return true;
            }
        }

        return false;
    }

    private function testModeIsSafe(): bool
    {
        if (!app()->environment(['local', 'testing'])) {
            $this->error('The --test option is only available in the local or testing environment.');

            return false;
        }

        foreach (['NewRivers' => 'mysql', 'AllRivers' => 'allrivers'] as $system => $connectionName) {
            $host = DB::connection($connectionName)->getConfig('host');
            if (!in_array(strtolower(trim((string) $host)), ['localhost', '127.0.0.1'], true)) {
                $this->error(
                    sprintf('The --test option requires the %s write connection host to be localhost or 127.0.0.1.', $system),
                );

                return false;
            }
        }

        if (config('mail.default') === 'msgraph') {
            $this->error('The --test option cannot use the MS Graph mailer. Configure SMTP to use Mailpit.');

            return false;
        }

        return true;
    }
}
