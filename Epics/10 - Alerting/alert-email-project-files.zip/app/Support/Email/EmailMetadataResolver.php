<?php

namespace App\Support\Email;

use App\Enums\Email\EmailType;
use App\Mail\Interfaces\TypedMailable;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Mail\Mailable;
use Illuminate\Support\Collection;
use Traversable;

class EmailMetadataResolver
{
    /**
     * @return array{mailable: ?string, related_type: ?string, related_id: ?int}
     */
    public function resolveFromMailable(Mailable $mailable): array
    {
        try {
            $data = $mailable->buildViewData();
        } catch (\Throwable) {
            $data = ['__laravel_mailable' => get_class($mailable)];
        }

        $metadata = $this->resolveFromData($data);
        if ($mailable instanceof TypedMailable) {
            $metadata['mailable'] = $mailable->emailType()->value;
            $metadata['related_type'] = $mailable->relatedType();
            $metadata['related_id'] = $mailable->relatedId();
        }

        return $metadata;
    }

    /**
     * @param array<string, mixed> $data
     * @return array{mailable: ?string, related_type: ?string, related_id: ?int}
     */
    public function resolveFromData(array $data): array
    {
        $mailableClass = $this->normalizeClassName($data['__laravel_mailable'] ?? null);
        $mailable = $mailableClass ? EmailType::fromMailableClass($mailableClass)?->value : null;
        $relatedModel = $this->findFirstModel($data);

        return [
            'mailable' => $mailable,
            'related_type' => $relatedModel ? $relatedModel::class : null,
            'related_id' => $relatedModel ? $this->normalizeRelatedId($relatedModel->getKey()) : null,
        ];
    }

    private function findFirstModel(mixed $value, int $depth = 0): ?Model
    {
        if ($depth > 5) {
            return null;
        }

        if ($value instanceof Model) {
            return $value;
        }

        if ($value instanceof Collection) {
            foreach ($value as $item) {
                $model = $this->findFirstModel($item, $depth + 1);

                if ($model !== null) {
                    return $model;
                }
            }

            return null;
        }

        if ($value instanceof Traversable) {
            foreach ($value as $item) {
                $model = $this->findFirstModel($item, $depth + 1);

                if ($model !== null) {
                    return $model;
                }
            }

            return null;
        }

        if (!is_array($value)) {
            return null;
        }

        foreach ($value as $key => $item) {
            if (in_array($key, ['__laravel_mailable', 'mailer', 'message'], true)) {
                continue;
            }

            $model = $this->findFirstModel($item, $depth + 1);

            if ($model !== null) {
                return $model;
            }
        }

        return null;
    }

    private function normalizeClassName(mixed $value): ?string
    {
        if (!is_string($value)) {
            return null;
        }

        $trimmed = trim($value);

        return $trimmed === '' ? null : $trimmed;
    }

    private function normalizeRelatedId(mixed $value): ?int
    {
        if (is_int($value)) {
            return $value > 0 ? $value : null;
        }

        if (is_string($value) && ctype_digit($value)) {
            $normalized = (int) $value;

            return $normalized > 0 ? $normalized : null;
        }

        return null;
    }
}
