<?php
declare(strict_types=1);

namespace App\View\Emails\Alerts;

use App\Enums\Alerts\AlertType;
use App\Enums\Email\EmailType;
use App\Models\Alerts\AlertRun;
use App\Services\Alerts\AlertsRegistry;
use App\View\Emails\EmailView;

final readonly class DtsOver20kAlert implements EmailView
{
    public function __construct(private AlertsRegistry $registry) {}

    public function emailType(): EmailType
    {
        return EmailType::DTSOver20kAlert;
    }

    public function template(): string
    {
        return 'emails.alerts.dts-over-20k';
    }

    public function subject(AlertRun $run): string
    {
        return $this->registry->mailSubject(AlertType::DtsOver20k);
    }
}
