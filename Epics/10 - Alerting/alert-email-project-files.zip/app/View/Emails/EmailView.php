<?php
declare(strict_types=1);

namespace App\View\Emails;

use App\Enums\Email\EmailType;
use App\Models\Alerts\AlertRun;

interface EmailView
{
    public function emailType(): EmailType;

    public function template(): string;

    public function subject(AlertRun $run): string;
}
