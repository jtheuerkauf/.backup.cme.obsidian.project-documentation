<?php

namespace App\Models;

use App\Enums\Users\JobCodes\ITJobCodes;
use App\Models\Datasync\AdpUser;
use App\Services\DataManagement\DataManagementTableConfig;
use Database\Factories\UserFactory;
use Illuminate\Database\Eloquent\Builder;
use Illuminate\Database\Eloquent\Collection;
use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Relations\BelongsToMany;
use Illuminate\Database\Eloquent\Relations\HasMany;
use Illuminate\Database\Eloquent\Relations\HasOne;
use Illuminate\Foundation\Auth\User as Authenticatable;
use Illuminate\Notifications\Notifiable;
use Laravel\Sanctum\HasApiTokens;
use LdapRecord\Laravel\Auth\AuthenticatesWithLdap;
use LdapRecord\Laravel\Auth\LdapAuthenticatable;
use Spatie\Permission\Traits\HasRoles;
use Throwable;

/**
 * @property int id
 * @property string name
 * @property string email
 * @property bool is_synthetic_user
 * @property int|null become_actor_user_id
 * @property string|null password
 * @property string|null guid
 * @property-read null|AdpUser adpUser
 * @property-read Collection<int, Department> departments
 *
 * @mixin Builder
 * @mixin UserFactory
 */
class User extends Authenticatable implements LdapAuthenticatable
{
    use AuthenticatesWithLdap;
    use HasApiTokens;
    use HasFactory;
    use HasRoles;
    use Notifiable;

    /**
     * @var list<string>
     */
    protected $fillable = [
        'name',
        'email',
        'is_synthetic_user',
        'become_actor_user_id',
        'password',
        'guid',
        'aplus_rep_id',
        'cpq_pod',
        'order_lookup_all_access',
        'legacy_cpq_created_at',
        'legacy_cpq_updated_at',
        'cpq_permissions_synced_at',
    ];

    /**
     * The attributes that should be hidden for serialization.
     *
     * @var list<string>
     */
    protected $hidden = [
        'password',
        'remember_token',
    ];

    /**
     * Get the attributes that should be cast.
     *
     * @return array<string, string>
     */
    protected function casts(): array
    {
        return [
            'is_synthetic_user' => 'boolean',
            'become_actor_user_id' => 'integer',
            'password' => 'hashed',
            'aplus_rep_id' => 'integer',
            'cpq_pod' => 'integer',
            'order_lookup_all_access' => 'boolean',
            'legacy_cpq_created_at' => 'datetime',
            'legacy_cpq_updated_at' => 'datetime',
            'cpq_permissions_synced_at' => 'datetime',
        ];
    }

    /**
     * Get the user's initials.
     *
     * This method extracts the first letter of each part of the user's name,
     * combines them, and returns them as uppercase initials.
     */
    public function initials(): string
    {
        $parts = explode(' ', $this->name);
        $initials = collect($parts)
            ->filter()
            ->map(fn ($part) => mb_substr($part, 0, 1))
            ->join('');

        return strtoupper($initials);
    }

    public function departments(): BelongsToMany|Department
    {
        return $this->belongsToMany(Department::class, 'department_users')
            ->withPivot('is_manager');
    }

    public function individualPermissions(): BelongsToMany|Permission
    {
        return $this->belongsToMany(Permission::class, 'model_has_permissions', 'model_id', 'permission_id');
    }

    public function orderAccessDelegations(): HasMany
    {
        return $this->hasMany(UserOrderAccessDelegation::class, 'user_id');
    }

    public function delegatedOrderAccessUsers(): BelongsToMany
    {
        return $this->belongsToMany(
            self::class,
            'user_order_access_delegations',
            'user_id',
            'delegated_user_id',
        )->withTimestamps();
    }

    public function orderAccessCustomerGrants(): HasMany
    {
        return $this->hasMany(UserOrderAccessCustomerGrant::class, 'user_id');
    }

    public function orderAccessIdnGrants(): HasMany
    {
        return $this->hasMany(UserOrderAccessIdnGrant::class, 'user_id');
    }

    public function gitLabCommitEmails(): HasMany
    {
        return $this->hasMany(GitLabDeveloperCommitEmail::class);
    }

    public function gitLabWorkSummaries(): HasMany
    {
        return $this->hasMany(GitLabDeveloperWorkSummary::class);
    }

    public function adpUser(): HasOne|AdpUser
    {
        $adpUser = $this->hasOne(AdpUser::class, 'work_email', 'email');
        /*
         * TEMPORARY SHIM for #521
         */
        if (! $adpUser->exists()) {
            $emailUser = array_first(explode('@', $this->email));
            $alternateEmail = $emailUser.'@storagesystemsul.com';
            $alternateUser = (clone $this)->fill(['email' => $alternateEmail]);
            $adpUser = $this->newHasOne(AdpUser::query(), $alternateUser, 'work_email', 'email');
        }

        // END SHIM

        return $adpUser;
    }

    public function inDepartment(Department $department): bool
    {
        return $this->departments()->where('department_id', $department->id)->exists();
    }

    public function isIT(): bool
    {
        $itCodes = array_map(static fn (ITJobCodes $code) => $code->value, ITJobCodes::cases());

        return $this->departments()->whereIn('code', $itCodes)->exists()
            || $this->hasRole('Super Admin');
    }

    public function isProjectSpecialist(): bool
    {
        return $this->adpUserOrNull()?->isProjectSpecialist() ?? false;
    }

    public function canAccessPmHubDirectLineImporter(): bool
    {
        return $this->hasRole('Super Admin') || $this->isProjectSpecialist();
    }

    public function canAccessPoSubmissions(): bool
    {
        if ($this->isIT()) {
            return true;
        }

        return $this->adpUserOrNull()?->canAccessPoSubmissions() ?? false;
    }

    public function isDirector(): bool
    {
        return $this->adpUserOrNull()?->isDirector() ?? false;
    }

    public function canAccessDataManagementAdmin(): bool
    {
        return $this->hasRole('Super Admin')
            || $this->can('all-access')
            || $this->isIT();
    }

    public function canAccessDataManagement(): bool
    {
        return app(DataManagementTableConfig::class)->userCanAccessAnyTable($this);
    }

    private function adpUserOrNull(): ?AdpUser
    {
        try {
            return $this->relationLoaded('adpUser')
                ? $this->getRelation('adpUser')
                : $this->adpUser()->first();
        } catch (Throwable) {
            return null;
        }
    }
}
