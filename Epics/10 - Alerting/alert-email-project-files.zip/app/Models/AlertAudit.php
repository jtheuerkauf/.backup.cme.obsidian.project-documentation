<?php

namespace App\Models;

use Carbon\Carbon;
use App\Models\AllRivers\DimReporting;
use App\Models\AllRivers\AlertTracking;
use Illuminate\Database\Eloquent\Model;
use App\Traits\Models\ConnectionInTestingEnv;
use Illuminate\Database\Eloquent\Relations\HasMany;
use Illuminate\Database\Eloquent\Factories\HasFactory;

/**
 * @property integer id
 * @property string name
 * @property string cadence_in_days
 * @property Carbon last_verified
 * @property Carbon created_at
 * @property Carbon updated_at
 */
class AlertAudit extends Model
{
    use HasFactory, ConnectionInTestingEnv;

    protected $fillable = [
        'name',
        'cadence_in_days',
        'last_verified',
    ];

    protected $casts = [
        'last_verified' => 'date',
    ];

    public function auditVerifications(): HasMany
    {
        return $this->hasMany(AlertAuditVerification::class, 'name', 'name');
    }

    public function alertTracking(): HasMany
    {
        return $this->hasMany(AlertTracking::class, 'name', 'name');
    }

    public function dimReporting(): HasMany
    {
        return $this->hasMany(DimReporting::class, 'name', 'name');
    }
}
