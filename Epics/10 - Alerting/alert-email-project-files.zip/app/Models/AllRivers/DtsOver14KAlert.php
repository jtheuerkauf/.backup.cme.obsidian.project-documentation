<?php
declare(strict_types=1);

namespace App\Models\AllRivers;

use Illuminate\Database\Eloquent\Model;

final class DtsOver14KAlert extends Model
{
    protected $connection = 'allrivers';
    protected $table = 'dtsOver14KAlert';
    protected $primaryKey = 'trackerNumber';

    public $incrementing = false;
    public $timestamps = false;

    protected $keyType = 'string';
}
