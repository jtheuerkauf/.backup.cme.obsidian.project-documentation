<?php

namespace App\Models\AllRivers;

use App\Models\AlertAudit;
use App\Models\AlertAuditVerification;
use Carbon\Carbon;
use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Relations\HasMany;

/**
 * @property string category
 * @property string name
 * @property string displayName
 * @property string description
 * @property string frequency
 * @property string ownerEmail
 * @property string requestorEmail
 * @property Carbon createdDate
 */
class DimReporting extends Model
{
    use HasFactory;

    protected $connection = 'allrivers';
    protected $table = 'dimReporting';
    protected $primaryKey = null;
    public $incrementing = false;
    public $timestamps = false;

    protected $fillable = [
        'name',
        'ownerEmail',
        'requestorEmail',
        'displayName',
        'createdDate',
    ];

    protected $casts = [
        'createdDate' => 'date',
    ];

    public function alertTracking(): HasMany
    {
        return $this->hasMany(AlertTracking::class, 'name', 'name');
    }

    public function alertAudits(): HasMany
    {
        return $this->hasMany(AlertAudit::class, 'name', 'name');
    }

    public function auditVerifications(): HasMany
    {
        return $this->hasMany(AlertAuditVerification::class, 'name', 'name');
    }
}
