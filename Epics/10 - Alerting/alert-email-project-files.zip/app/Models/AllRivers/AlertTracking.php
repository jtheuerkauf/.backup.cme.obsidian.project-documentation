<?php

namespace App\Models\AllRivers;

use App\Models\AlertAudit;
use App\Models\AlertAuditVerification;
use Carbon\Carbon;
use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Relations\HasMany;

/**
 * @property string name
 * @property integer runCount
 * @property integer totalRunCount
 * @property integer lineCount
 * @property Carbon runDate
 * @property Carbon lastUpdate
 */
class AlertTracking extends Model
{
    use HasFactory;

    protected $connection = 'allrivers';
    protected $table = 'alertTracking';
    protected $primaryKey = null;
    public $incrementing = false;
    public $timestamps = false;

    protected $fillable = ['name', 'runDate'];

    protected $casts = [
        'runDate' => 'date',
        'lastUpdate' => 'date',
    ];

    public function dimReporting(): HasMany
    {
        return $this->hasMany(DimReporting::class, 'name', 'name');
    }

    public function alertAudits(): HasMany
    {
        return $this->hasMany(AlertAudit::class, 'name', 'name');
    }

    public function auditVerifications(): HasMany
    {
        return $this->hasMany(AlertAuditVerification::class, 'name', 'name');
    }
}
