<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Relations\BelongsTo;
use Illuminate\Support\Str;
use Spatie\Permission\Contracts\Permission as SpatiePermissionType;
use Spatie\Permission\Exceptions\PermissionDoesNotExist;
use Spatie\Permission\Models\Permission as SpatiePermission;

/**
 * @mixin \Illuminate\Database\Eloquent\Model
 */
class Permission extends SpatiePermission
{
    use HasFactory;

    public static function findByCode(string $code, $guardName = null): SpatiePermission
    {
        $guardName = $guardName ?? config('auth.defaults.guard');

        $permission = static::where('guard_name', $guardName)
                            ->where(
                                fn($query) => $query
                                    ->where('code', '=', $code)
                                    ->orWhere('name', '=', $code),
                            )->first();

        if (!$permission) {
            throw PermissionDoesNotExist::create($code, $guardName);
        }

        return $permission;
    }

    public static function findByName(string $name, $guardName = null): SpatiePermission
    {
        $guardName = $guardName ?? config('auth.defaults.guard');

        return static::findByCode($name, $guardName);
    }

    public static function createPerms(
        string $name,
        bool $is_crud = false,
        $department = 0,
    ): SpatiePermissionType|array|SpatiePermission {
        $code = Str::slug($name, '-');

        if ($is_crud) {
            $crud_operations = ['create', 'read', 'update', 'delete'];
            $permissions = [];

            foreach ($crud_operations as $operation) {
                $operation_name = ucfirst($operation);
                $insert = [
                    'name' => "{$operation_name} {$name}",
                    'code' => "{$operation}-{$code}",
                    'guard_name' => config('auth.defaults.guard'),
                ];

                if ($department) {
                    $insert['department_id'] = $department;
                }

                $permissions[] = static::create($insert);
            }

            return $permissions;
        }

        $insert = [
            'name' => $name,
            'code' => $code,
            'guard_name' => config('auth.defaults.guard'),
        ];

        if ($department) {
            $insert['department_id'] = $department;
        }

        return static::create($insert);
    }

    public function department(): BelongsTo|Department
    {
        return $this->belongsTo(Department::class);
    }
}
