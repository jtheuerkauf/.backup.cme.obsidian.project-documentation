<?php

namespace App\Models;

use App\DTO\Email\EmailAttachmentDTO;
use App\Enums\Email\EmailStatus;
use App\Enums\Email\EmailType;
use App\Models\Alerts\AlertRun;
use App\Traits\Normalizers\EmailTextNormalizer;
use Illuminate\Database\Eloquent\Attributes\Scope;
use Illuminate\Database\Eloquent\Builder;
use Illuminate\Database\Eloquent\Casts\Attribute;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Relations\BelongsTo;
use Illuminate\Database\Eloquent\Relations\MorphTo;
use SortDirection;

/**
 * @formatter:off
 */
/**
 * @property non-negative-int $id
 * @property string $email_type
 * @property EmailType|null $mailable
 * @property class-string<Model> $related_type // These Models need a common type: abstract ancestor or interface
 * @property non-negative-int $related_id
 * @property-read Model $relatedRecord {@see relatedRecord()}
 * @property-read AlertRun|null $alert_run {@see alertRun()}
 * @property-read ModelActionLog $modelActionLog {@see modelActionLog()}
 * @property User $generatedBy {@see generatedBy()}
 * @property string<email> $from_email
 * @property string<email>[] $to
 * @property string<email>[] $cc
 * @property string<email>[] $bcc
 * @property string<email>[] $reply_to
 * @property string $subject
 * @property null|string $subject_search
 * @property null|string<html> $body_html
 * @property null|string $body_search
 * @property EmailAttachmentDTO[] $attachments
 * @property string $message_id
 * @property EmailStatus $status
 * @property non-negative-int $attempts
 * @property non-negative-int $error_code
 * @property string $error_message
 * @property object $context
 * @property-read \DateTimeImmutable $latest_update
 * @property \DateTimeImmutable $queued_at
 * @property \DateTimeImmutable $last_attempted_at
 * @property \DateTimeImmutable $sent_at
 * @property string dedupe_key
 * @property ??? importance
 *
 * @method static forStatus(EmailStatus $status)
 *
 * @mixin Builder<Email>
 */
/**
 * @formatter:on
 */
class Email extends Model
{
    use EmailTextNormalizer;

    protected $fillable = [
        'provider',
        'email_type',
        'mailable',
        'related_type',
        'related_id',
        'generated_by_id',
        'model_action_log_id',
        'from_email',
        'to',
        'cc',
        'bcc',
        'reply_to',
        'subject',
        'body_html',
        'importance',
        'attachments',
        'message_id',
        'dedupe_key',
        'status',
        'queued_at',
        'attempts',
        'last_attempted_at',
        'sent_at',
        'error_code',
        'error_message',
        'context',
    ];

    protected $guarded = [
        'body_search',
        'subject_search',
    ];

    protected function casts(): array
    {
        return [
            'to' => 'json',
            'cc' => 'json',
            'bcc' => 'json',
            'reply_to' => 'json',
            'context' => 'json',
            'related_id' => 'int',
            'generated_by_id' => 'int',
            'model_action_log_id' => 'int',
            'queued_at' => 'datetime',
            'last_attempted_at' => 'datetime',
            'sent_at' => 'datetime',
            'status' => EmailStatus::class,
            'mailable' => EmailType::class,
        ];
    }

    public static function createWithBody(array $attributes): static
    {
        $email = new static($attributes);
        $email->body_search = $email->normalizeBody($email->body_html);
        $email->subject_search = $email->normalizeSubject($email->subject);
        $email->save();

        return $email;
    }

    /**
     * @noinspection PhpUnused
     * @todo The Models in emails must have something in common, right?
     *       They should get an interface so relatedRecord can be typed.
     */
    public function relatedRecord(): MorphTo
    {
        return $this->morphTo(__FUNCTION__, 'related_type', 'related_id');
    }

    protected function alertRun(): Attribute
    {
        return Attribute::get(function (): ?AlertRun {
            if ($this->related_type !== (new AlertRun)->getMorphClass()) {
                return null;
            }

            $related = $this->relatedRecord;

            return $related instanceof AlertRun ? $related : null;
        });
    }

    /**
     * @noinspection PhpUnused
     */
    public function generatedBy(): BelongsTo|User
    {
        return $this->belongsTo(User::class, 'generated_by_id');
    }

    /**
     * @noinspection PhpUnused
     */
    public function modelActionLog(): BelongsTo|ModelActionLog
    {
        return $this->belongsTo(ModelActionLog::class, 'model_action_log_id');
    }

    protected function attachments(): Attribute
    {
        /*
         * TODO Make DTO objects like this into cast-classes. For plurality, create *Set classes.
         *      Lighter weight than Collections, directly typed data instead of inferred from comments.
         */
        return Attribute::make(
            get: fn () => array_map(
                static fn (mixed $attachment): EmailAttachmentDTO => EmailAttachmentDTO::fromArray(
                    is_array($attachment) ? $attachment : [],
                ),
                $this->fromJson($this->attributes['attachments']),
            ),
            set: fn (array $value) => $this->attributes['attachments']
                = $this->asJson(
                    array_map(
                        fn (array|EmailAttachmentDTO $dto) => is_array($dto) ? $dto : $dto->toArray(),
                        $value,
                    ),
                ),
        )->shouldCache();
    }

    /**
     * @noinspection PhpUnused
     */
    protected function latestUpdate(): Attribute
    {
        // It's either sent, attempted/failed, or queued (not attempted)
        return Attribute::make(
            get: fn () => $this->sent_at ?? $this->last_attempted_at ?? $this->queued_at,
        )->shouldCache();
    }

    /**
     * @noinspection PhpUnused
     */
    #[Scope]
    protected function forStatus(Builder $query, EmailStatus $status): void
    {
        $query->where('status', $status);
    }

    /**
     * @noinspection PhpUnused
     */
    #[Scope]
    protected function orderByLatestUpdate(Builder $query, SortDirection $sort): void
    {
        $query->orderBy('status', $sort === SortDirection::Ascending ? 'asc' : 'desc');
    }
}
