<?php

namespace App\Models\Datasync;

use App\Enums\Users\JobCodes\BillingJobCodes;
use App\Enums\Users\JobCodes\CSRJobCodes;
use App\Enums\Users\JobCodes\SalesJobCodes;
use Illuminate\Database\Eloquent\Attributes\Scope;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Relations\BelongsTo;
use Illuminate\Database\Query\Builder;

class AdpUser extends Model
{
    protected $connection = 'datasync';
    protected $table = 'adpUsers';
    protected $primaryKey = 'worker_id';
    public $incrementing = false;
    public const DIRECTOR_DEPARTMENT_CODES = ['009'];
    public const DIRECTOR_JOB_CODES = ['VPSS', 'CDNA', 'DSRS', 'DSSA', 'DNERS', 'DWRS', 'DOS', 'DNYCS', 'DMWS', 'DSSE'];
    public const ACCOUNT_MANAGERS_PROJECT_MANAGERS = ['ACCM', 'PROM'];
    public const PO_SUBMISSION_SUPPORT_JOB_CODES = [
        'ACTS',
        'CSR',
        'LCSR',
        'GS',
        'CDCSP',
        'CSM',
        'WSL',
        'WCSS',
        'DCEM',
        'VPAO',
        'CDNA',
    ];
    public const PO_SUBMISSION_ACCESS_JOB_TITLE_KEYWORDS = [
        'sale',
        'Account Specialist',
        'HCA Account Manager',
        'Government Account Manager',
    ];

    public const PROJECT_SPECIALIST_JOB_CODES = [
        "PROS",
        "PSM",
    ];

    protected $fillable = [
        'worker_id',
        'associate_oid',
        'first_name',
        'last_name',
        'full_name',
        'preferred_name',
        'gender',
        'ethnicity',
        'race',
        'military',
        'state',
        'zip_code',
        'work_email',
        'phone',
        'status',
        'hire_date',
        'termination_date',
        'job_title',
        'job_code',
        'position_id',
        'worker_type',
        'is_salary',
        'payroll_group',
        'payroll_file_number',
        'reports_to_name',
        'reports_to_id',
        'business_unit_code',
        'business_unit_name',
        'department_code',
        'department_name',
        'default_warehouse',
    ];

    protected $casts = [
        'hire_date' => 'date',
        'termination_date' => 'date',
        'created_at' => 'datetime',
        'updated_at' => 'datetime',
    ];

    /**
     * Normalize and lookup an ADP user by email.
     */
    public static function findByEmail(?string $email): ?self
    {
        if (!$email) {
            return null;
        }

        return static::where('work_email', strtolower(trim($email)))->first();
    }

    public function manager(): BelongsTo|self
    {
        return $this->belongsTo(self::class, 'reports_to_id', 'worker_id');
    }

    public function isDirector(): bool
    {
        return ($this->status ?? '') === 'Active'
               && (in_array((string)$this->department_code, self::DIRECTOR_DEPARTMENT_CODES, true)
                   || in_array((string)$this->job_code, self::DIRECTOR_JOB_CODES, true));
    }

    public function isCustomerServiceRep(): bool
    {
        return $this->hasCsrJobCode()
               || in_array(
                   $this->job_code,
                   ['GS', 'CDCSP', 'WSL', 'WCSS', 'DCEM', 'VPAO', 'ACCM', 'KAM', 'ACTS'],
                   true,
               );
    }

    public static function isInCsrJobCodeList(?string $jobCode): bool
    {
        return in_array((string)$jobCode, CSRJobCodes::values(), true);
    }

    public function hasCsrJobCode(): bool
    {
        return self::isInCsrJobCodeList($this->job_code);
    }

    public function hasPoSubmissionAccessJobCode(): bool
    {
        $jobCode = (string)$this->job_code;

        return in_array($jobCode, SalesJobCodes::values(), true)
               || in_array($jobCode, self::PO_SUBMISSION_SUPPORT_JOB_CODES, true);
    }

    public function hasPoSubmissionAccessJobTitle(): bool
    {
        $jobTitle = strtolower((string)$this->job_title);

        foreach (self::PO_SUBMISSION_ACCESS_JOB_TITLE_KEYWORDS as $keyword) {
            if (str_contains($jobTitle, strtolower($keyword))) {
                return true;
            }
        }

        return false;
    }

    public function canAccessPoSubmissions(): bool
    {
        return ($this->status ?? '') === 'Active'
               && ($this->hasPoSubmissionAccessJobCode() || $this->hasPoSubmissionAccessJobTitle());
    }

    public function isPoSubmissionSalesStaff(): bool
    {
        return ($this->status ?? '') === 'Active'
               && in_array((string)$this->job_code, SalesJobCodes::values(), true);
    }

    public function isBilling(): bool
    {
        return $this->department_code === BillingJobCodes::DEPARTMENT->value;
    }

    public function isProjectSpecialist(): bool
    {
        return in_array($this->job_code, self::PROJECT_SPECIALIST_JOB_CODES, true);
    }

    #[Scope]
    protected function directors($query)
    {
        return $query
            ->where('status', 'Active')
            ->where(
                fn(Builder $nested) => $nested
                    ->whereIn('department_code', self::DIRECTOR_DEPARTMENT_CODES)
                    ->orWhereIn('job_code', self::DIRECTOR_JOB_CODES),
            );
    }
}
