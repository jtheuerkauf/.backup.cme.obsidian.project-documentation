<?php

namespace App\Models\Alerts;

use App\DTO\Alerts\AlertDataConfig;
use App\Enums\Alerts\ScheduleType;
use Illuminate\Database\Eloquent\Attributes\Scope;
use Illuminate\Database\Eloquent\Builder;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Relations\BelongsTo;

/**
 * @property int $id
 * @property int $alert_id
 * @property Alert $alert
 * @property ScheduleType $schedule_type
 * @property string $schedule_definition
 * @property string $timezone
 * @property array<string, mixed> $data_params
 * @property string $data_params_hash
 * @property null|\Carbon\CarbonInterface $next_run_at
 * @property null|\Carbon\CarbonInterface $enabled_at
 * @property null|\Carbon\CarbonInterface $disabled_at
 * @method static self|Builder due()
 * @method static self|Builder query()
 *
 * @mixin Builder<AlertSchedule>
 */
final class AlertSchedule extends Model
{
    protected $fillable = [
        'schedule_type',
        'schedule_definition',
        'timezone',
        'data_params',
        'next_run_at',
        'enabled_at',
        'disabled_at',
    ];

    protected static function booted(): void
    {
        static::saving(
            static function(self $schedule): void
            {
                $schedule->data_params_hash = self::dataParamsHash($schedule->data_params);
            },
        );
    }

    protected function casts(): array
    {
        return [
            'schedule_type' => ScheduleType::class,
            'data_params' => 'array',
            'next_run_at' => 'datetime',
            'enabled_at' => 'datetime',
            'disabled_at' => 'datetime',
        ];
    }

    public function alert(): BelongsTo|Alert
    {
        return $this->belongsTo(Alert::class);
    }

    public function isEnabled(): bool
    {
        return $this->disabled_at === null && $this->enabled_at !== null;
    }

    public function dataConfig(Alert $alert): AlertDataConfig
    {
        return new AlertDataConfig($alert->source_config->source, $this->data_params);
    }

    /**
     * @param array<string, mixed> $dataParams
     *
     * @throws \JsonException
     */
    public static function dataParamsHash(array $dataParams): string
    {
        return hash('sha256', json_encode(self::canonicalize($dataParams), JSON_THROW_ON_ERROR));
    }

    private static function canonicalize(mixed $value): mixed
    {
        if (!is_array($value)) {
            return $value;
        }

        $value = array_map(self::canonicalize(...), $value);
        if (!array_is_list($value)) {
            ksort($value);
        }

        return $value;
    }

    #[Scope]
    protected function due(Builder $query): void
    {
        $query
            ->whereNotNull('enabled_at')
            ->whereNull('disabled_at')
            ->where('next_run_at', '<=', now());
    }
}
