<?php

namespace App\Models\Alerts;

use App\Enums\ProcessStatus;
use App\Models\Email;
use Carbon\CarbonInterface;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Relations\BelongsTo;
use Illuminate\Database\Eloquent\Relations\MorphMany;

/**
 * @property int $id
 * @property int $alert_id
 * @property int $alert_schedule_id
 * @property-read Alert $alert
 * @property-read AlertSchedule $schedule
 * @property CarbonInterface $scheduled_for
 * @property CarbonInterface $started_at
 * @property CarbonInterface $completed_at
 * @property ProcessStatus $status
 * @property string $idempotency_key
 * @property array $context
 * @property string $error_summary
 *
 * @mixin \Illuminate\Database\Eloquent\Builder<AlertRun>
 */
class AlertRun extends Model
{
    protected $fillable = [
        'alert_id',
        'alert_schedule_id',
        'scheduled_for',
        'started_at',
        'completed_at',
        'status',
        'idempotency_key',
        'context',
        'error_summary',
    ];

    protected function casts(): array
    {
        return [
            'scheduled_for' => 'datetime',
            'started_at' => 'datetime',
            'completed_at' => 'datetime',
            'status' => ProcessStatus::class,
            'context' => 'array',
        ];
    }

    public function alert(): BelongsTo|Alert
    {
        return $this->belongsTo(Alert::class);
    }

    public function schedule(): BelongsTo|AlertSchedule
    {
        return $this->belongsTo(AlertSchedule::class, 'alert_schedule_id');
    }

    public function emails(): MorphMany|Email
    {
        return $this->morphMany(Email::class, 'relatedRecord', 'related_type', 'related_id');
    }
}
