<?php

namespace App\Models\Alerts;

use App\DTO\Alerts\AlertSourceConfig;
use App\Enums\Alerts\AlertType;
use App\Models\Role;
use Illuminate\Database\Eloquent\Casts\Attribute;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Relations\BelongsToMany;
use Illuminate\Database\Eloquent\Relations\HasMany;

/**
 * @formatter:off
 */
/**
 * @property int $id
 * @property \App\Enums\Alerts\AlertType $type_key
 * @property string $name
 * @property AlertSourceConfig $source_config
 * @property int $definition_version
 * @property null|\Carbon\CarbonInterface $enabled_at
 * @property null|\Carbon\CarbonInterface $disabled_at
 * @property-read \Illuminate\Database\Eloquent\Collection<Role> $roles
 *
 * @mixin \Illuminate\Database\Eloquent\Builder<Alert>
 */
/**
 * @formatter:on
 */
final class Alert extends Model
{
    protected $fillable = [
        'type_key',
        'name',
        'source_config',
        'definition_version',
        'enabled_at',
        'disabled_at',
    ];

    protected function casts(): array
    {
        return [
            'type_key' => AlertType::class,
            'definition_version' => 'int',
            'disabled_at' => 'datetime',
            'enabled_at' => 'datetime',
        ];
    }

    public function schedules(): HasMany|AlertSchedule
    {
        return $this->hasMany(AlertSchedule::class);
    }

    public function runs(): HasMany|AlertRun
    {
        return $this->hasMany(AlertRun::class);
    }

    /**
     * @noinspection PhpUnused
     */
    public function roles(): BelongsToMany|Role
    {
        return $this
            ->belongsToMany(Role::class, 'alert_role_recipients')
            ->withPivot('enabled')
            ->withTimestamps();
    }

    public function isEnabled(): bool
    {
        return $this->disabled_at === null && $this->enabled_at !== null;
    }

    /**
     * @noinspection PhpUnused
     */
    protected function sourceConfig(): Attribute
    {
        return Attribute::make(
            get: static fn (string $value): AlertSourceConfig => AlertSourceConfig::fromArray(
                json_decode($value, true, 512, JSON_THROW_ON_ERROR),
            ),
            set: static fn (AlertSourceConfig $value): string => json_encode(
                $value->toArray(),
                JSON_THROW_ON_ERROR,
            ),
        )->shouldCache();
    }
}
