<?php

namespace App\Models;

use App\Models\AllRivers\AlertTracking;
use App\Models\AllRivers\DimReporting;
use App\Traits\Models\ConnectionInTestingEnv;
use Carbon\Carbon;
use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Relations\HasMany;

/**
 * @property integer id
 * @property string name
 * @property string owner_email
 * @property string requester_email
 * @property string signed_off_email
 * @property Carbon verified_at
 * @property array review_answers
 * @property Carbon created_at
 * @property Carbon updated_at
 */
class AlertAuditVerification extends Model
{
    use HasFactory, ConnectionInTestingEnv;

    protected $fillable = [
        'name',
        'owner_email',
        'requester_email',
        'signed_off_email',
        'verified_at',
        'review_answers',
    ];

    protected $casts = [
        'verified_at' => 'date',
        'review_answers' => 'array',
    ];

    public function alertAudits(): HasMany
    {
        return $this->hasMany(AlertAudit::class, 'name', 'name');
    }

    public function alertTracking(): HasMany
    {
        return $this->hasMany(AlertTracking::class, 'name', 'name');
    }

    public function dimReporting(): HasMany
    {
        return $this->hasMany(DimReporting::class, 'name', 'name');
    }
}
