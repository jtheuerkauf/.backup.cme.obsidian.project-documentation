<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Relations\BelongsTo;
use Spatie\Permission\Exceptions\RoleDoesNotExist;
use \Spatie\Permission\Models\Role as SpatieRole;

class Role extends SpatieRole
{
    use HasFactory;

    public static function findByCode(string $code, $guardName = null): SpatieRole
    {
        $guardName = $guardName ?? config('auth.defaults.guard');

        $role = static::where(function ($query) use ($code) {
            $query->where('code', '=', $code)
                ->orWhere('name', '=', $code);
        })->where('guard_name', $guardName)->first();

        if (! $role) {
            throw RoleDoesNotExist::create($code, $guardName);
        }

        return $role;
    }

    public static function findByName(string $name, $guardName = null): SpatieRole
    {
        $guardName = $guardName ?? config('auth.defaults.guard');

        return static::findByCode($name, $guardName);
    }

    public function department(): BelongsTo
    {
        return $this->belongsTo(Department::class);
    }
}
