<?php

namespace App\Providers;

use App\Events\Invoices\InvoiceStored;
use App\Listeners\Invoices\SendInvoiceUploadCompletedNotification;
use App\Events\POSubmissions\POSubmissionClaimed;
use App\Events\Workflows\WorkflowJobLogged;
use App\Listeners\Email\AttachEmailMetadataHeaders;
use App\Listeners\Email\MarkIntentEmailSending;
use App\Listeners\Email\MarkIntentEmailSent;
use App\Listeners\POSubmissions\LogPOSubmissionClaimed;
use App\Listeners\VendorCcReceipts\LinkVendorCcReceiptInvoice;
use App\Listeners\Workflows\CheckForWorkflowCompletion;
use Illuminate\Foundation\Support\Providers\EventServiceProvider as ServiceProvider;
use Illuminate\Mail\Events\MessageSending;
use Illuminate\Mail\Events\MessageSent;

class EventServiceProvider extends ServiceProvider
{
    protected $listen = [
        InvoiceStored::class => [
            LinkVendorCcReceiptInvoice::class,
            SendInvoiceUploadCompletedNotification::class,
        ],
        POSubmissionClaimed::class => [
            LogPOSubmissionClaimed::class,
        ],
        WorkflowJobLogged::class => [
            CheckForWorkflowCompletion::class,
        ],
        MessageSending::class => [
            AttachEmailMetadataHeaders::class,
            MarkIntentEmailSending::class,
        ],
        MessageSent::class => [
            MarkIntentEmailSent::class,
        ],
    ];
}
