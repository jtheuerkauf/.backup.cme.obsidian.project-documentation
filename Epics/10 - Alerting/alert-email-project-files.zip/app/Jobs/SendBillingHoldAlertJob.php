<?php

namespace App\Jobs;

use App\Enums\Email\EmailType;
use App\Mail\BillingHoldAlertMail;
use App\Models\APlus\Order as APlusOrder;
use App\Models\Email;
use App\Models\ModelActionLog;
use App\Services\Alerts\BillingHoldAlertService;
use App\Support\ValueHelpers;
use Carbon\CarbonImmutable;
use Illuminate\Bus\Queueable;
use Illuminate\Contracts\Queue\ShouldQueue;
use Illuminate\Database\QueryException;
use Illuminate\Foundation\Bus\Dispatchable;
use Illuminate\Queue\InteractsWithQueue;
use Illuminate\Queue\SerializesModels;
use Illuminate\Support\Collection;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Log;
use Illuminate\Support\Facades\Mail;

class SendBillingHoldAlertJob implements ShouldQueue
{
    use Dispatchable, InteractsWithQueue, Queueable, SerializesModels;

    public int $timeout = 300;
    public int $tries = 3;
    public int $backoff = 10;

    private string $emailType = 'alerts.order.billing_hold_over_7_days';
    private string $queuedAction = 'billing_hold_alert_queued';

    public function __construct(
        private readonly ?array $toRecipients = null,
        private readonly ?array $ccRecipients = null,
        private readonly int $minimumDaysHeld = 7,
        private readonly bool $sendEmpty = false,
    ) {
    }

    public function handle(BillingHoldAlertService $service): void
    {
        $rows = $service->buildRows($this->minimumDaysHeld);

        if ($rows->isEmpty() && !$this->sendEmpty) {
            Log::info('[Billing Hold Alert] No BH rows found for alert run.', [
                'minimum_days_held' => $this->minimumDaysHeld,
            ]);
            return;
        }

        $to = $this->sanitizeRecipients($this->toRecipients)
            ?: ['billing@cmecorp.com'];
        $cc = $this->sanitizeRecipients($this->ccRecipients)
            ?: ['kbugbee@cmecorp.com'];

        $generatedAt = CarbonImmutable::now(config('app.timezone'));
        $dedupeKey = $this->buildDedupeKey($rows, $to, $cc, $generatedAt, $this->minimumDaysHeld);
        $intent = $this->createEmailIntent(
            dedupeKey: $dedupeKey,
            rows: $rows,
            toRecipients: $to,
            ccRecipients: $cc,
            generatedAt: $generatedAt,
            minimumDaysHeld: $this->minimumDaysHeld,
            sendEmpty: $this->sendEmpty,
        );

        if ($intent === null) {
            Log::info('[Billing Hold Alert] Duplicate BH alert intent detected; skipping queue.', [
                'dedupe_key' => $dedupeKey,
                'row_count' => $rows->count(),
            ]);

            return;
        }

        $pending = Mail::to($to);
        if (!empty($cc)) {
            $pending->cc($cc);
        }

        $pending->queue(new BillingHoldAlertMail(
            rows: $rows,
            generatedAt: $generatedAt,
            minimumDaysHeld: $this->minimumDaysHeld,
            emailType: $this->emailType,
            dedupeKey: $dedupeKey,
            intentEmailId: $intent->id,
        ));

        Log::info('[Billing Hold Alert] Queued BH alert email.', [
            'row_count' => $rows->count(),
            'to' => $to,
            'cc' => $cc,
            'email_intent_id' => $intent->id,
            'dedupe_key' => $dedupeKey,
            'minimum_days_held' => $this->minimumDaysHeld,
            'send_empty' => $this->sendEmpty,
        ]);
    }

    private function sanitizeRecipients(?array $recipients): array
    {
        if ($recipients === null) {
            return [];
        }

        return collect($recipients)
            ->map(fn ($email) => strtolower(trim((string) $email)))
            ->filter(fn ($email) => $email !== '' && filter_var($email, FILTER_VALIDATE_EMAIL) !== false)
            ->unique()
            ->values()
            ->all();
    }

    private function createEmailIntent(
        string $dedupeKey,
        Collection $rows,
        array $toRecipients,
        array $ccRecipients,
        CarbonImmutable $generatedAt,
        int $minimumDaysHeld,
        bool $sendEmpty,
    ): ?Email {
        if ($this->intentExists($dedupeKey)) {
            return null;
        }

        $previewMailable = new BillingHoldAlertMail(
            rows: $rows,
            generatedAt: $generatedAt,
            minimumDaysHeld: $minimumDaysHeld,
        );

        try {
            return DB::transaction(function () use ($dedupeKey, $rows, $toRecipients, $ccRecipients, $generatedAt, $minimumDaysHeld, $sendEmpty, $previewMailable): Email {
                $context = [
                    'alert_name' => BillingHoldAlertService::ALERT_NAME,
                    'hold_code' => 'BH',
                    'generated_at' => $generatedAt->toIso8601String(),
                    'minimum_days_held' => $minimumDaysHeld,
                    'send_empty' => $sendEmpty,
                    'row_count' => $rows->count(),
                    'order_keys' => $rows
                        ->pluck('order_key')
                        ->filter()
                        ->unique()
                        ->values()
                        ->all(),
                ];

                $intent = Email::createWithBody([
                    'provider' => 'msgraph',
                    'email_type' => $this->emailType,
                    'mailable' => EmailType::BillingHoldAlert,
                    'related_type' => APlusOrder::class,
                    'related_id' => null,
                    'generated_by_id' => null,
                    'model_action_log_id' => null,
                    'from_email' => $this->resolveFromEmail(),
                    'to' => $toRecipients,
                    'cc' => $ccRecipients,
                    'reply_to' => [$this->resolveReplyToEmail()],
                    'subject' => $this->resolveSubject($minimumDaysHeld),
                    'body_html' => $previewMailable->render(),
                    'status' => 'queued',
                    'queued_at' => now(),
                    'attempts' => 0,
                    'dedupe_key' => $dedupeKey,
                    'context' => $context,
                ]);

                $log = ModelActionLog::create([
                    'loggable_type' => Email::class,
                    'loggable_id' => $intent->id,
                    'user_id' => null,
                    'action' => $this->queuedAction,
                    'data' => [
                        'alert_name' => BillingHoldAlertService::ALERT_NAME,
                        'hold_code' => 'BH',
                        'email_type' => $this->emailType,
                        'dedupe_key' => $dedupeKey,
                        'minimum_days_held' => $minimumDaysHeld,
                        'send_empty' => $sendEmpty,
                        'row_count' => $rows->count(),
                        'order_keys' => $context['order_keys'],
                        'to' => $toRecipients,
                        'cc' => $ccRecipients,
                    ],
                ]);

                $intent->model_action_log_id = $log->id;
                $intent->save();

                return $intent;
            });
        } catch (QueryException $e) {
            if (ValueHelpers::isDuplicateKeyException($e)) {
                return null;
            }

            throw $e;
        }
    }

    private function buildDedupeKey(
        Collection $rows,
        array $toRecipients,
        array $ccRecipients,
        CarbonImmutable $generatedAt,
        int $minimumDaysHeld,
    ): string {
        $rowSignature = $rows
            ->map(function (array $row): string {
                return implode('|', [
                    (string) ($row['order_key'] ?? ''),
                    (string) ($row['days_held'] ?? ''),
                    (string) ($row['status'] ?? ''),
                    (string) ($row['cleanup_note'] ?? ''),
                    (string) ($row['tracker_number'] ?? ''),
                    (string) (int) ($row['is_bpo'] ?? false),
                ]);
            })
            ->sort()
            ->values()
            ->all();

        $snapshotHash = sha1(json_encode([
            'rows' => $rowSignature,
            'to' => array_values($toRecipients),
            'cc' => array_values($ccRecipients),
        ], JSON_UNESCAPED_SLASHES) ?: '');

        return $this->emailType
            . '|date:' . $generatedAt->toDateString()
            . '|min-days:' . $minimumDaysHeld
            . '|snapshot:' . $snapshotHash;
    }

    private function intentExists(string $dedupeKey): bool
    {
        return Email::query()
            ->where('dedupe_key', $dedupeKey)
            ->exists();
    }

    private function resolveFromEmail(): string
    {
        $configured = trim((string) config('mail.from.address', ''));

        return $configured !== '' ? $configured : 'devrequests@cmecorp.com';
    }

    private function resolveReplyToEmail(): string
    {
        $configured = trim((string) config('mail.reply_to.address', ''));
        if ($configured !== '') {
            return $configured;
        }

        return 'devrequests@cmecorp.com';
    }

    private function resolveSubject(int $minimumDaysHeld): string
    {
        return $minimumDaysHeld === 7
            ? 'Orders Held (BH) Over 7 Days'
            : 'Orders Held (BH) Over ' . $minimumDaysHeld . ' Days (Preview)';
    }
}
