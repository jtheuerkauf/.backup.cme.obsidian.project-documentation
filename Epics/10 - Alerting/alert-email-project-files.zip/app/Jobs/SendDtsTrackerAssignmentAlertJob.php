<?php

namespace App\Jobs;

use App\Enums\Email\EmailType;
use App\Mail\DtsTrackerAssignmentMail;
use App\Models\Datasync\PMHubOrderTracker;
use App\Models\Datasync\PMHubTracker as DatasyncPMHubTracker;
use App\Models\PMHub\TrackerContact;
use App\Repositories\Interfaces\PMHub\DtsTrackerAlertRepositoryInterface;
use App\Repositories\Interfaces\PMHub\DtsTrackerNotificationRepositoryInterface;
use App\Repositories\MongoDB\MongoClient;
use App\Support\Addresses\Address;
use App\Support\PMHub\DtsTrackerAssignmentBatchBuilder;
use App\Support\Text\Formatter;
use App\Support\Text\Sanitizer;
use App\Support\ValueHelpers;
use Carbon\Carbon;
use Illuminate\Bus\Queueable;
use Illuminate\Contracts\Queue\ShouldQueue;
use Illuminate\Foundation\Bus\Dispatchable;
use Illuminate\Queue\InteractsWithQueue;
use Illuminate\Queue\SerializesModels;
use Illuminate\Support\Collection;
use Illuminate\Support\Facades\Log;
use Illuminate\Support\Facades\Mail;
use MongoDB\BSON\ObjectId;
use MongoDB\BSON\UTCDateTime;

class SendDtsTrackerAssignmentAlertJob implements ShouldQueue
{
    use Dispatchable, InteractsWithQueue, Queueable, SerializesModels;

    public const MAX_ORDER_ROWS_PER_BATCH = DtsTrackerAssignmentBatchBuilder::MAX_ORDER_ROWS_PER_BATCH;

    /**
     * Processing jobs are created from bounded tracker batches. A single
     * tracker remains atomic for contact-state correctness, while APlusSync
     * lookups are chunked so its order rows cannot create oversized predicates.
     */
    public int $timeout = 75;

    public int $tries = 3;

    public int $backoff = 10;

    /** @var array<int, string>|null */
    public ?array $trackerNumbers = null;

    private int $maxEmailsPerRun = 0;

    private int $orderMetricsPreloadChunkSize = self::MAX_ORDER_ROWS_PER_BATCH;

    private int $progressLogInterval = 25;

    private ?string $launchRecipientOverride = null;

    private array $launchBccRecipients = [];

    /** @var array<string, array{tracker_id:string, tracker_number:string}> */
    private array $pendingMongoTrackerContactDates = [];

    /** @var array<string, TrackerContact> */
    private array $latestTrackerContactsCache = [];

    private array $dtsOrderKeyCache = [];

    private bool $dtsOrderKeyCachePrimed = false;

    private array $orderMetricsCache = [];

    /** @var array<string, string> */
    private array $salesRepLabelCache = [];

    private bool $salesRepLabelCachePrimed = false;

    /** @var array<string, array<string, mixed>> */
    private array $trackerMailDataCache = [];

    private ?DtsTrackerAlertRepositoryInterface $trackerAlertRepository = null;

    private ?DtsTrackerNotificationRepositoryInterface $trackerAssignmentRepository = null;

    private ?string $forcedTrackerNumber = null;

    private string $introEmailType = 'pmhub.tracker.intro';

    private string $followUpEmailType = 'pmhub.tracker.follow_up';

    public function __construct(
        private readonly ?string $launchDate = null,
        ?array $trackerNumbers = null,
    ) {
        $this->trackerNumbers = $trackerNumbers;
    }

    public function withLaunchRecipientOverride(?string $email): self
    {
        $this->launchRecipientOverride = Sanitizer::sanitizeEmailAddress($email);

        return $this;
    }

    /**
     * @param  array<int, string|null>  $emails
     */
    public function withLaunchBccRecipients(array $emails): self
    {
        $this->launchBccRecipients = collect($emails)
            ->map(fn ($email) => Sanitizer::sanitizeEmailAddress($email))
            ->filter()
            ->unique()
            ->values()
            ->all();

        return $this;
    }

    public function withForcedTrackerNumber(?string $trackerNumber): self
    {
        $trackerNumber = trim((string) $trackerNumber);
        $this->forcedTrackerNumber = $trackerNumber !== '' ? $trackerNumber : null;

        return $this;
    }

    private function trackerAlertRepository(): DtsTrackerAlertRepositoryInterface
    {
        if ($this->trackerAlertRepository === null) {
            $this->trackerAlertRepository = app(DtsTrackerAlertRepositoryInterface::class);
        }

        return $this->trackerAlertRepository;
    }

    private function trackerAssignmentRepository(): DtsTrackerNotificationRepositoryInterface
    {
        if ($this->trackerAssignmentRepository === null) {
            $this->trackerAssignmentRepository = app(DtsTrackerNotificationRepositoryInterface::class);
        }

        return $this->trackerAssignmentRepository;
    }

    public function handle(): void
    {
        $this->dtsOrderKeyCache = [];
        $this->dtsOrderKeyCachePrimed = false;
        $this->orderMetricsCache = [];
        $this->salesRepLabelCache = [];
        $this->salesRepLabelCachePrimed = false;
        $this->latestTrackerContactsCache = [];
        $this->trackerMailDataCache = [];
        $this->pendingMongoTrackerContactDates = [];
        $startedAt = now();
        $runStartedAt = microtime(true);
        $isForcedTrackerRun = $this->isForcedTrackerRun();
        $launchDate = ! $isForcedTrackerRun && $this->launchDate !== null
            ? Carbon::parse($this->launchDate)->startOfDay()
            : null;
        $totalTrackers = 0;
        $introSent = 0;
        $followUpSent = 0;
        $processedTrackers = 0;
        $executionStatus = 'success';
        $failureContext = [];
        $serverIp = $this->resolveExecutionIpAddress();

        Log::info('[PMHub DTS Tracker Alerts] Job started', [
            'started_at' => $startedAt->toDateTimeString(),
            'environment' => app()->environment(),
            'host' => $this->resolveExecutionHostName(),
            'server_timezone' => date_default_timezone_get(),
            'server_ip' => $serverIp,
            'server_ip_resolved_hostname' => $this->resolveExecutionIpHostname($serverIp),
            'launch_date' => $launchDate?->toDateString(),
            'forced_tracker_number' => $this->forcedTrackerNumber,
            'tracker_batch_count' => count($this->trackerNumbers ?? []),
            'launch_override_recipient' => $this->launchRecipientOverride,
            'launch_bcc_count' => count($this->launchBccRecipients),
            'status' => 'started',
        ]);

        try {
            $now = now();

            if (! $isForcedTrackerRun && $now->isWeekend()) {
                $executionStatus = 'skipped';

                Log::info('[PMHub DTS Tracker Alerts] Weekend detected; delaying processing', [
                    'timestamp' => $now->toDateTimeString(),
                    'day' => $now->format('l'),
                    'timezone' => config('app.timezone'),
                ]);

                return;
            }

            if ($this->isCoordinatorRun()) {
                $this->dispatchProcessingJobs($launchDate);
                $executionStatus = 'fan_out';

                return;
            }

            $trackers = $this->trackerAssignmentRepository()->getTrackersForProcessing(
                $launchDate,
                $this->forcedTrackerNumber,
                $this->trackerNumbers,
            );
            $loadedTrackerCount = $trackers->count();
            $trackers = $trackers
                ->reject(fn (DatasyncPMHubTracker $tracker): bool => $this->shouldSuppressTrackerAssignmentEmail($tracker))
                ->values();
            $totalTrackers = $trackers->count();

            Log::info('[PMHub DTS Tracker Alerts] Trackers loaded', [
                'launch_date' => $launchDate?->toDateString(),
                'trackers' => $totalTrackers,
                'suppressed_trackers' => $loadedTrackerCount - $totalTrackers,
                'max_emails_per_run' => $this->maxEmailsPerRun,
                'launch_override_recipient' => $this->launchRecipientOverride,
                'forced_tracker_number' => $this->forcedTrackerNumber,
                'tracker_batch_count' => count($this->trackerNumbers ?? []),
            ]);

            $this->primeLatestTrackerContacts($trackers);
            $this->primeDtsOrderKeyCache($trackers);
            $this->primeSalesRepLabelCache($trackers);
            $this->primeOrderMetricsCache($trackers);

            $poIntroGroups = $this->buildPoIntroGroups($trackers);
            $processedPoIntroGroups = [];

            foreach ($trackers as $index => $tracker) {
                $processedTrackers = $index + 1;

                if ($processedTrackers % $this->progressLogInterval === 0 || $processedTrackers === $totalTrackers) {
                    Log::info('[PMHub DTS Tracker Alerts] Run progress', [
                        'processed_trackers' => $processedTrackers,
                        'total_trackers' => $totalTrackers,
                        'intro_sent' => $introSent,
                        'follow_up_sent' => $followUpSent,
                    ]);
                }

                if (! $isForcedTrackerRun && $this->maxEmailsPerRun > 0 && ($introSent + $followUpSent) >= $this->maxEmailsPerRun) {
                    Log::warning('[PMHub DTS Tracker Alerts] Max emails per run reached; delaying remaining trackers', [
                        'cap' => $this->maxEmailsPerRun,
                        'intro_sent' => $introSent,
                        'follow_up_sent' => $followUpSent,
                        'processed_trackers' => $processedTrackers,
                        'total_trackers' => $totalTrackers,
                    ]);
                    break;
                }

                $trackerNumber = $this->resolveDatasyncTrackerNumber($tracker);

                if ($trackerNumber === null) {
                    if (! $isForcedTrackerRun) {
                        Log::warning('[PMHub DTS Tracker Alerts] Tracker skipped due to missing datasync tracker number', [
                            'tracker' => (string) $tracker->trackerNumber,
                        ]);

                        continue;
                    }

                    $trackerNumber = $this->forcedTrackerNumber;
                }

                $datasyncTrackerId = $this->resolveDatasyncTrackerId($tracker);

                if ($datasyncTrackerId === null) {
                    if (! $isForcedTrackerRun) {
                        Log::warning('[PMHub DTS Tracker Alerts] Tracker skipped due to missing datasync tracker id', [
                            'tracker' => $trackerNumber,
                        ]);

                        continue;
                    }

                    $datasyncTrackerId = $trackerNumber;
                }

                $pmEmail = $isForcedTrackerRun
                    ? $this->resolveForcedPmEmail($tracker)
                    : Sanitizer::sanitizeEmailAddress($tracker->logisticsCoordinatorProfile?->email);
                $contactEmail = $isForcedTrackerRun
                    ? $this->resolveForcedContactEmail($tracker, $pmEmail)
                    : Sanitizer::sanitizeEmailAddress($tracker->contactEmail);

                if (! $pmEmail || ! $contactEmail) {
                    Log::warning('[PMHub DTS Tracker Alerts] Tracker email routing unresolved', [
                        'tracker' => $trackerNumber,
                        'pm_email' => $tracker->logisticsCoordinatorProfile?->email,
                        'contact_email' => $tracker->contactEmail,
                        'forced_tracker_run' => $isForcedTrackerRun,
                    ]);

                    continue;
                }

                $routing = $this->resolveRecipientRouting($contactEmail, $pmEmail);
                $accountManagerEmail = $this->resolveAccountManagerEmail($tracker);
                $intendedCcRecipients = $this->buildCcRecipients($routing['intended_cc'], [$accountManagerEmail]);
                $ccRecipients = $routing['launch_override_recipient'] === null
                    ? $this->buildCcRecipients($routing['cc'], [$accountManagerEmail])
                    : $routing['cc'];

                $orderRows = $tracker->orderTrackers;
                $snapshot = $isForcedTrackerRun
                    ? $this->buildForcedTrackerSnapshot($orderRows)
                    : $this->buildTrackerSnapshot($orderRows);

                if (! $snapshot) {
                    continue;
                }

                $latestContact = $this->forcedTrackerNumber === null
                    ? $this->latestTrackerContact($datasyncTrackerId, $trackerNumber)
                    : null;

                $mailData = $this->trackerMailData($tracker);
                $pmName = $this->resolvePmName($tracker, $pmEmail);

                $poIntroGroupKey = $isForcedTrackerRun
                    ? null
                    : $this->resolvePoIntroGroupKey(
                        datasyncTrackerId: $datasyncTrackerId,
                        pmEmail: $pmEmail,
                        contactEmail: $contactEmail,
                        snapshot: $snapshot,
                        latestContact: $latestContact,
                        groups: $poIntroGroups,
                    );

                if ($poIntroGroupKey !== null) {
                    if (in_array($poIntroGroupKey, $processedPoIntroGroups, true)) {
                        continue;
                    }

                    $sentGroupedIntro = $this->sendGroupedPurchaseOrderIntro(
                        group: $poIntroGroups[$poIntroGroupKey],
                        routing: $routing,
                    );

                    if ($sentGroupedIntro) {
                        $processedPoIntroGroups[] = $poIntroGroupKey;
                        $introSent++;

                        continue;
                    }
                }

                if (! $latestContact) {
                    $poData = $isForcedTrackerRun
                        ? $this->buildForcedPoData(
                            $tracker,
                            $orderRows,
                            $snapshot['po_numbers'],
                            $mailData['deliver_to_address'] ?? null,
                        )
                        : $this->buildPoDataForPoNumbers(
                            $orderRows,
                            $snapshot['po_numbers'],
                            $mailData['deliver_to_address'] ?? null,
                        );

                    if (! $poData) {
                        continue;
                    }

                    $introMailable = new DtsTrackerAssignmentMail(
                        type: 'intro',
                        tracker: $mailData,
                        poData: $poData,
                        pmEmail: $pmEmail,
                        pmName: $pmName,
                    );
                    $bodyHtml = $this->renderBodyHtml($introMailable, $trackerNumber, $this->introEmailType);

                    if ($bodyHtml === null) {
                        continue;
                    }

                    $dedupeKey = $this->buildSnapshotDedupeKey(
                        $this->introEmailType,
                        $datasyncTrackerId,
                        $trackerNumber,
                        $snapshot['snapshot_hash'],
                        $isForcedTrackerRun
                    );
                    $subjectTrackerNumber = str_starts_with(strtoupper($trackerNumber), 'T')
                        ? $trackerNumber
                        : 'T'.$trackerNumber;

                    $intent = $this->createEmailIntent(
                        emailType: $this->introEmailType,
                        dedupeKey: $dedupeKey,
                        tracker: $tracker,
                        datasyncTrackerId: $datasyncTrackerId,
                        datasyncTrackerNumber: $trackerNumber,
                        pmEmail: $pmEmail,
                        toRecipients: $routing['to'],
                        ccRecipients: $ccRecipients,
                        bccRecipients: $routing['bcc'],
                        intendedToRecipients: $routing['intended_to'],
                        intendedCcRecipients: $intendedCcRecipients,
                        launchOverrideRecipient: $routing['launch_override_recipient'],
                        subject: 'CME Tracker '.$subjectTrackerNumber,
                        poData: $poData,
                        bodyHtml: $bodyHtml,
                    );

                    if (! $intent) {
                        continue;
                    }

                    $queuedIntroMailable = new DtsTrackerAssignmentMail(
                        type: 'intro',
                        tracker: $mailData,
                        poData: $poData,
                        pmEmail: $pmEmail,
                        pmName: $pmName,
                        emailType: $this->introEmailType,
                        dedupeKey: $dedupeKey,
                        intentEmailId: $intent->id,
                    );

                    $this->queueTrackerAssignmentMail($routing['to'], $ccRecipients, $routing['bcc'], $queuedIntroMailable);

                    $this->recordTrackerContact(
                        datasyncTrackerId: $datasyncTrackerId,
                        datasyncTrackerNumber: $trackerNumber,
                        emailType: $this->introEmailType,
                        snapshot: $snapshot,
                        intent: $intent,
                        context: [
                            'event' => 'intro',
                            'sent_po_numbers' => $poData['po_numbers'],
                            'sent_order_keys' => $poData['order_keys'],
                        ],
                    );

                    $this->queueTrackerFirstCustomerContactDate($tracker);

                    $introSent++;

                    continue;
                }

                $previousSnapshot = $this->normalizeSnapshot($latestContact->po_numbers_snapshot);
                $addedPoNumbers = ValueHelpers::addedStrings($previousSnapshot['po_numbers'], $snapshot['po_numbers']);

                if (empty($addedPoNumbers)) {
                    continue;
                }

                $poData = $this->buildPoDataForPoNumbers(
                    $orderRows,
                    $addedPoNumbers,
                    $mailData['deliver_to_address'] ?? null,
                );

                if (! $poData) {
                    continue;
                }

                $previousPoData = $this->buildPoDataForPoNumbers(
                    $orderRows,
                    $previousSnapshot['po_numbers'],
                    $mailData['deliver_to_address'] ?? null,
                );
                $followUpMailData = array_merge($mailData, [
                    'previous_po_numbers' => $previousSnapshot['po_numbers'],
                ]);

                $followUpMailable = new DtsTrackerAssignmentMail(
                    type: 'follow_up',
                    tracker: $followUpMailData,
                    poData: $poData,
                    pmEmail: $pmEmail,
                    pmName: $pmName,
                );
                $followUpMailable->previousPoData = $previousPoData;
                $bodyHtml = $this->renderBodyHtml($followUpMailable, $trackerNumber, $this->followUpEmailType);

                if ($bodyHtml === null) {
                    continue;
                }

                $dedupeKey = $this->buildSnapshotDedupeKey(
                    $this->followUpEmailType,
                    $datasyncTrackerId,
                    $trackerNumber,
                    $snapshot['snapshot_hash']
                );
                $subjectTrackerNumber = str_starts_with(strtoupper($trackerNumber), 'T')
                    ? $trackerNumber
                    : 'T'.$trackerNumber;

                $intent = $this->createEmailIntent(
                    emailType: $this->followUpEmailType,
                    dedupeKey: $dedupeKey,
                    tracker: $tracker,
                    datasyncTrackerId: $datasyncTrackerId,
                    datasyncTrackerNumber: $trackerNumber,
                    pmEmail: $pmEmail,
                    toRecipients: $routing['to'],
                    ccRecipients: $ccRecipients,
                    bccRecipients: $routing['bcc'],
                    intendedToRecipients: $routing['intended_to'],
                    intendedCcRecipients: $intendedCcRecipients,
                    launchOverrideRecipient: $routing['launch_override_recipient'],
                    subject: $subjectTrackerNumber.' Add On',
                    poData: $poData,
                    bodyHtml: $bodyHtml,
                );

                if (! $intent) {
                    continue;
                }

                $queuedFollowUpMailable = new DtsTrackerAssignmentMail(
                    type: 'follow_up',
                    tracker: $followUpMailData,
                    poData: $poData,
                    pmEmail: $pmEmail,
                    pmName: $pmName,
                    emailType: $this->followUpEmailType,
                    dedupeKey: $dedupeKey,
                    intentEmailId: $intent->id,
                );
                $queuedFollowUpMailable->previousPoData = $previousPoData;

                $this->queueTrackerAssignmentMail($routing['to'], $ccRecipients, $routing['bcc'], $queuedFollowUpMailable);

                $this->recordTrackerContact(
                    datasyncTrackerId: $datasyncTrackerId,
                    datasyncTrackerNumber: $trackerNumber,
                    emailType: $this->followUpEmailType,
                    snapshot: $snapshot,
                    intent: $intent,
                    context: [
                        'event' => 'follow_up',
                        'added_po_numbers' => $poData['po_numbers'],
                        'added_order_keys' => $poData['order_keys'],
                        'previous_po_numbers' => $previousSnapshot['po_numbers'],
                    ],
                );

                $followUpSent++;
            }
        } catch (\Throwable $exception) {
            $executionStatus = 'failed';
            $failureContext = [
                'exception_class' => $exception::class,
                'error' => $exception->getMessage(),
            ];

            Log::error('[PMHub DTS Tracker Alerts] Job failed', [
                'started_at' => $startedAt->toDateTimeString(),
                'finished_at' => now()->toDateTimeString(),
                'environment' => app()->environment(),
                'host' => $this->resolveExecutionHostName(),
                'status' => $executionStatus,
                'launch_date' => $launchDate?->toDateString(),
                'forced_tracker_number' => $this->forcedTrackerNumber,
                'processed_trackers' => $processedTrackers,
                'total_trackers' => $totalTrackers,
                'intro_sent' => $introSent,
                'follow_up_sent' => $followUpSent,
                'elapsed_seconds' => round(microtime(true) - $runStartedAt, 3),
                'exception_class' => $exception::class,
                'error' => $exception->getMessage(),
            ]);

            throw $exception;
        } finally {
            $this->flushPendingTrackerFirstCustomerContactDates();

            $finishContext = [
                'started_at' => $startedAt->toDateTimeString(),
                'finished_at' => now()->toDateTimeString(),
                'environment' => app()->environment(),
                'host' => $this->resolveExecutionHostName(),
                'status' => $executionStatus,
                'launch_date' => $launchDate?->toDateString(),
                'forced_tracker_number' => $this->forcedTrackerNumber,
                'processed_trackers' => $processedTrackers,
                'total_trackers' => $totalTrackers,
                'intro_sent' => $introSent,
                'follow_up_sent' => $followUpSent,
                'elapsed_seconds' => round(microtime(true) - $runStartedAt, 3),
            ];

            if ($failureContext !== []) {
                $finishContext = array_merge($finishContext, $failureContext);
            }

            Log::info('[PMHub DTS Tracker Alerts] Job finished', $finishContext);
        }
    }

    private function isCoordinatorRun(): bool
    {
        return ! $this->isForcedTrackerRun() && $this->trackerNumbers === null;
    }

    private function dispatchProcessingJobs(?Carbon $launchDate): void
    {
        $batches = app(DtsTrackerAssignmentBatchBuilder::class)->build(
            $this->trackerAssignmentRepository()->getTrackerBatchCandidates($launchDate)
        );

        foreach ($batches as $trackerBatch) {
            $job = new self(
                launchDate: $this->launchDate,
                trackerNumbers: $trackerBatch,
            );
            $job->withLaunchRecipientOverride($this->launchRecipientOverride)
                ->withLaunchBccRecipients($this->launchBccRecipients);

            dispatch($job)->onQueue('default');
        }

        Log::info('[PMHub DTS Tracker Alerts] Coordinator fanned out processing jobs', [
            'batches' => count($batches),
        ]);
    }

    private function primeLatestTrackerContacts(Collection $trackers): void
    {
        if ($this->isForcedTrackerRun() || $trackers->isEmpty()) {
            return;
        }

        $trackerIdentities = $trackers
            ->map(function (DatasyncPMHubTracker $tracker): ?array {
                $trackerId = $this->resolveDatasyncTrackerId($tracker);
                $trackerNumber = $this->resolveDatasyncTrackerNumber($tracker);

                if ($trackerId === null || $trackerNumber === null) {
                    return null;
                }

                return [
                    'tracker_id' => $trackerId,
                    'tracker_number' => $trackerNumber,
                ];
            })
            ->filter()
            ->values()
            ->all();

        if ($trackerIdentities === []) {
            return;
        }

        $this->latestTrackerContactsCache = $this->trackerAssignmentRepository()
            ->latestTrackerContacts($trackerIdentities)
            ->all();
    }

    private function latestTrackerContact(string $trackerId, string $trackerNumber): ?TrackerContact
    {
        return $this->latestTrackerContactsCache[
            $this->trackerContactCacheKey($trackerId, $trackerNumber)
        ] ?? null;
    }

    private function trackerContactCacheKey(string $trackerId, string $trackerNumber): string
    {
        return trim($trackerId).'|'.trim($trackerNumber);
    }

    private function buildPoIntroGroups(Collection $trackers): array
    {
        $groups = [];

        foreach ($trackers as $tracker) {
            $trackerNumber = $this->resolveDatasyncTrackerNumber($tracker);
            $datasyncTrackerId = $this->resolveDatasyncTrackerId($tracker);
            $pmEmail = Sanitizer::sanitizeEmailAddress($tracker->logisticsCoordinatorProfile?->email);
            $contactEmail = Sanitizer::sanitizeEmailAddress($tracker->contactEmail);

            if ($trackerNumber === null || $datasyncTrackerId === null || $pmEmail === null || $contactEmail === null) {
                continue;
            }

            $snapshot = $this->buildTrackerSnapshot($tracker->orderTrackers);

            if ($snapshot === null || count($snapshot['po_numbers']) !== 1) {
                continue;
            }

            $latestContact = $this->latestTrackerContact($datasyncTrackerId, $trackerNumber);

            if ($latestContact !== null) {
                continue;
            }

            $poNumber = trim((string) ($snapshot['po_numbers'][0] ?? ''));

            if ($poNumber === '') {
                continue;
            }

            $mailData = $this->trackerMailData($tracker);
            $orderKeysForTracker = $tracker->orderTrackers
                ->pluck('orderKey')
                ->map(fn ($key) => trim((string) $key))
                ->filter()
                ->unique()
                ->sort()
                ->values();

            if ($orderKeysForTracker->isEmpty()) {
                continue;
            }

            $groupKey = $this->buildPoIntroGroupKey($pmEmail, $contactEmail, $poNumber);

            $groups[$groupKey] ??= [
                'group_key' => $groupKey,
                'po_number' => $poNumber,
                'pm_email' => $pmEmail,
                'contact_email' => $contactEmail,
                'pm_name' => $this->resolvePmName($tracker, $pmEmail),
                'trackers' => [],
            ];

            $groups[$groupKey]['trackers'][] = [
                'tracker_model' => $tracker,
                'tracker_id' => $datasyncTrackerId,
                'tracker_number' => $trackerNumber,
                'snapshot' => $snapshot,
                'mail_data' => $mailData,
                'order_rows' => $tracker->orderTrackers,
                'order_keys' => $orderKeysForTracker->all(),
            ];
        }

        return collect($groups)
            ->filter(fn (array $group) => count($group['trackers']) > 1)
            ->all();
    }

    private function shouldSuppressTrackerAssignmentEmail(DatasyncPMHubTracker $tracker): bool
    {
        $projectName = strtoupper(trim((string) $tracker->projectName));

        return str_starts_with($projectName, 'HCAADA');
    }

    private function buildPoIntroGroupKey(string $pmEmail, string $contactEmail, string $poNumber): string
    {
        return strtolower(trim($pmEmail))
            .'|'
            .strtolower(trim($contactEmail))
            .'|'
            .strtoupper(trim($poNumber));
    }

    private function resolvePoIntroGroupKey(
        string $datasyncTrackerId,
        string $pmEmail,
        string $contactEmail,
        array $snapshot,
        ?TrackerContact $latestContact,
        array $groups,
    ): ?string {
        if ($latestContact !== null || count($snapshot['po_numbers']) !== 1) {
            return null;
        }

        $poNumber = trim((string) ($snapshot['po_numbers'][0] ?? ''));

        if ($poNumber === '') {
            return null;
        }

        $groupKey = $this->buildPoIntroGroupKey($pmEmail, $contactEmail, $poNumber);
        $group = $groups[$groupKey] ?? null;

        if (! is_array($group)) {
            return null;
        }

        $isGroupMember = collect($group['trackers'] ?? [])
            ->contains(fn (array $context) => ($context['tracker_id'] ?? null) === $datasyncTrackerId);

        return $isGroupMember ? $groupKey : null;
    }

    private function sendGroupedPurchaseOrderIntro(array $group, array $routing): bool
    {
        $trackerContexts = collect($group['trackers'] ?? [])
            ->map(function (array $context) use ($group): ?array {
                $poNumber = trim((string) ($group['po_number'] ?? ''));
                $orderRows = $context['order_rows'] ?? collect();

                if (! ($orderRows instanceof Collection) || $poNumber === '') {
                    return null;
                }

                $mailData = is_array($context['mail_data'] ?? null) ? $context['mail_data'] : [];
                $poDataForTracker = $this->buildPoDataForPoNumbers(
                    $orderRows,
                    [$poNumber],
                    $mailData['deliver_to_address'] ?? null,
                );

                if ($poDataForTracker === null) {
                    return null;
                }

                $row = collect($poDataForTracker['rows'] ?? [])->first();

                if (! is_array($row)) {
                    return null;
                }

                $trackerNumber = trim((string) ($context['tracker_number'] ?? ''));
                $trackerNumberDisplay = str_starts_with(strtoupper($trackerNumber), 'T')
                    ? $trackerNumber
                    : 'T'.$trackerNumber;

                $context['order_keys'] = $poDataForTracker['order_keys'] ?? [];
                $context['sales_rep_label'] = $poDataForTracker['sales_rep_label'] ?? '[Unavailable]';
                $context['row'] = [
                    'tracker_number' => $trackerNumberDisplay,
                    'po_amount_display' => (string) ($row['po_amount_display'] ?? '$0.00'),
                    'po_amount_total' => (float) ($row['po_amount_total'] ?? 0),
                    'deliver_to_address' => (string) ($row['deliver_to_address'] ?? ($mailData['deliver_to_address'] ?? '[Deliver To Address]')),
                    'for_display' => (string) (($mailData['account_name'] ?? '[CUSTOMER NAME]').' (Account #'.($mailData['account_id'] ?? '[ACCOUNT #]').')'),
                ];

                return $context;
            })
            ->filter(fn ($context) => is_array($context))
            ->values();

        if ($trackerContexts->count() < 2) {
            return false;
        }

        $baseContext = $trackerContexts->first();

        if (! is_array($baseContext)) {
            return false;
        }

        $poNumber = trim((string) ($group['po_number'] ?? ''));

        if ($poNumber === '') {
            return false;
        }

        $groupedTrackerIds = $trackerContexts
            ->pluck('tracker_id')
            ->map(fn ($id) => trim((string) $id))
            ->filter()
            ->unique()
            ->values();

        $groupedTrackerNumbers = $trackerContexts
            ->pluck('tracker_number')
            ->map(fn ($number) => trim((string) $number))
            ->filter()
            ->unique()
            ->values();

        $groupedOrderKeys = $trackerContexts
            ->pluck('order_keys')
            ->flatten()
            ->map(fn ($key) => trim((string) $key))
            ->filter()
            ->unique()
            ->sort()
            ->values();

        $rows = $trackerContexts
            ->pluck('row')
            ->filter(fn ($row) => is_array($row))
            ->map(function (array $row): array {
                return [
                    'tracker_number' => (string) ($row['tracker_number'] ?? '[Tracker]'),
                    'po_amount_display' => (string) ($row['po_amount_display'] ?? '$0.00'),
                    'po_amount_total' => (float) ($row['po_amount_total'] ?? 0),
                    'deliver_to_address' => (string) ($row['deliver_to_address'] ?? '[Deliver To Address]'),
                    'for_display' => (string) ($row['for_display'] ?? '[CUSTOMER NAME] (Account #[ACCOUNT #])'),
                ];
            })
            ->sortBy('tracker_number')
            ->values();

        if ($rows->isEmpty()) {
            return false;
        }

        $poAmountTotal = (float) $rows->sum(fn (array $row) => (float) $row['po_amount_total']);
        $salesRepLabel = $trackerContexts
            ->pluck('sales_rep_label')
            ->map(fn ($label) => trim((string) $label))
            ->filter()
            ->unique()
            ->implode(', ');

        $poData = [
            'order_keys' => $groupedOrderKeys->all(),
            'po_numbers' => [$poNumber],
            'po_numbers_display' => $poNumber,
            'po_amount_total' => $poAmountTotal,
            'po_amount_display' => $this->formatPoAmount($poAmountTotal),
            'sales_rep_label' => $salesRepLabel !== '' ? $salesRepLabel : '[Unavailable]',
            'rows' => $rows->all(),
        ];

        $mailData = array_merge($baseContext['mail_data'] ?? [], [
            'purchase_order_number' => $poNumber,
        ]);

        $pmEmail = trim((string) ($group['pm_email'] ?? ''));
        $pmName = trim((string) ($group['pm_name'] ?? ''));
        $accountManagerEmails = $trackerContexts
            ->pluck('tracker_model')
            ->filter(fn ($tracker) => $tracker instanceof DatasyncPMHubTracker)
            ->map(fn (DatasyncPMHubTracker $tracker) => $this->resolveAccountManagerEmail($tracker))
            ->filter()
            ->values()
            ->all();
        $intendedCcRecipients = $this->buildCcRecipients([$pmEmail], $accountManagerEmails);
        $ccRecipients = $routing['launch_override_recipient'] === null
            ? $this->buildCcRecipients($routing['cc'], $accountManagerEmails)
            : $routing['cc'];

        if ($pmEmail === '' || $pmName === '') {
            return false;
        }

        $dedupeKey = $this->buildGroupedPoIntroDedupeKey($group, $trackerContexts->all());
        $subject = 'Purchase Order '.$poNumber;
        $mailable = new DtsTrackerAssignmentMail(
            type: 'po_intro',
            tracker: $mailData,
            poData: $poData,
            pmEmail: $pmEmail,
            pmName: $pmName,
        );
        $bodyHtml = $this->renderBodyHtml($mailable, $poNumber, $this->introEmailType);

        if ($bodyHtml === null) {
            return false;
        }

        /** @var DatasyncPMHubTracker|null $baseTracker */
        $baseTracker = $baseContext['tracker_model'] ?? null;
        $baseTrackerId = trim((string) ($baseContext['tracker_id'] ?? ''));
        $baseTrackerNumber = trim((string) ($baseContext['tracker_number'] ?? ''));

        if (! $baseTracker instanceof DatasyncPMHubTracker || $baseTrackerId === '' || $baseTrackerNumber === '') {
            return false;
        }

        $intent = $this->createEmailIntent(
            emailType: $this->introEmailType,
            dedupeKey: $dedupeKey,
            tracker: $baseTracker,
            datasyncTrackerId: $baseTrackerId,
            datasyncTrackerNumber: $baseTrackerNumber,
            pmEmail: $pmEmail,
            toRecipients: $routing['to'],
            ccRecipients: $ccRecipients,
            bccRecipients: $routing['bcc'],
            intendedToRecipients: $routing['intended_to'],
            intendedCcRecipients: $intendedCcRecipients,
            launchOverrideRecipient: $routing['launch_override_recipient'],
            subject: $subject,
            poData: $poData,
            bodyHtml: $bodyHtml,
            intentContextExtras: [
                'mode' => 'purchase_order_grouped_intro',
                'purchase_order_number' => $poNumber,
                'group_size' => $trackerContexts->count(),
                'grouped_tracker_ids' => $groupedTrackerIds->all(),
                'grouped_tracker_numbers' => $groupedTrackerNumbers->all(),
            ],
            logDataExtras: [
                'mode' => 'purchase_order_grouped_intro',
                'purchase_order_number' => $poNumber,
                'group_size' => $trackerContexts->count(),
                'grouped_tracker_ids' => $groupedTrackerIds->all(),
                'grouped_tracker_numbers' => $groupedTrackerNumbers->all(),
            ],
        );

        if (! $intent) {
            return true;
        }

        $queuedMailable = new DtsTrackerAssignmentMail(
            type: 'po_intro',
            tracker: $mailData,
            poData: $poData,
            pmEmail: $pmEmail,
            pmName: $pmName,
            emailType: $this->introEmailType,
            dedupeKey: $dedupeKey,
            intentEmailId: $intent->id,
        );

        $this->queueTrackerAssignmentMail($routing['to'], $ccRecipients, $routing['bcc'], $queuedMailable);

        foreach ($trackerContexts as $context) {
            $trackerId = trim((string) ($context['tracker_id'] ?? ''));
            $trackerNumber = trim((string) ($context['tracker_number'] ?? ''));
            $snapshot = is_array($context['snapshot'] ?? null) ? $context['snapshot'] : null;
            $trackerModel = $context['tracker_model'] ?? null;

            if ($trackerId === '' || $trackerNumber === '' || $snapshot === null || ! $trackerModel instanceof DatasyncPMHubTracker) {
                continue;
            }

            $this->recordTrackerContact(
                datasyncTrackerId: $trackerId,
                datasyncTrackerNumber: $trackerNumber,
                emailType: $this->introEmailType,
                snapshot: $snapshot,
                intent: $intent,
                context: [
                    'event' => 'po_intro_grouped',
                    'purchase_order_number' => $poNumber,
                    'sent_po_numbers' => $poData['po_numbers'],
                    'sent_order_keys' => $poData['order_keys'],
                    'grouped_tracker_ids' => $groupedTrackerIds->all(),
                    'grouped_tracker_numbers' => $groupedTrackerNumbers->all(),
                ],
            );

            $this->queueTrackerFirstCustomerContactDate($trackerModel);
        }

        return true;
    }

    private function buildGroupedPoIntroDedupeKey(array $group, array $trackerContexts): string
    {
        $poNumber = trim((string) ($group['po_number'] ?? ''));
        $pmEmail = strtolower(trim((string) ($group['pm_email'] ?? '')));
        $contactEmail = strtolower(trim((string) ($group['contact_email'] ?? '')));

        $trackerSignature = collect($trackerContexts)
            ->map(function (array $context): string {
                $trackerId = trim((string) ($context['tracker_id'] ?? ''));
                $snapshotHash = trim((string) data_get($context, 'snapshot.snapshot_hash', ''));

                return $trackerId.':'.$snapshotHash;
            })
            ->filter()
            ->sort()
            ->implode('|');

        return $this->introEmailType
            .'|po:'.$poNumber
            .'|pm:'.$pmEmail
            .'|contact:'.$contactEmail
            .'|group:'.sha1($trackerSignature);
    }

    private function primeDtsOrderKeyCache(Collection $trackers): void
    {
        if ($this->isForcedTrackerRun()) {
            $this->dtsOrderKeyCachePrimed = true;

            return;
        }

        $orderKeys = $trackers
            ->pluck('orderTrackers')
            ->flatten(1)
            ->filter(fn ($row) => $row instanceof PMHubOrderTracker)
            ->pluck('orderKey')
            ->map(fn ($key) => trim((string) $key))
            ->filter()
            ->unique()
            ->sort()
            ->values();

        if ($orderKeys->isNotEmpty()) {
            $this->dtsOrderKeyCache = array_fill_keys(
                $this->trackerAlertRepository()->getDtsOrderKeys($orderKeys->all()),
                true,
            );
        }

        $this->dtsOrderKeyCachePrimed = true;

        Log::info('[PMHub DTS Tracker Alerts] DTS order key cache primed', [
            'order_keys' => $orderKeys->count(),
            'dts_order_keys' => count($this->dtsOrderKeyCache),
        ]);
    }

    private function primeSalesRepLabelCache(Collection $trackers): void
    {
        $isForcedTrackerRun = $this->isForcedTrackerRun();
        $orderKeys = $trackers
            ->pluck('orderTrackers')
            ->flatten(1)
            ->filter(fn ($row) => $row instanceof PMHubOrderTracker)
            ->pluck('orderKey')
            ->map(fn ($key) => trim((string) $key))
            ->filter()
            ->filter(fn (string $key): bool => $isForcedTrackerRun || $this->isCachedDtsOrderKey($key))
            ->unique()
            ->sort()
            ->values();

        if ($orderKeys->isNotEmpty()) {
            $this->salesRepLabelCache = $this->trackerAlertRepository()
                ->resolveSalesRepLabelsForOrderKeys($orderKeys->all());
        }

        $this->salesRepLabelCachePrimed = true;

        Log::info('[PMHub DTS Tracker Alerts] Sales rep label cache primed', [
            'order_keys' => $orderKeys->count(),
            'labeled_order_keys' => count($this->salesRepLabelCache),
        ]);
    }

    private function filterCachedDtsOrderKeys(Collection $orderKeys): Collection
    {
        return $orderKeys
            ->map(fn ($key) => trim((string) $key))
            ->filter(fn (string $key): bool => $this->isCachedDtsOrderKey($key))
            ->unique()
            ->sort()
            ->values();
    }

    private function isCachedDtsOrderKey(mixed $orderKey): bool
    {
        $orderKey = trim((string) $orderKey);

        return $orderKey !== ''
            && $this->dtsOrderKeyCachePrimed
            && array_key_exists($orderKey, $this->dtsOrderKeyCache);
    }

    private function buildTrackerSnapshot(Collection $orderRows): ?array
    {
        $allOrderKeys = $orderRows
            ->pluck('orderKey')
            ->map(fn ($key) => trim((string) $key))
            ->filter()
            ->unique()
            ->sort()
            ->values();

        if ($allOrderKeys->isEmpty()) {
            return null;
        }

        $dtsOrderKeys = $this->filterCachedDtsOrderKeys($allOrderKeys);

        if ($dtsOrderKeys->isEmpty()) {
            return null;
        }

        $poNumbers = ValueHelpers::normalizeStrings(
            $orderRows
                ->pluck('customerPurchaseOrderNumber')
                ->all()
        );

        if (empty($poNumbers)) {
            return null;
        }

        return [
            'po_numbers' => $poNumbers,
            'snapshot_hash' => ValueHelpers::hashNormalizedStrings($poNumbers),
        ];
    }

    private function buildForcedTrackerSnapshot(Collection $orderRows): ?array
    {
        $poNumbers = ValueHelpers::normalizeStrings(
            $orderRows
                ->pluck('customerPurchaseOrderNumber')
                ->all()
        );

        if (empty($poNumbers)) {
            $poNumbers = ['TRACKER-'.trim((string) $this->forcedTrackerNumber)];
        }

        return [
            'po_numbers' => $poNumbers,
            'snapshot_hash' => sha1('forced|'.trim((string) $this->forcedTrackerNumber).'|'.implode('|', $poNumbers)),
        ];
    }

    private function normalizeSnapshot(null|array|string $snapshot): array
    {
        $snapshotArray = is_array($snapshot) ? $snapshot : [];

        $sourcePoNumbers = array_is_list($snapshotArray)
            ? $snapshotArray
            : data_get($snapshotArray, 'po_numbers', []);

        $poNumbers = ValueHelpers::normalizeStrings($sourcePoNumbers);

        return [
            'po_numbers' => $poNumbers,
            'snapshot_hash' => ValueHelpers::hashNormalizedStrings($poNumbers),
        ];
    }

    private function salesRepLabelForOrderKeys(array $orderKeys): string
    {
        $normalizedOrderKeys = collect($orderKeys)
            ->map(fn ($key) => trim((string) $key))
            ->filter()
            ->unique()
            ->values();

        if ($normalizedOrderKeys->isEmpty()) {
            return '[Unavailable]';
        }

        if (! $this->salesRepLabelCachePrimed) {
            return $this->trackerAlertRepository()->resolveSalesRepLabelForOrderKeys($normalizedOrderKeys->all());
        }

        $label = $normalizedOrderKeys
            ->map(fn (string $orderKey): ?string => $this->salesRepLabelCache[$orderKey] ?? null)
            ->filter(fn (?string $value): bool => $value !== null && trim($value) !== '')
            ->unique()
            ->implode(', ');

        return $label !== '' ? $label : '[Unavailable]';
    }

    private function buildPoDataForPoNumbers(
        Collection $orderRows,
        array $candidatePoNumbers,
        ?string $defaultDeliverToAddress = null
    ): ?array {
        $poNumbers = collect($candidatePoNumbers)
            ->map(fn ($po) => trim((string) $po))
            ->filter()
            ->unique()
            ->sort()
            ->values();

        if ($poNumbers->isEmpty()) {
            return null;
        }

        $filteredOrderRows = $orderRows
            ->filter(function (PMHubOrderTracker $row) use ($poNumbers) {
                $poNumber = trim((string) $row->customerPurchaseOrderNumber);

                return $poNumber !== '' && $poNumbers->contains($poNumber);
            })
            ->values();

        $orderKeysByPo = $filteredOrderRows
            ->groupBy(fn (PMHubOrderTracker $row) => trim((string) $row->customerPurchaseOrderNumber))
            ->map(function (Collection $rows): Collection {
                return $rows
                    ->pluck('orderKey')
                    ->map(fn ($key) => trim((string) $key))
                    ->filter()
                    ->unique()
                    ->sort()
                    ->values();
            });

        $dtsOrderKeySet = $this->filterCachedDtsOrderKeys($orderKeysByPo->flatten())->flip();

        if ($dtsOrderKeySet->isEmpty()) {
            return null;
        }

        $orderKeys = $orderKeysByPo
            ->flatten()
            ->map(fn ($key) => trim((string) $key))
            ->filter(fn (string $key) => $dtsOrderKeySet->has($key))
            ->filter()
            ->unique()
            ->sort()
            ->values();

        if ($orderKeys->isEmpty()) {
            return null;
        }

        $orderMetricsByKey = $this->fetchOrderMetricsForRows(
            $filteredOrderRows
                ->filter(fn (PMHubOrderTracker $row): bool => $this->isCachedDtsOrderKey($row->orderKey))
                ->values()
        );

        $rows = $poNumbers
            ->map(function (string $poNumber) use (
                $orderKeysByPo,
                $dtsOrderKeySet,
                $orderMetricsByKey,
                $defaultDeliverToAddress
            ): ?array {
                $poOrderKeys = ($orderKeysByPo->get($poNumber) ?? collect())
                    ->map(fn ($key) => trim((string) $key))
                    ->filter(fn (string $key) => $dtsOrderKeySet->has($key))
                    ->filter()
                    ->unique()
                    ->sort()
                    ->values();

                if ($poOrderKeys->isEmpty()) {
                    return null;
                }

                $poAmountTotal = (float) $poOrderKeys->sum(function (string $orderKey) use ($orderMetricsByKey) {
                    return (float) (($orderMetricsByKey->get($orderKey)['po_amount_total'] ?? 0));
                });

                if ($poAmountTotal <= 0) {
                    return null;
                }

                return [
                    'po_number' => $poNumber,
                    'order_keys' => $poOrderKeys->all(),
                    'po_amount_total' => $poAmountTotal,
                    'po_amount_display' => $this->formatPoAmount($poAmountTotal),
                    'deliver_to_address' => $defaultDeliverToAddress ?: '[Deliver To Address]',
                ];
            })
            ->filter()
            ->values();

        if ($rows->isEmpty()) {
            return null;
        }

        $poAmountTotal = (float) $rows->sum(fn (array $row) => (float) $row['po_amount_total']);

        return [
            'order_keys' => $orderKeys->all(),
            'po_numbers' => $poNumbers->all(),
            'po_numbers_display' => $poNumbers->implode(', '),
            'po_amount_total' => $poAmountTotal,
            'po_amount_display' => $this->formatPoAmount($poAmountTotal),
            'sales_rep_label' => $this->salesRepLabelForOrderKeys($orderKeys->all()),
            'rows' => $rows->all(),
        ];
    }

    private function buildForcedPoData(
        DatasyncPMHubTracker $tracker,
        Collection $orderRows,
        array $candidatePoNumbers,
        ?string $defaultDeliverToAddress = null
    ): ?array {
        $poNumbers = collect($candidatePoNumbers)
            ->map(fn ($po) => trim((string) $po))
            ->filter()
            ->unique()
            ->sort()
            ->values();

        if ($poNumbers->isEmpty()) {
            $poNumbers = collect(['TRACKER-'.trim((string) ($tracker->trackerNumber ?: $this->forcedTrackerNumber))]);
        }

        $orderKeys = $orderRows
            ->pluck('orderKey')
            ->map(fn ($key) => trim((string) $key))
            ->filter()
            ->unique()
            ->sort()
            ->values();

        $orderMetricsByKey = $this->fetchOrderMetricsForRows($orderRows);
        $deliverToAddress = $defaultDeliverToAddress ?: '[Deliver To Address]';
        $forDisplay = (string) (
            ($tracker->accountName ?: '[CUSTOMER NAME]')
            .' (Account #'
            .($tracker->accountId ?: '[ACCOUNT #]')
            .')'
        );

        $rows = $poNumbers
            ->map(function (string $poNumber) use ($orderRows, $orderMetricsByKey, $deliverToAddress, $forDisplay): array {
                $poOrderKeys = $orderRows
                    ->filter(function (PMHubOrderTracker $row) use ($poNumber): bool {
                        return trim((string) $row->customerPurchaseOrderNumber) === $poNumber;
                    })
                    ->pluck('orderKey')
                    ->map(fn ($key) => trim((string) $key))
                    ->filter()
                    ->unique()
                    ->sort()
                    ->values();

                $poAmountTotal = (float) $poOrderKeys->sum(function (string $orderKey) use ($orderMetricsByKey) {
                    return (float) ($orderMetricsByKey->get($orderKey)['po_amount_total'] ?? 0);
                });

                return [
                    'po_number' => $poNumber,
                    'order_keys' => $poOrderKeys->all(),
                    'po_amount_total' => $poAmountTotal,
                    'po_amount_display' => $this->formatPoAmount($poAmountTotal),
                    'deliver_to_address' => $deliverToAddress,
                    'for_display' => $forDisplay,
                ];
            })
            ->values();

        if ($rows->isEmpty()) {
            $rows = collect([[
                'po_number' => trim((string) ($poNumbers->first() ?? 'TRACKER-'.$this->forcedTrackerNumber)),
                'order_keys' => $orderKeys->all(),
                'po_amount_total' => 0,
                'po_amount_display' => $this->formatPoAmount(0),
                'deliver_to_address' => $deliverToAddress,
                'for_display' => $forDisplay,
            ]]);
        }

        $poAmountTotal = (float) $rows->sum(fn (array $row) => (float) $row['po_amount_total']);

        return [
            'order_keys' => $orderKeys->all(),
            'po_numbers' => $poNumbers->all(),
            'po_numbers_display' => $poNumbers->implode(', '),
            'po_amount_total' => $poAmountTotal,
            'po_amount_display' => $this->formatPoAmount($poAmountTotal),
            'sales_rep_label' => $orderKeys->isNotEmpty()
                ? $this->salesRepLabelForOrderKeys($orderKeys->all())
                : '[Unavailable]',
            'rows' => $rows->all(),
        ];
    }

    private function fetchOrderMetricsForRows(Collection $orderRows): Collection
    {
        if ($orderRows->isEmpty()) {
            return collect();
        }

        $requestedOrderKeys = $orderRows
            ->pluck('orderKey')
            ->map(fn ($key) => trim((string) $key))
            ->filter()
            ->unique()
            ->values();

        if ($requestedOrderKeys->isEmpty()) {
            return collect();
        }

        $this->primeOrderMetricsCacheFromRows($orderRows);

        return $requestedOrderKeys
            ->mapWithKeys(function (string $orderKey): array {
                return [
                    $orderKey => $this->orderMetricsCache[$orderKey] ?? [
                        'po_amount_total' => 0,
                        'has_qty_fallback' => false,
                    ],
                ];
            });
    }

    private function primeOrderMetricsCache(Collection $trackers): void
    {
        $isForcedTrackerRun = $this->isForcedTrackerRun();
        $orderRows = $trackers
            ->pluck('orderTrackers')
            ->flatten(1)
            ->filter(fn ($row) => $row instanceof PMHubOrderTracker)
            ->filter(fn (PMHubOrderTracker $row) => trim((string) $row->orderKey) !== '')
            ->filter(fn (PMHubOrderTracker $row): bool => $isForcedTrackerRun
                || $this->isCachedDtsOrderKey($row->orderKey))
            ->unique(fn (PMHubOrderTracker $row) => trim((string) $row->orderKey))
            ->values();

        if ($orderRows->isEmpty()) {
            return;
        }

        $chunkSize = max(1, $this->orderMetricsPreloadChunkSize);
        $totalRows = $orderRows->count();
        $processedRows = 0;
        $preloadStartedAt = microtime(true);

        Log::info('[PMHub DTS Tracker Alerts] Priming order metrics cache', [
            'order_rows' => $totalRows,
            'chunk_size' => $chunkSize,
        ]);

        foreach ($orderRows->chunk($chunkSize) as $chunkIndex => $chunkRows) {
            $this->primeOrderMetricsCacheFromRows($chunkRows);
            $processedRows += $chunkRows->count();

            if (($chunkIndex + 1) % 5 === 0 || $processedRows >= $totalRows) {
                Log::info('[PMHub DTS Tracker Alerts] Order metrics cache progress', [
                    'processed_order_rows' => $processedRows,
                    'total_order_rows' => $totalRows,
                    'elapsed_seconds' => round(microtime(true) - $preloadStartedAt, 3),
                ]);
            }
        }
    }

    private function primeOrderMetricsCacheFromRows(Collection $orderRows): void
    {
        $requestedOrderKeys = $orderRows
            ->map(fn ($row) => trim((string) data_get($row, 'orderKey')))
            ->filter()
            ->unique()
            ->values();

        if ($requestedOrderKeys->isEmpty()) {
            return;
        }

        $missingOrderKeys = $requestedOrderKeys
            ->reject(fn (string $orderKey) => array_key_exists($orderKey, $this->orderMetricsCache))
            ->values();

        if ($missingOrderKeys->isEmpty()) {
            return;
        }

        $missingOrderKeySet = $missingOrderKeys->flip();
        $missingOrderRows = $orderRows
            ->filter(fn ($row) => $missingOrderKeySet->has(trim((string) data_get($row, 'orderKey'))))
            ->values();

        if ($missingOrderRows->isEmpty()) {
            return;
        }

        $primaryMetrics = $this->trackerAlertRepository()->fetchOrderMetricsForRows($missingOrderRows);

        foreach ($missingOrderKeys as $orderKey) {
            $metric = $primaryMetrics->get($orderKey, []);

            $this->orderMetricsCache[$orderKey] = [
                'po_amount_total' => (float) data_get($metric, 'po_amount_total', 0),
                'has_qty_fallback' => (bool) data_get($metric, 'has_qty_fallback', false),
            ];
        }
    }

    private function createEmailIntent(
        string $emailType,
        string $dedupeKey,
        DatasyncPMHubTracker $tracker,
        string $datasyncTrackerId,
        string $datasyncTrackerNumber,
        string $pmEmail,
        array $toRecipients,
        array $ccRecipients,
        array $bccRecipients,
        array $intendedToRecipients,
        array $intendedCcRecipients,
        ?string $launchOverrideRecipient,
        string $subject,
        array $poData,
        string $bodyHtml,
        array $intentContextExtras = [],
        array $logDataExtras = [],
    ): ?object {
        if ($this->trackerAssignmentRepository()->intentExists($dedupeKey)) {
            return null;
        }

        $trackerId = $this->resolveMongoTrackerId($tracker);
        $intentContext = [
            'tracker_number' => (string) $tracker->trackerNumber,
            'datasync_pmhub_tracker_id' => $datasyncTrackerId,
            'datasync_pmhub_tracker_number' => $datasyncTrackerNumber,
            'tracker_id' => $trackerId,
            'tracker_created_date' => $tracker->trackerCreatedDate?->toDateString(),
            'order_keys' => $poData['order_keys'],
            'po_numbers' => $poData['po_numbers'],
            'email_type' => $emailType,
        ];

        if ($launchOverrideRecipient !== null) {
            $intentContext['launch_override_recipient'] = $launchOverrideRecipient;
            $intentContext['intended_to'] = $intendedToRecipients;
            $intentContext['intended_cc'] = $intendedCcRecipients;
        }

        $intentContext = array_merge($intentContext, $intentContextExtras);

        $action = $emailType === $this->introEmailType
            ? 'pmhub_tracker_intro_queued'
            : 'pmhub_tracker_follow_up_queued';

        $logData = [
            'email_type' => $emailType,
            'dedupe_key' => $dedupeKey,
            'tracker_number' => (string) $tracker->trackerNumber,
            'datasync_pmhub_tracker_id' => $datasyncTrackerId,
            'datasync_pmhub_tracker_number' => $datasyncTrackerNumber,
            'tracker_id' => $trackerId,
            'order_keys' => $poData['order_keys'],
            'po_numbers' => $poData['po_numbers'],
            'to' => $toRecipients,
            'cc' => $ccRecipients,
            'bcc' => $bccRecipients,
        ];

        if ($launchOverrideRecipient !== null) {
            $logData['launch_override_recipient'] = $launchOverrideRecipient;
            $logData['intended_to'] = $intendedToRecipients;
            $logData['intended_cc'] = $intendedCcRecipients;
        }

        $logData = array_merge($logData, $logDataExtras);

        return $this->trackerAssignmentRepository()->createEmailIntent([
            'email_type' => $emailType,
            'mailable' => EmailType::DTSTrackerAssignment,
            'related_type' => DatasyncPMHubTracker::class,
            'from_email' => $pmEmail,
            'to' => $toRecipients,
            'cc' => $ccRecipients,
            'bcc' => $bccRecipients,
            'reply_to' => [$pmEmail],
            'subject' => $subject,
            'body_html' => $bodyHtml,
            'dedupe_key' => $dedupeKey,
            'context' => $intentContext,
            'action' => $action,
            'log_data' => $logData,
        ]);
    }

    /**
     * @return array{
     *     to: array<int, string>,
     *     cc: array<int, string>,
     *     bcc: array<int, string>,
     *     intended_to: array<int, string>,
     *     intended_cc: array<int, string>,
     *     launch_override_recipient: string|null
     * }
     */
    private function resolveRecipientRouting(string $contactEmail, string $pmEmail): array
    {
        $intendedTo = [$contactEmail];
        $intendedCc = [$pmEmail];
        $overrideRecipient = Sanitizer::sanitizeEmailAddress($this->launchRecipientOverride);
        $bccRecipients = collect($this->launchBccRecipients)
            ->map(fn ($email) => Sanitizer::sanitizeEmailAddress($email))
            ->filter()
            ->unique()
            ->values()
            ->all();

        if ($overrideRecipient === null) {
            return [
                'to' => $intendedTo,
                'cc' => $intendedCc,
                'bcc' => $bccRecipients,
                'intended_to' => $intendedTo,
                'intended_cc' => $intendedCc,
                'launch_override_recipient' => null,
            ];
        }

        return [
            'to' => [$overrideRecipient],
            'cc' => [],
            'bcc' => $bccRecipients,
            'intended_to' => $intendedTo,
            'intended_cc' => $intendedCc,
            'launch_override_recipient' => $overrideRecipient,
        ];
    }

    /**
     * @param  array<int, string|null>  $primaryRecipients
     * @param  array<int, string|null>  $additionalRecipients
     * @return array<int, string>
     */
    private function buildCcRecipients(array $primaryRecipients, array $additionalRecipients = []): array
    {
        return collect(array_merge($primaryRecipients, $additionalRecipients))
            ->map(fn ($email) => Sanitizer::sanitizeEmailAddress($email))
            ->filter()
            ->unique()
            ->values()
            ->all();
    }

    private function resolveAccountManagerEmail(?DatasyncPMHubTracker $tracker): ?string
    {
        return Sanitizer::sanitizeEmailAddress($tracker?->accountManagerProfile?->email);
    }

    private function queueTrackerAssignmentMail(array $toRecipients, array $ccRecipients, array $bccRecipients, DtsTrackerAssignmentMail $mailable): void
    {
        $pending = Mail::to($toRecipients);

        if (! empty($ccRecipients)) {
            $pending->cc($ccRecipients);
        }

        if (! empty($bccRecipients)) {
            $pending->bcc($bccRecipients);
        }

        $pending->queue($mailable);
    }

    private function recordTrackerContact(
        string $datasyncTrackerId,
        string $datasyncTrackerNumber,
        string $emailType,
        array $snapshot,
        object $intent,
        array $context = [],
    ): void {
        $this->trackerAssignmentRepository()->recordTrackerContact([
            'tracker_id' => $datasyncTrackerId,
            'tracker_number' => $datasyncTrackerNumber,
            'contact_type' => DtsTrackerAssignmentMail::class,
            'email_type' => $emailType,
            'po_numbers_snapshot' => $snapshot['po_numbers'],
            'email_id' => $intent->id,
            'model_action_log_id' => $intent->model_action_log_id,
            'context' => $context,
        ]);
    }

    private function buildSnapshotDedupeKey(
        string $emailType,
        string $datasyncTrackerId,
        string $trackerNumber,
        string $snapshotHash,
        bool $forceUnique = false
    ): string {
        $key = $emailType
            .'|tracker-id:'.$datasyncTrackerId
            .'|tracker:'.$trackerNumber
            .'|snapshot:'.$snapshotHash;

        if ($forceUnique) {
            $key .= '|forced-run:'.now()->format('YmdHisv');
        }

        return $key;
    }

    private function isForcedTrackerRun(): bool
    {
        return $this->forcedTrackerNumber !== null;
    }

    private function resolveForcedPmEmail(DatasyncPMHubTracker $tracker): ?string
    {
        return Sanitizer::sanitizeEmailAddress($tracker->logisticsCoordinatorProfile?->email)
            ?: Sanitizer::sanitizeEmailAddress(config('services.msgraph.from_mailbox'))
            ?: Sanitizer::sanitizeEmailAddress(config('mail.from.address'))
            ?: 'devrequests@cmecorp.com';
    }

    private function resolveForcedContactEmail(DatasyncPMHubTracker $tracker, ?string $pmEmail): ?string
    {
        return Sanitizer::sanitizeEmailAddress($tracker->contactEmail)
            ?: Sanitizer::sanitizeEmailAddress($this->launchRecipientOverride)
            ?: $pmEmail;
    }

    private function resolvePmName(DatasyncPMHubTracker $tracker, string $pmEmail): string
    {
        $pmName = Formatter::normalizeDisplayName(
            ($tracker->logisticsCoordinatorProfile?->firstName ?? '')
            .' '
            .($tracker->logisticsCoordinatorProfile?->lastName ?? '')
        );

        return $pmName !== '' ? $pmName : $pmEmail;
    }

    private function buildTrackerMailData(DatasyncPMHubTracker $tracker): array
    {
        $accountName = Formatter::toReadableCase((string) $tracker->accountName);
        $schedulingContactName = Formatter::toReadableCase((string) $tracker->contactName);
        $schedulingContactPhone = Sanitizer::sanitizePhoneDisplay((string) $tracker->contactPhone);

        return [
            'tracker_number' => (string) $tracker->trackerNumber,
            'customer_first_name' => Formatter::extractFirstName((string) $tracker->contactName),
            'account_name' => $accountName !== '' ? $accountName : '[CUSTOMER NAME]',
            'account_id' => (string) ($tracker->accountId ?: '[ACCOUNT #]'),
            'deliver_to_address' => $this->formatDeliverToAddress($tracker),
            'scheduling_contact' => $this->formatSchedulingContact($tracker),
            'scheduling_contact_name' => $schedulingContactName !== '' ? $schedulingContactName : '[Unavailable]',
            'scheduling_contact_phone' => $schedulingContactPhone ?? '[Unavailable]',
            'scheduling_contact_email' => Sanitizer::sanitizeEmailAddress($tracker->contactEmail) ?: '[Unavailable]',
        ];
    }

    private function trackerMailData(DatasyncPMHubTracker $tracker): array
    {
        $trackerNumber = trim((string) $tracker->trackerNumber);

        if ($trackerNumber === '') {
            return $this->buildTrackerMailData($tracker);
        }

        if (array_key_exists($trackerNumber, $this->trackerMailDataCache)) {
            return $this->trackerMailDataCache[$trackerNumber];
        }

        return $this->trackerMailDataCache[$trackerNumber] = $this->buildTrackerMailData($tracker);
    }

    private function formatDeliverToAddress(DatasyncPMHubTracker $tracker): string
    {
        $shipToName = Formatter::toReadableCase((string) $tracker->customerShipToName);
        $addressPayload = $this->buildDeliverToAddressValidationPayload($tracker);
        $validatedAddress = $this->findCachedValidatedAddress($addressPayload);

        $validatedDisplay = $this->formatValidatedDeliverToAddress(
            shipToName: $shipToName,
            parsed: $validatedAddress?->parsed,
        );

        if ($validatedDisplay !== null) {
            return $validatedDisplay;
        }

        $normalizedDisplay = $this->formatNormalizedDeliverToAddress(
            shipToName: $shipToName,
            addressPayload: $addressPayload,
        );

        if ($normalizedDisplay !== null) {
            return $normalizedDisplay;
        }

        $rawCityStateZip = Address::formatCityStateZip(
            city: Formatter::toReadableCase((string) ($addressPayload['city'] ?? '')),
            state: trim((string) ($addressPayload['state'] ?? '')),
            zip: trim((string) ($addressPayload['zip'] ?? '')),
        );

        $rawParts = [
            $shipToName,
            Formatter::toReadableCase((string) ($addressPayload['address_1'] ?? '')),
            Formatter::toReadableCase((string) ($addressPayload['address_2'] ?? '')),
            $rawCityStateZip,
        ];

        $rawDisplay = Address::formatMultiline($rawParts);

        return $rawDisplay !== null ? $rawDisplay : '[Deliver To Address]';
    }

    private function buildDeliverToAddressValidationPayload(DatasyncPMHubTracker $tracker): array
    {
        return [
            'address_1' => trim((string) $tracker->customerShipToAddress1),
            'address_2' => trim((string) ($tracker->customerShipToAddress2 ?? '')),
            'city' => trim((string) $tracker->customerShipToCity),
            'state' => trim((string) $tracker->customerShipToState),
            'zip' => trim((string) $tracker->customerShipToZip),
        ];
    }

    private function formatValidatedDeliverToAddress(string $shipToName, ?array $parsed): ?string
    {
        $parsed = is_array($parsed) ? $parsed : [];

        $street = Formatter::toReadableCase((string) ($parsed['street'] ?? ''));
        $city = Formatter::toReadableCase((string) ($parsed['city'] ?? ''));
        $state = trim((string) ($parsed['state'] ?? ''));
        $zip = trim((string) ($parsed['zip'] ?? ''));

        $cityStateZip = Address::formatCityStateZip($city, $state, $zip);

        // If cached parsed data is incomplete, fall back to normalized/raw payload formatting.
        if ($street === '' && $cityStateZip === '') {
            return null;
        }

        return Address::formatMultiline([
            $shipToName,
            $street,
            $cityStateZip,
        ]);
    }

    private function formatNormalizedDeliverToAddress(string $shipToName, array $addressPayload): ?string
    {
        $normalized = Address::normalize([
            'address_1' => $addressPayload['address_1'] ?? '',
            'address_2' => $addressPayload['address_2'] ?? '',
            'city' => $addressPayload['city'] ?? '',
            'state' => $addressPayload['state'] ?? '',
            'zip' => $addressPayload['zip'] ?? '',
        ]);

        $street = Formatter::toReadableCase((string) ($normalized['street'] ?? ''));
        $city = Formatter::toReadableCase((string) ($normalized['city'] ?? ''));
        $state = trim((string) ($normalized['state'] ?? ''));
        $zip = trim((string) ($normalized['zip'] ?? ''));

        $cityStateZip = Address::formatCityStateZip($city, $state, $zip);

        return Address::formatMultiline([
            $shipToName,
            $street,
            $cityStateZip,
        ]);
    }

    private function findCachedValidatedAddress(array $addressPayload): ?object
    {
        return $this->trackerAssignmentRepository()->findValidatedAddress($addressPayload);
    }

    private function formatSchedulingContact(DatasyncPMHubTracker $tracker): string
    {
        $contactPhone = Sanitizer::sanitizePhoneDisplay((string) $tracker->contactPhone);

        $parts = [
            Formatter::toReadableCase((string) $tracker->contactName),
            $contactPhone ?? '',
            trim((string) $tracker->contactEmail),
        ];

        $parts = array_values(array_filter($parts, fn ($value) => $value !== ''));

        return ! empty($parts) ? implode(', ', $parts) : '[Scheduling Contact Unavailable]';
    }

    private function formatPoAmount(float $amount): string
    {
        return '$'.number_format(max($amount, 0), 2);
    }

    private function resolveExecutionHostName(): string
    {
        $hostName = gethostname();

        if (! is_string($hostName) || trim($hostName) === '') {
            $hostName = php_uname('n');
        }

        $hostName = trim((string) $hostName);

        return $hostName !== '' ? $hostName : 'unknown';
    }

    private function resolveExecutionIpAddress(): ?string
    {
        $hostName = gethostname();
        $fallbackIp = null;

        if (! is_string($hostName) || trim($hostName) === '') {
            return null;
        }

        $hostIps = @gethostbynamel($hostName);

        if (is_array($hostIps)) {
            foreach ($hostIps as $hostIp) {
                $hostIp = trim((string) $hostIp);

                if ($hostIp !== '' && filter_var($hostIp, FILTER_VALIDATE_IP)) {
                    if (! str_starts_with($hostIp, '127.')) {
                        return $hostIp;
                    }

                    $fallbackIp ??= $hostIp;
                }
            }

            return $fallbackIp ?? null;
        }

        $fallbackIp = trim((string) gethostbyname($hostName));

        return filter_var($fallbackIp, FILTER_VALIDATE_IP) ? $fallbackIp : null;
    }

    private function resolveExecutionIpHostname(?string $serverIp = null): ?string
    {
        if ($serverIp === null) {
            return null;
        }

        $resolvedHostName = trim((string) gethostbyaddr($serverIp));

        if ($resolvedHostName === '' || $resolvedHostName === $serverIp) {
            return null;
        }

        return $resolvedHostName;
    }

    private function renderBodyHtml(DtsTrackerAssignmentMail $mailable, string $trackerNumber, string $emailType): ?string
    {
        try {
            return $mailable->render();
        } catch (\Throwable $e) {
            Log::warning('[PMHub DTS Tracker Alerts] Failed rendering body_html; email skipped', [
                'tracker' => $trackerNumber,
                'email_type' => $emailType,
                'error' => $e->getMessage(),
            ]);

            return null;
        }
    }

    private function resolveDatasyncTrackerId(DatasyncPMHubTracker $tracker): ?string
    {
        $attributes = collect($tracker->getAttributes())
            ->mapWithKeys(function ($value, $key): array {
                return [strtolower((string) $key) => $value];
            });

        $trackerId = Sanitizer::nullableString($attributes->get('trackerid'));

        return $trackerId ?? Sanitizer::nullableString($tracker->trackerId);
    }

    private function resolveDatasyncTrackerNumber(DatasyncPMHubTracker $tracker): ?string
    {
        return Sanitizer::nullableString($tracker->trackerNumber);
    }

    private function queueTrackerFirstCustomerContactDate(DatasyncPMHubTracker $tracker): void
    {
        $trackerId = $this->resolveMongoTrackerId($tracker);

        if ($trackerId === null) {
            Log::warning('[PMHub DTS Tracker Alerts] Mongo firstCustomerContactDate skipped; trackerId missing', [
                'tracker' => (string) $tracker->trackerNumber,
            ]);

            return;
        }

        $this->pendingMongoTrackerContactDates[$trackerId] = [
            'tracker_id' => $trackerId,
            'tracker_number' => (string) $tracker->trackerNumber,
        ];
    }

    private function flushPendingTrackerFirstCustomerContactDates(): void
    {
        if ($this->pendingMongoTrackerContactDates === []) {
            return;
        }

        $pendingTrackerContactDates = $this->pendingMongoTrackerContactDates;
        $this->pendingMongoTrackerContactDates = [];
        $trackerDocumentIds = collect(array_keys($pendingTrackerContactDates))
            ->map(function (int|string $trackerId): string|ObjectId {
                $trackerId = (string) $trackerId;

                return preg_match('/^[a-f0-9]{24}$/i', $trackerId) === 1
                    ? new ObjectId($trackerId)
                    : $trackerId;
            })
            ->all();

        try {
            $collection = app(MongoClient::class)->collection('Trackers');
            $update = [
                '$set' => [
                    'firstCustomerContactDate' => new UTCDateTime((int) now('UTC')->valueOf()),
                ],
            ];
            $result = count($trackerDocumentIds) === 1
                ? $collection->updateOne(['_id' => $trackerDocumentIds[0]], $update)
                : $collection->updateMany(['_id' => ['$in' => $trackerDocumentIds]], $update);

            if ($result->getMatchedCount() < count($trackerDocumentIds)) {
                Log::warning('[PMHub DTS Tracker Alerts] Mongo firstCustomerContactDate batch matched fewer tracker docs than requested', [
                    'requested' => count($trackerDocumentIds),
                    'matched' => $result->getMatchedCount(),
                ]);
            }
        } catch (\Throwable $e) {
            Log::warning('[PMHub DTS Tracker Alerts] Mongo firstCustomerContactDate batch write failed', [
                'requested' => count($trackerDocumentIds),
                'error' => $e->getMessage(),
            ]);
        }
    }

    private function resolveMongoTrackerId(DatasyncPMHubTracker $tracker): ?string
    {
        $attributes = collect($tracker->getAttributes())
            ->mapWithKeys(function ($value, $key): array {
                return [strtolower((string) $key) => $value];
            });

        $trackerId = Sanitizer::nullableString($attributes->get('trackerid'));

        return $trackerId ?? Sanitizer::nullableString($tracker->trackerId);
    }
}
