<?php
declare(strict_types=1);

use App\Enums\Alerts\AlertType;
use App\Services\Alerts\BoundaryPlanners\BroadcastAlertBoundaryPlanner;
use App\Services\Alerts\Formatters\DtsOver20kAlertDataFormatter;
use App\View\Emails\Alerts\DtsOver20kAlert;
use App\Services\Alerts\Collectors\Legacy\DtsOver20kAlertCollector;
use App\Services\Alerts\Legacy\RunProcessor;

return [
    // Keys are persisted in alerts.type_key; values must be explicit code definitions.
    'registry' => [
        AlertType::DtsOver20k->slug() => [
            'collector' => DtsOver20kAlertCollector::class,
            'run_processor' => RunProcessor::class,
            'email_delivery' => [
                'boundary_planner' => BroadcastAlertBoundaryPlanner::class,
                'formatter' => DtsOver20kAlertDataFormatter::class,
                'view' => DtsOver20kAlert::class,
            ],
            'definition_version' => 1,
            'legacy_tracking_name' => 'dtsOver20kAlert',
            'mail_subject' => 'Trackers with DTS-1 or DTS-3 Orders over $20K',
            'legacy_reporting' => [
                'category' => 'Alert',
                'description' => 'This alert is triggered when a tracker has a qualifying DTS-1 or DTS-3 order and the tracker is not completed by the LC or PS.',
                'frequency' => 'Single',
                'ownerEmail' => 'rthomas@cmecorp.com',
                'requestorEmail' => 'dchevrette@cmecorp.com',
            ],
        ],
    ],

    // Bracketed, comma-separated PM Hub customer IDs whose HCAADA tracker
    // assignment emails are temporarily suppressed.
    'hcaada_dts_tracker_assignment_skip' => array_values(array_filter(
        array_map(
            'trim',
            explode(',', trim((string) env('HCAADA_DTS_TRACKER_ASSIGNMENT_SKIP'), " \t\n\r\0\x0B[]")),
        ),
        fn (string $customerId): bool => $customerId !== '',
    )),
];
