<?php
declare(strict_types=1);

use App\DTO\Email\EmailAddress;
use App\DTO\Email\EmailBuildRequest;
use App\DTO\Email\Recipient;
use App\DTO\Email\Recipients;
use App\Enums\Email\EmailStatus;
use App\Enums\Email\EmailType;
use App\Listeners\Email\MarkIntentEmailSending;
use App\Listeners\Email\MarkIntentEmailSent;
use App\Mail\Builders\Alert\AlertMailBuilder;
use App\Models\Email;
use App\Models\User;
use Illuminate\Mail\Events\MessageSending;
use Illuminate\Mail\Events\MessageSent;
use Illuminate\Mail\SentMessage;
use Symfony\Component\Mailer\Envelope as SymfonyEnvelope;
use Symfony\Component\Mailer\SentMessage as SymfonySentMessage;
use Symfony\Component\Mime\Email as SymfonyEmail;

it(
    'marks the email intent as processing before it is sent',
    function (): void {
        $intent = Email::createWithBody(
            [
                'from_email' => 'sender@example.com',
                'related_type' => User::class,
                'related_id' => 1,
                'to' => ['recipient@example.com'],
                'cc' => [],
                'bcc' => [],
                'reply_to' => [],
                'email_type' => 'test.listener',
                'subject' => 'Queued message',
                'status' => EmailStatus::Queued,
                'queued_at' => now()->subMinute(),
                'attempts' => 0,
                'context' => ['boundary_key' => 'generic-mail'],
            ],
        );

        $message = (new SymfonyEmail)
            ->from('sender@example.com')
            ->to('recipient@example.com')
            ->subject('Queued message')
            ->html('<p>Message body</p>');
        $message->getHeaders()->addTextHeader('X-Email-Intent-Id', (string) $intent->id);
        $message->getHeaders()->addIdHeader('Message-ID', 'intent-message@example.com');

        app(MarkIntentEmailSending::class)->handle(new MessageSending($message));

        $intent->refresh();

        expect($intent->status)
            ->toBe(EmailStatus::Processing)
            ->and($intent->attempts)->toBe(1)
            ->and($intent->last_attempted_at)->not
            ->toBeNull()
            ->and($intent->message_id)->toBe('<intent-message@example.com>');

        $sent = new SentMessage(new SymfonySentMessage($message, SymfonyEnvelope::create($message)));
        app(MarkIntentEmailSent::class)->handle(new MessageSent($sent));
        expect($intent->refresh()->status)->toBe(EmailStatus::Sent);

        $request = new EmailBuildRequest(
            boundaryKey: 'generic-mail',
            type: EmailType::DTSOver20kAlert,
            recipients: new Recipients(new Recipient(new EmailAddress('recipient@example.com'), 'Recipient')),
            subject: 'Queued message',
            template: 'emails.alerts.dts-over-20k',
            viewData: [],
        );
        app(AlertMailBuilder::class)->build($request)
            ->withIntent($intent->id)
            ->failed(new RuntimeException('Transport failed'));
        expect($intent->refresh()->status)
            ->toBe(EmailStatus::Failed)
            ->and($intent->error_message)->toBe('Transport failed');
    },
);
