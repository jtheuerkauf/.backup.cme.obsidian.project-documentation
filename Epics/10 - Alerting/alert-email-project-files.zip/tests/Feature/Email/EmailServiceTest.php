<?php

use App\Actions\POSubmissions\RejectPOSubmission;
use App\DTO\Email\EmailAttachmentDTO;
use App\Enums\Email\EmailType;
use App\Models\Email;
use App\Models\POSubmission;
use App\Models\User;
use App\Services\API\Graph\GraphApiClient;
use App\Services\Email\EmailService;
use Illuminate\Mail\Mailable;
use function Pest\Laravel\assertDatabaseHas;

beforeEach(
    function()
    {
        config(
            [
                'queue.default' => 'sync',
                'mail.default' => 'msgraph',
                'services.msgraph.from_mailbox' => 'configured-sender@example.com',
            ],
        );

        // Mock Graph client directly (faster than Http::fake for Graph).
        $this->graph = Mockery::mock(GraphApiClient::class);

        // Default: allow Graph mail sends, return array (matches GraphApiClient signature).
        $this->graph
            ->shouldReceive('sendMail')
            ->byDefault()
            ->andReturn(['status' => 202]);

        app()->instance(GraphApiClient::class, $this->graph);
    },
);

it(
    'sends email and logs to database',
    function()
    {
        $this->graph
            ->shouldReceive('sendMail')
            ->once()
            ->withArgs(
                function(
                    string $fromMailbox,
                    array $to,
                    string $subject,
                    string $body,
                    array $options,
                )
                {
                    return $fromMailbox === 'configured-sender@example.com'
                           && $to === ['owner@example.com']
                           && $subject === 'Test Subject'
                           && $body === '<p>Hello</p>'
                           && (($options['replyTo'] ?? []) === ['no-reply@cmecorp.com']);
                },
            )
            ->andReturn(['status' => 202]);

        $email = app(EmailService::class)->sendRendered(
            to: ['owner@example.com'],
            subject: 'Test Subject',
            bodyHtml: '<p>Hello</p>',
            context: ['type' => 'test'],
        );

        expect($email)
            ->toBeInstanceOf(Email::class)
            ->and($email->status)->toBe('sent')
            ->and($email->to)->toBe(['owner@example.com'])
            ->and($email->context)->toBe(['type' => 'test'])
            ->and($email->from_email)->toBe('configured-sender@example.com');

        assertDatabaseHas(
            'emails',
            [
                'id' => $email->id,
                'status' => 'sent',
                'from_email' => 'configured-sender@example.com',
            ],
        );
    },
)->group('skipped')->skip('Needs review');

it(
    'handles attachments',
    function()
    {
        $encoded = base64_encode('test content');
        $attachment = EmailAttachmentDTO::fromArray(
            [
                'name' => 'test.txt',
                'contentType' => 'text/plain',
                'size' => strlen('test content'),
            ],
        );

        $this->graph
            ->shouldReceive('sendMail')
            ->once()
            ->withArgs(
                function(string $fromMailbox, array $to, string $subject, string $body, array $options) use ($encoded)
                {
                    $attachments = $options['attachments'] ?? [];

                    return $fromMailbox === 'configured-sender@example.com'
                           && $to === ['recipient@example.com']
                           && $subject === 'Test Subject'
                           && $body === '<p>Hello</p>'
                           && count($attachments) === 1
                           && ($attachments[0]['name'] ?? null) === 'test.txt'
                           && ($attachments[0]['contentBytes'] ?? null) === $encoded;
                },
            )
            ->andReturn(['status' => 202]);

        $email = app(EmailService::class)->sendRendered(
            to: ['recipient@example.com'],
            subject: 'Test Subject',
            bodyHtml: '<p>Hello</p>',
            context: [
                'name' => 'test.txt',
                'contentType' => 'text/plain',
                'size' => strlen('test content'),
            ],
            attachmentsMeta: [$attachment],
            attachmentsPayload: [
                [
                    'name' => 'test.txt',
                    'contentType' => 'text/plain',
                    'contentBytes' => $encoded,
                ],
            ],
        );

        expect($email->attachments)
            ->toBeArray()
            ->toHaveCount(1)
            ->toContainOnlyInstancesOf(EmailAttachmentDTO::class)
            ->and($email->attachments[0])->toBe($attachment)
            ->and($email->attachments[0]->name)->toBe('test.txt');
    },
)->group('skipped')->skip('Needs review');

it(
    'captures text body',
    function()
    {
        // Rendering is inherently heavier (Blade), but keep Graph mocked.
        $this->graph->shouldReceive('sendMail')->once()->andReturn(['status' => 202]);

        $mailable = new class extends Mailable {
            public $textView = 'emails.po-submissions.rejected';

            public function build()
            {
                return $this
                    ->view('emails.po-submissions.rejected')
                    ->text('emails.po-submissions.rejected')
                    ->with(
                        [
                            'submission' => (object)[
                                'id' => 1,
                                'quote_id' => '12345',
                                'oracle_id' => 'O123',
                                'status' => 'rejected',
                                'getAttribute' => fn($k) => $k === 'quote_id' ? '12345' : null,
                            ],
                            'reason' => 'test',
                            'email' => 'test@example.com',
                            'isOoo' => false,
                        ],
                    );
            }
        };

        $mailable->to('recipient@example.com');

        $email = app(EmailService::class)->sendMailable($mailable);

        expect($email->body_search)->not
            ->toBeNull()
            ->and($email->body_search)->toContain('12345');
    },
)->group('slow', 'skipped')->skip('Needs review');

it(
    'reject po submission uses email service',
    function()
    {
        // This path sends via Mail + MicrosoftGraphTransport -> GraphApiClient::sendMail()
        $this->graph->shouldReceive('sendMail')->once()->andReturn(['status' => 202]);

        Http::preventStrayRequests();
        Http::fake(
            [
                config('services.cpq.base_url') . '/*' => Http::response([], 200),
            ],
        );

        $submission = POSubmission::factory()->create(
            [
                'status' => 'claimed',
                'cpq_owner_email' => 'owner@example.com',
                'region' => 1,
            ],
        );

        $user = User::factory()->create(['email' => 'claimer@example.com']);

        $action = app(RejectPOSubmission::class);
        $action($submission, 'Rejected Reason', $user);

        assertDatabaseHas(
            'emails',
            [
                'to' => json_encode(['owner@example.com']),
                'subject' => 'PO Submission Rejected: ' . $submission->quote_id,
                'mailable' => EmailType::POSubmissionRejected,
                'related_type' => POSubmission::class,
                'related_id' => $submission->id,
            ],
        );
    },
)->group('slow', 'skipped')->skip('Needs review');
