<?php
declare(strict_types=1);

use App\Application\EmailDashboard\EmailCollector;
use App\Application\EmailDashboard\Filters;
use App\Enums\Email\EmailStatus;
use App\Enums\Email\EmailType;
use App\Enums\PermissionCode;
use App\Models\Email;
use App\Models\Permission;
use App\Models\User;
use App\Queries\Dashboards\EmailSearchQuery;
use App\Services\Email\EmailAccessService;
use Carbon\CarbonImmutable;

it(
    'filters email dashboard statuses using the persisted, mutually exclusive status',
    function (): void {
        $queued = makeDashboardEmail(
            EmailStatus::Queued,
            [
                'last_attempted_at' => now(),
                'error_message' => 'A stale error must not make this failed.',
            ],
        );
        $processing = makeDashboardEmail(
            EmailStatus::Processing,
            [
                'sent_at' => now(),
            ],
        );
        $sent = makeDashboardEmail(
            EmailStatus::Sent,
            [
                'error_code' => '500',
            ],
        );
        $failed = makeDashboardEmail(
            EmailStatus::Failed,
            [
                'sent_at' => now(),
            ],
        );

        foreach ([
            [EmailStatus::Queued, $queued],
            [EmailStatus::Processing, $processing],
            [EmailStatus::Sent, $sent],
            [EmailStatus::Failed, $failed],
        ] as [$status, $expected]) {
            $query = new EmailSearchQuery;
            $query->searchQuery([EmailType::OrderAcknowledgement], null, '', '', null, null);

            $ids = $query
                ->applyStatus($status)
                ->builder()
                ->pluck('id');

            expect($ids->all())->toBe([$expected->id]);
        }
    },
);

it('uses LIKE for subject and body searches and leaves non-matching emails out', function (): void {
    $subjectMatch = makeDashboardEmail(EmailStatus::Sent, [
        'subject' => 'Subject search needle',
        'body_html' => '<p>Unrelated body</p>',
    ]);
    $bodyMatch = makeDashboardEmail(EmailStatus::Sent, [
        'subject' => 'Unrelated subject',
        'body_html' => '<p>Body search needle</p>',
    ]);
    makeDashboardEmail(EmailStatus::Sent, [
        'subject' => 'Subject search',
        'body_html' => '<p>Body search</p>',
    ]);

    expect(dashboardSearchIds(search: 'subject search needle'))->toBe([$subjectMatch->id]);
    expect(dashboardSearchIds(search: 'body search needle'))->toBe([$bodyMatch->id]);
});

it('supports star wildcards in dashboard searches', function (): void {
    $match = makeDashboardEmail(EmailStatus::Sent, [
        'subject' => 'Some excellent search is string',
    ]);
    makeDashboardEmail(EmailStatus::Sent, [
        'subject' => 'Some excellent search is unrelated',
    ]);

    foreach ([
        'some search string' => '%some search string%',
        '*some search* string' => '%some search% string%',
        'some **search* * string' => '%some %search% % string%',
    ] as $search => $like) {
        $query = new EmailSearchQuery;
        $query->searchQuery(
            [EmailType::OrderAcknowledgement],
            null,
            $search,
            '',
            null,
            null,
        );

        expect($query->builder()->getBindings())->toContain($like);
    }

    expect(dashboardSearchIds(search: 'some **search* * string'))->toBe([$match->id]);
});

it('applies the mailable, address, and date filters individually', function (): void {
    $mailableMatch = makeDashboardEmail(EmailStatus::Sent);
    $otherMailable = makeDashboardEmail(EmailStatus::Sent, [
        'mailable' => EmailType::BillingHoldAlert,
    ]);

    $query = new EmailSearchQuery;
    $query->searchQuery(
        [EmailType::OrderAcknowledgement, EmailType::BillingHoldAlert],
        EmailType::OrderAcknowledgement,
        '',
        '',
        null,
        null,
    );
    expect($query->builder()->pluck('id')->all())->toBe([$mailableMatch->id]);
    expect($otherMailable->id)->not->toBeIn($query->builder()->pluck('id')->all());

    $addressMatch = makeDashboardEmail(EmailStatus::Sent, ['to' => ['filter@example.com']]);
    makeDashboardEmail(EmailStatus::Sent, ['to' => ['other@example.com']]);
    expect(dashboardSearchIds(address: 'filter@example.com'))->toBe([$addressMatch->id]);

    $dateFrom = CarbonImmutable::parse('2026-07-10');
    $dateTo = CarbonImmutable::parse('2026-07-20');
    makeDashboardEmail(EmailStatus::Sent, ['sent_at' => $dateFrom->subSecond()]);
    $dateMatch = makeDashboardEmail(EmailStatus::Sent, ['sent_at' => $dateFrom->addDay()]);
    makeDashboardEmail(EmailStatus::Sent, ['sent_at' => $dateTo->addDay()]);

    expect(dashboardSearchIds(dateFrom: $dateFrom, dateTo: $dateTo))->toBe([$dateMatch->id]);
});

it('counts every status consistently for every combination of dashboard search criteria', function (): void {
    setPermissionsTeamId(0);

    $dateFrom = CarbonImmutable::parse('2026-07-10');
    $dateTo = CarbonImmutable::parse('2026-07-20');
    $user = User::factory()->create();
    $user->givePermissionTo(Permission::factory()->create(['code' => PermissionCode::MailableAll->slug()]));
    $emails = [];

    foreach (EmailStatus::cases() as $status) {
        foreach (['subject', 'body'] as $match) {
            $emails[] = [
                'email' => makeDashboardEmail($status, dashboardSearchAttributes($status, $dateFrom, $match)),
                'mismatches' => [],
            ];
        }

        foreach (['mailable', 'search', 'address', 'date_from', 'date_to'] as $criterion) {
            $emails[] = [
                'email' => makeDashboardEmail(
                    $status,
                    dashboardSearchAttributes($status, $dateFrom, 'subject', $criterion),
                ),
                'mismatches' => [$criterion],
            ];
        }
    }

    $criteria = ['mailable', 'search', 'address', 'date_from', 'date_to'];
    for ($mask = 0; $mask < 2 ** count($criteria); $mask++) {
        $active = array_filter(
            $criteria,
            fn (int $index): bool => (bool) ($mask & (1 << $index)),
            ARRAY_FILTER_USE_KEY,
        );

        $data = (new EmailCollector(new EmailAccessService(), new EmailSearchQuery()))->execute(
            $user,
            new Filters(
                mailable: in_array('mailable', $active, true) ? EmailType::OrderAcknowledgement : null,
                status: null,
                search: in_array('search', $active, true) ? 'status count needle' : '',
                address: in_array('address', $active, true) ? 'count@example.com' : '',
                dateFrom: in_array('date_from', $active, true) ? $dateFrom : null,
                dateTo: in_array('date_to', $active, true) ? $dateTo : null,
                sortBy: 'latest_update',
                direction: SortDirection::Descending,
            ),
        );

        $expected = collect($emails)
            ->reject(fn (array $email): bool => array_intersect($active, $email['mismatches']) !== [])
            ->groupBy(fn (array $email): string => $email['email']->status->value)
            ->map(fn ($emails): int => $emails->count());

        expect($data->counts['all'])->toBe($expected->sum());
        foreach (EmailStatus::cases() as $status) {
            expect($data->counts[$status->value])
                ->toBe($expected->get($status->value, 0));
        }
    }
});

function makeDashboardEmail(EmailStatus $status, array $attributes = []): Email
{
    return Email::createWithBody(
        [
            'from_email' => 'sender@example.com',
            'to' => ['recipient@example.com'],
            'cc' => [],
            'bcc' => [],
            'reply_to' => [],
            'email_type' => 'test.dashboard',
            'subject' => $status->value,
            'mailable' => EmailType::OrderAcknowledgement,
            'status' => $status,
            'queued_at' => now()->subMinute(),
            'attempts' => 0,
            'context' => [],
            ...$attributes,
        ],
    );
}

function dashboardSearchIds(
    string $search = '',
    string $address = '',
    ?CarbonImmutable $dateFrom = null,
    ?CarbonImmutable $dateTo = null,
): array {
    $query = new EmailSearchQuery;
    $query->searchQuery(
        [EmailType::OrderAcknowledgement],
        null,
        $search,
        $address,
        $dateFrom,
        $dateTo,
    );

    return $query->builder()->pluck('id')->all();
}

function dashboardSearchAttributes(
    EmailStatus $status,
    CarbonImmutable $matchedAt,
    string $match,
    ?string $mismatch = null,
): array {
    $updatedAt = match ($mismatch) {
        'date_from' => $matchedAt->subDay(),
        'date_to' => $matchedAt->addDays(11),
        default => $matchedAt->addDays(2),
    };

    $timestamps = match ($status) {
        EmailStatus::Queued => ['queued_at' => $updatedAt],
        EmailStatus::Processing => ['queued_at' => $updatedAt->subMinute(), 'last_attempted_at' => $updatedAt],
        EmailStatus::Sent => ['queued_at' => $updatedAt->subMinute(), 'sent_at' => $updatedAt],
        EmailStatus::Failed => ['queued_at' => $updatedAt->subMinute(), 'last_attempted_at' => $updatedAt],
    };

    return [
        'mailable' => $mismatch === 'mailable'
            ? EmailType::BillingHoldAlert
            : EmailType::OrderAcknowledgement,
        'subject' => $match === 'subject' && $mismatch !== 'search'
            ? 'Subject status count needle'
            : 'Other subject',
        'body_html' => $match === 'body' && $mismatch !== 'search'
            ? '<p>Body status count needle</p>'
            : '<p>Other body</p>',
        'to' => [$mismatch === 'address' ? 'other@example.com' : 'count@example.com'],
        'attachments' => [],
        ...$timestamps,
    ];
}
