<?php
declare(strict_types=1);

use App\DTO\Alerts\AlertDataConfig;
use App\DTO\Alerts\AlertPreview;
use App\DTO\Alerts\AlertSourceConfig;
use App\Enums\Alerts\ScheduleType;
use App\Enums\Email\EmailStatus;
use App\Enums\ProcessStatus;
use App\Mail\BuiltMail;
use App\Models\Alerts\Alert;
use App\Models\Alerts\AlertRun;
use App\Models\Alerts\AlertSchedule;
use App\Models\Email;
use App\Services\Alerts\Interfaces\LegacyAlertCollector;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Mail;
use Illuminate\Support\Facades\Schema;

beforeEach(function (): void {
    Mail::fake();
    config()->set('database.default', 'sqlite');
    config()->set('database.connections.allrivers.driver', 'sqlite');
    config()->set('database.connections.allrivers.database', ':memory:');
    DB::purge('allrivers');

    Schema::connection('allrivers')->create('alert_run_legacy_receipts', function ($table): void {
        $table->string('idempotency_key')->primary();
        $table->string('name');
        $table->date('run_date');
        $table->unsignedInteger('line_count');
        $table->string('payload_hash');
    });
    Schema::connection('allrivers')->create('alertTracking', function ($table): void {
        $table->string('name');
        $table->date('runDate');
        $table->unsignedInteger('runCount');
        $table->unsignedInteger('totalRunCount');
        $table->unsignedInteger('lineCount');
        $table->unique(['name', 'runDate']);
    });
    Schema::connection('allrivers')->create('dimReporting', function ($table): void {
        $table->string('name')->primary();
        $table->string('category');
        $table->string('displayName');
        $table->string('description');
        $table->string('frequency');
        $table->string('ownerEmail');
        $table->string('requestorEmail');
        $table->date('createdDate');
    });

    $collector = new class implements LegacyAlertCollector
    {
        public bool $collected = false;

        /** @var array<string, mixed> */
        private array $collectedResult = [];

        public function validate(AlertDataConfig $dataConfig): void {}

        public function preview(Alert $alert, AlertDataConfig $dataConfig): AlertPreview
        {
            return new AlertPreview;
        }

        public function collect(Alert $alert, AlertRun $run, AlertDataConfig $dataConfig): void
        {
            $this->collected = true;
            $this->collectedResult = $this->resultPayload();
        }

        public function result(): array
        {
            return $this->collectedResult;
        }

        /** @return array<string, mixed> */
        private function resultPayload(): array
        {
            return [
                'status' => ProcessStatus::Succeeded,
                'rows' => [
                    [
                        'tracker_id' => 100,
                        'tracker_number' => 'T-100',
                        'tracker_created_date' => '2026-10-01',
                        'warehouse' => 'Main',
                        'logistics_coordinator_name' => 'Coordinator',
                        'project_specialist_name' => 'Specialist',
                        'account_manager_name' => 'Manager',
                        'customer_name' => 'Customer',
                        'address_1' => '1 Test Street',
                        'city' => 'Boston',
                        'state' => 'MA',
                        'zip' => '02101',
                        'dts_total_cost' => 20_001,
                        'previous_dts_total_cost' => null,
                        'customer_need_by_date' => '2026-10-15',
                        'within_two_weeks' => false,
                    ],
                ],
                'legacy_state' => [],
                'context' => ['matched_row_count' => 1],
            ];
        }

        public function restoreResult(array $result): void
        {
            $this->collectedResult = $result;
        }
    };
    config()->set('alerts.registry.dts-over-20k.collector', $collector);

    $alert = Alert::query()->create([
        'type_key' => 'dts-over-20k',
        'name' => 'DTS dispatch command test',
        'source_config' => new AlertSourceConfig([]),
        'definition_version' => 1,
        'enabled_at' => now(),
    ]);
    $schedule = $alert->schedules()->create([
        'schedule_type' => ScheduleType::Cron,
        'schedule_definition' => '0 4 * * *',
        'timezone' => 'America/New_York',
        'data_params' => ['minimum_dts_total' => 20_000],
        'next_run_at' => now()->subMinute(),
        'enabled_at' => now(),
    ]);
});

it('runs the full due alert with test recipients and isolated legacy writes', function (): void {
    $this->artisan('alerts:dispatch-due', ['--alert' => 'dts-over-20k', '--test' => true])
        ->assertExitCode(0);

    $run = AlertRun::query()->sole();
    dump($run->status, $run->context, $run->error_summary);
    $intent = Email::query()->sole();
    $schedule = AlertSchedule::query()->sole();

    expect(config('alerts.registry.dts-over-20k.collector')->collected)->toBeTrue()
        ->and($run->status)->toBe(ProcessStatus::Succeeded)
        ->and($schedule->next_run_at->greaterThan($run->scheduled_for))->toBeTrue()
        ->and($intent->related_type)->toBe(AlertRun::class)
        ->and($intent->related_id)->toBe($run->id)
        ->and($intent->to)->toHaveCount(1)
        ->and(str_ends_with($intent->to[0], '@example.test'))->toBeTrue()
        ->and($intent->status)->toBe(EmailStatus::Queued)
        ->and($intent->queued_at)->not->toBeNull()
        ->and($run->context['email_messages']['all']['status'])->toBe('queued')
        ->and(DB::connection('allrivers')->table('alert_run_legacy_receipts')->count())->toBe(1)
        ->and(DB::connection('allrivers')->table('alertTracking')->value('totalRunCount'))->toBe(1)
        ->and(DB::connection('allrivers')->table('dimReporting')->count())->toBe(1);

    Mail::assertNothingSent();
    Mail::assertQueued(BuiltMail::class, fn (BuiltMail $mail): bool => str_ends_with(
        $mail->to[0]['address'],
        '@example.test',
    ));
});

it('rejects test execution outside local and testing before changing a schedule', function (): void {
    $this->app['env'] = 'production';

    $this->artisan('alerts:dispatch-due', ['--test' => true])
        ->expectsOutput('The --test option is only available in the local or testing environment.')
        ->assertExitCode(1);

    expect(AlertRun::query()->count())->toBe(0)
        ->and(AlertSchedule::query()->sole()->next_run_at->isPast())->toBeTrue();
});

it('rejects test execution when the NewRivers host is not loopback', function (): void {
    config()->set('database.connections.mysql.host', 'prod-db.example');
    DB::purge('mysql');

    $this->artisan('alerts:dispatch-due', ['--test' => true])
        ->expectsOutput('The --test option requires the NewRivers write connection host to be localhost or 127.0.0.1.')
        ->assertExitCode(1);

    config()->set('database.connections.mysql.host', 'localhost');
    DB::purge('mysql');
    expect(AlertRun::query()->count())->toBe(0);
});

it('rejects test execution when the AllRivers host is not loopback', function (): void {
    config()->set('database.connections.allrivers.host', 'prod-db.example');
    DB::purge('allrivers');

    $this->artisan('alerts:dispatch-due', ['--test' => true])
        ->expectsOutput('The --test option requires the AllRivers write connection host to be localhost or 127.0.0.1.')
        ->assertExitCode(1);

    config()->set('database.connections.allrivers.host', 'localhost');
    DB::purge('allrivers');
    expect(AlertRun::query()->count())->toBe(0);
});

it('rejects URL-based database connections with a non-loopback host', function (): void {
    config()->set('database.connections.allrivers.url', 'mysql://prod-db.example/allrivers');
    DB::purge('allrivers');

    $this->artisan('alerts:dispatch-due', ['--test' => true])
        ->expectsOutput('The --test option requires the AllRivers write connection host to be localhost or 127.0.0.1.')
        ->assertExitCode(1);

    config()->set('database.connections.allrivers.url', null);
    DB::purge('allrivers');
    expect(AlertRun::query()->count())->toBe(0);
});

it('rejects test execution with the Microsoft Graph mailer', function (): void {
    config()->set('mail.default', 'msgraph');

    $this->artisan('alerts:dispatch-due', ['--test' => true])
        ->expectsOutput('The --test option cannot use the MS Graph mailer. Configure SMTP to use Mailpit.')
        ->assertExitCode(1);

    expect(AlertRun::query()->count())->toBe(0);
});
