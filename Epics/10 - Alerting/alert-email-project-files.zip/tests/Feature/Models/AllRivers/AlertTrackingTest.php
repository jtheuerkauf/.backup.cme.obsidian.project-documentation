<?php

use App\Models\AlertAudit;
use App\Models\AlertAuditVerification;
use App\Models\AllRivers\AlertTracking;
use App\Models\AllRivers\DimReporting;
use Illuminate\Support\Carbon;
use Illuminate\Support\Collection;

beforeEach(function () {
    Carbon::setTestNow('2025-02-01');
});

it('can create an AlertTracking record via factory', function () {
    $tracking = AlertTracking::factory()->make([
        'name'    => 'MyAlert',
        'runDate' => '2025-01-15',
    ]);

    expect($tracking->name)->toBe('MyAlert')
        ->and($tracking->runDate->format('Y-m-d'))->toBe('2025-01-15');
});

it('loads related dimReporting records', function () {
    $tracking = AlertTracking::factory()->make(['name' => 'ReportAlert']);

    $dimReporting = DimReporting::factory()->make([
        'name' => 'ReportAlert',
        'ownerEmail' => 'owner@example.com',
        'requestorEmail' => 'req@example.com',
        'displayName' => 'Owner Display',
    ]);

    $tracking->setRelation('dimReporting', new Collection([$dimReporting]));

    $related = $tracking->dimReporting;

    expect($related)->toHaveCount(1)
        ->and($related->first()->ownerEmail)->toBe('owner@example.com');
});

it('loads related alert audits', function () {
    $tracking = AlertTracking::factory()->make(['name' => 'AuditAlert']);

    $audit = AlertAudit::factory()->make([
        'name' => 'AuditAlert',
        'cadence_in_days' => 30,
        'last_verified' => null,
    ]);

    $tracking->setRelation('alertAudits', new Collection([$audit]));

    $related = $tracking->alertAudits;

    expect($related)->toHaveCount(1)
        ->and($related->first()->name)->toBe('AuditAlert');
});

it('loads related audit verifications', function () {
    $tracking = AlertTracking::factory()->make(['name' => 'VerifyAlert']);

    $verification = AlertAuditVerification::factory()->make([
        'name' => 'VerifyAlert',
        'owner_email' => 'owner@example.com',
        'requester_email' => 'req@example.com',
    ]);

    $tracking->setRelation('auditVerifications', new Collection([$verification]));

    $related = $tracking->auditVerifications;

    expect($related)->toHaveCount(1)
        ->and($related->first()->owner_email)->toBe('owner@example.com');
});
