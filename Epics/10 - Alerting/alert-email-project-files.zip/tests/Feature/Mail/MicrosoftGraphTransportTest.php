<?php

namespace Tests\Feature\Mail;

use App\DTO\Email\EmailAttachmentDTO;
use App\Enums\Email\EmailType;
use App\Enums\Email\EmailStatus;
use App\Mail\POSubmissionOnHoldMail;
use App\Mail\Transport\MicrosoftGraphTransport;
use App\Models\Email;
use App\Models\POSubmission;
use App\Services\API\Graph\GraphApiClient;
use Illuminate\Foundation\Testing\RefreshDatabase;
use Illuminate\Http\Client\RequestException;
use Illuminate\Mail\Mailable;
use Illuminate\Support\Facades\Http;
use Illuminate\Support\Facades\Mail;
use Symfony\Component\Mime\Email as SymfonyEmail;
use Tests\TestCase;
use Throwable;

class MicrosoftGraphTransportTest extends TestCase
{
    use RefreshDatabase;

    protected function setUp(): void
    {
        parent::setUp();

        Http::fake([
            'https://login.microsoftonline.com/*' => Http::response(['access_token' => 'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJzdWIiOiIxMjM0NTY3ODkwIiwibmFtZSI6IkpvaG4gRG9lIiwiaWF0IjoxNTE2MjM5MDIyfQ.SflKxwRJSMeKKF2QT4fwpMeJf36POk6yJV_adQssw5c', 'expires_in' => 3600]),
        ]);
    }

    public function test_it_sends_email_via_graph_and_logs_to_database()
    {
        $this->markTestSkipped('Needs Review.');

        config(['services.msgraph.from_mailbox' => 'configured-sender@example.com']);

        Http::fake([
            'https://graph.microsoft.com/v1.0/users/configured-sender@example.com/sendMail' => Http::response([], 202),
        ]);

        Mail::mailer('msgraph')->to('recipient@example.com')->send(
            new POSubmissionOnHoldMail(
                POSubmission::factory()->create(),
            'Wait for credit',
            'claimer@example.com'
        ));

        $this->assertDatabaseHas('emails', [
            'to' => json_encode(['recipient@example.com']),
            'from_email' => 'configured-sender@example.com',
            'status' => EmailStatus::Sent,
            'provider' => 'msgraph',
        ]);

        Http::assertSent(function ($request) {
            return str_contains($request->url(), '/users/configured-sender@example.com/sendMail') &&
                   $request['saveToSentItems'] === true &&
                   $request['message']['toRecipients'][0]['emailAddress']['address'] === 'recipient@example.com';
        });
    }

    public function test_it_uses_configured_mailbox_even_if_mailable_has_from()
    {
        $this->markTestSkipped('Needs Review.');

        config(['services.msgraph.from_mailbox' => 'configured-sender@example.com']);

        Http::fake([
            'https://graph.microsoft.com/v1.0/users/configured-sender@example.com/sendMail' => Http::response([], 202),
        ]);

        $mailable = new class extends Mailable
        {
            public function build()
            {
                return $this->view('emails.po-submissions.rejected')
                    ->from('custom-from@example.com')
                    ->with([
                        'submission' => (object)['id' => 1, 'quote_id' => 'Q123', 'status' => 'rejected', 'oracle_id' => 'O123', 'getAttribute' => fn() => 'Q123'],
                        'reason' => 'test',
                        'email' => 'test@example.com',
                        'isOoo' => false
                    ]);
            }
        };

        Mail::mailer('msgraph')->to('recipient@example.com')->send($mailable);

        Http::assertSent(function ($request) {
            return str_contains($request->url(), '/users/configured-sender@example.com/sendMail');
        });

        $this->assertDatabaseHas('emails', [
            'from_email' => 'configured-sender@example.com',
        ]);
    }

    public function test_it_handles_attachments()
    {
        Http::fake([
            'https://graph.microsoft.com/v1.0/users/*/sendMail' => Http::response([], 202),
        ]);

        $mailable = new class extends Mailable
        {
            public function build()
            {
                return $this->view('emails.po-submissions.rejected')
                    ->with([
                        'submission' => (object)['id' => 1, 'quote_id' => 'Q123', 'status' => 'rejected', 'oracle_id' => 'O123', 'getAttribute' => fn() => 'Q123'],
                        'reason' => 'test',
                        'email' => 'test@example.com',
                        'isOoo' => false
                    ])
                    ->attachData('test content', 'test.txt', ['mime' => 'text/plain']);
            }
        };

        Mail::mailer('msgraph')->to('recipient@example.com')->send($mailable);

        Http::assertSent(function ($request) {
            return !empty($request['message']['attachments']) &&
                   $request['message']['attachments'][0]['name'] === 'test.txt' &&
                   $request['message']['attachments'][0]['contentBytes'] === base64_encode('test content');
        });

        $email = Email::latest()->first();
        $this->assertIsArray($email->attachments);
        $this->assertCount(1, $email->attachments);
        $this->assertContainsOnlyInstancesOf(EmailAttachmentDTO::class, $email->attachments);
        $this->assertEquals('test.txt', $email->attachments[0]->name);
    }

    public function test_it_logs_mailable_and_related_model_metadata_for_standard_mailables()
    {
        Http::fake([
            'https://graph.microsoft.com/v1.0/users/*/sendMail' => Http::response([], 202),
        ]);

        $submission = POSubmission::factory()->create();

        Mail::mailer('msgraph')->to('recipient@example.com')->send(
            new POSubmissionOnHoldMail(
            $submission,
            'Wait for review',
            'claimer@example.com'
        ));

        $email = Email::latest()->first();

        $this->assertNotNull($email);
        $this->assertSame(EmailType::POSubmissionOnHold, $email->mailable);
        $this->assertSame(POSubmission::class, $email->related_type);
        $this->assertSame($submission->id, $email->related_id);
    }

    public function test_it_handles_failure_and_bubbles_exception()
    {
        Http::fake([
            'https://graph.microsoft.com/v1.0/users/*/sendMail' => Http::response(['error' => 'Server Error'], 500),
        ]);

        $this->expectException(RequestException::class);

        Mail::mailer('msgraph')->to('recipient@example.com')->send(
            new POSubmissionOnHoldMail(
                POSubmission::factory()->create(),
            'Wait',
            'claimer@example.com'
        ));

        $this->assertDatabaseHas('emails', [
            'status' => EmailStatus::Failed,
            'error_message' => 'HTTP request returned status code 500:',
        ]);
    }

    public function test_it_reuses_email_record_on_retry()
    {
        Http::fake([
            'https://graph.microsoft.com/v1.0/users/*/sendMail' => Http::response(['error' => 'Fail'], 500),
        ]);

        $submission = POSubmission::factory()->create();
        $mailable = new POSubmissionOnHoldMail($submission, 'Wait', 'claimer@example.com');

        // We need a stable Message-ID to test retry logic
        // Standard Laravel send generates a new one every time unless we set it.
        // For testing, we can manually use the transport.

        $symfonyEmail = new SymfonyEmail();
        $symfonyEmail->to('recipient@example.com');
        $symfonyEmail->from('sender@example.com');
        $symfonyEmail->subject('Test');
        $symfonyEmail->text('Body');
        $symfonyEmail->getHeaders()->addIdHeader('Message-ID', 'test-id@example.com');

        $transport = new MicrosoftGraphTransport(app(GraphApiClient::class));

        // Attempt 1
        try {
            $transport->send($symfonyEmail);
        } catch (Throwable) {
            // Log for debugging if needed
        }

        $this->assertDatabaseCount('emails', 1);
        $email = Email::first();
        $this->assertSame(1, $email->attempts);
        $this->assertSame(EmailStatus::Failed, $email->status);

        // Attempt 2
        try {
            $transport->send($symfonyEmail);
        } catch (Throwable) {
        }

        $this->assertDatabaseCount('emails', 1);
        $email->refresh();
        $this->assertEquals(2, $email->attempts);
    }
}
