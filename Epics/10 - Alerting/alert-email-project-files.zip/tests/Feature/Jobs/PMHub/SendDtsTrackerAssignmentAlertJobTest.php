<?php

namespace tests\Feature\Jobs\PMHub;

use App\Enums\Email\EmailType;
use App\Enums\Email\EmailStatus;
use App\Jobs\SendDtsTrackerAssignmentAlertJob;
use App\Mail\DtsTrackerAssignmentMail;
use App\Models\Datasync\PMHubTracker as DatasyncPMHubTracker;
use App\Repositories\Interfaces\PMHub\DtsTrackerAlertRepositoryInterface;
use App\Repositories\Interfaces\PMHub\DtsTrackerNotificationRepositoryInterface;
use App\Repositories\MongoDB\MongoClient;
use App\Services\Addresses\AddressValidationService;
use Carbon\Carbon;
use Illuminate\Support\Collection as SupportCollection;
use Illuminate\Support\Facades\Bus;
use Illuminate\Support\Facades\Log;
use Illuminate\Support\Facades\Mail;
use Mockery;
use MongoDB\BSON\UTCDateTime;
use MongoDB\Collection as MongoCollection;
use Tests\Fixtures\Repositories\FakeDtsTrackerAlertRepository;
use Tests\Fixtures\Repositories\FakeDtsTrackerNotificationRepository;
use Tests\TestCase;

class SendDtsTrackerAssignmentAlertJobTest extends TestCase
{
    private MongoClient $mongoClientMock;

    private MongoCollection $trackersCollectionMock;

    protected function setUp(): void
    {
        parent::setUp();

        Carbon::setTestNow(Carbon::parse('2026-02-17 10:00:00'));

        Mail::fake();
        FakeDtsTrackerNotificationRepository::bind(DtsTrackerNotificationRepositoryInterface::class);
        FakeDtsTrackerAlertRepository::bind(DtsTrackerAlertRepositoryInterface::class);
        FakeDtsTrackerNotificationRepository::seedProfile(
            profileId: '123',
            firstName: 'Sally',
            lastName: 'AM',
            email: 'sally.am@cmecorp.com'
        );

        $this->mongoClientMock = Mockery::mock(MongoClient::class);
        $this->trackersCollectionMock = Mockery::mock(MongoCollection::class);

        $this->app->instance(MongoClient::class, $this->mongoClientMock);
        $this->mongoClientMock
            ->shouldReceive('collection')
            ->with('Trackers')
            ->andReturn($this->trackersCollectionMock);

        $this->trackersCollectionMock
            ->shouldReceive('updateOne')
            ->andReturn($this->makeMongoUpdateResult(matchedCount: 1))
            ->byDefault();
        $this->trackersCollectionMock
            ->shouldReceive('updateMany')
            ->andReturn($this->makeMongoUpdateResult(matchedCount: 2))
            ->byDefault();
    }

    protected function tearDown(): void
    {
        Carbon::setTestNow();

        Mockery::close();

        parent::tearDown();
    }

    public function test_it_creates_and_sends_intro_email_intent_for_new_dts_tracker_assignment(): void
    {
        $this->seedProfile(profileId: '1', firstName: 'Jane', lastName: 'Doe (PM Reg 6)', email: 'jane.doe@cmecorp.com');
        $this->seedAccountManagerProfile();
        $this->seedAccountManager(acctMgrId: 123, name: 'Sally Calderin (PM Reg 6)');

        $this->seedTracker([
            'trackerNumber' => '900001',
            'trackerId' => 'TRK-900001',
            'trackerCreatedDate' => '2026-02-10',
            'logisticsCoordinatorId' => '1',
            'contactName' => 'MARK MILLER',
            'contactEmail' => 'mark.miller@example.com',
            'accountName' => 'ACME HEALTH',
        ]);

        $this->seedOrderTracker([
            'orderKey' => 'ORD-1',
            'trackerNumber' => '900001',
            'customerPurchaseOrderNumber' => 'PO-100',
            'orderEntryDate' => '2026-02-10',
        ]);

        $this->seedOrderMetrics(
            orderNumberKey: 'ORD-1',
            orderCustomerPOTotal: 1500.25,
            orderPrimarySalesRep: '123',
            orderNumber: '50001',
            orderCustomerNumber: '20001'
        );
        $this->seedOrderLine(orderNumberKey: 'ORD-1', orderLineSKU: 'CESS-DTS-1', orderLineQuantityOrdered: 1);

        $this->seedValidatedAddress('123 Main St', 'Boston', 'MA', '02110');

        (new SendDtsTrackerAssignmentAlertJob(trackerNumbers: ['900001']))->handle();

        $email = $this->emails()->firstWhere('email_type', 'pmhub.tracker.intro');

        $this->assertNotNull($email);
        $this->assertSame(EmailStatus::Sent, $email->status);
        $this->assertSame('CME Tracker T900001', $email->subject);
        $this->assertSame(1, $email->attempts);
        $this->assertNotNull($email->queued_at);
        $this->assertNotNull($email->last_attempted_at);
        $this->assertNotNull($email->sent_at);
        $this->assertSame(EmailType::DTSTrackerAssignment, $email->mailable);
        $this->assertSame(DatasyncPMHubTracker::class, $email->related_type);
        $this->assertNull($email->related_id);
        $this->assertStringStartsWith('pmhub.tracker.intro|tracker-id:TRK-900001|tracker:900001|snapshot:', (string) $email->dedupe_key);
        $introBody = preg_replace('/\s+/', ' ', strip_tags((string) $email->body_html)) ?? '';
        $this->assertStringContainsString("Hi Mark, thank you for choosing CME's Direct-to-Site services.", $introBody);
        $this->assertStringContainsString('My name is Jane Doe and I will be your primary point of contact as we coordinate the delivery of your equipment. I will monitor the status of all items and will reach out to schedule delivery once everything has been received in good condition. If there are any important updates, I will contact you right away.', $introBody);
        $this->assertStringContainsString('To ensure smooth delivery, please confirm all the following that apply, by replying to this email.', $introBody);
        $this->assertStringContainsString('Sally Calderin', $introBody);
        $this->assertStringNotContainsString('(PM Reg 6)', $introBody);
        $this->assertStringNotContainsString('Your CME Project Manager', $introBody);
        $this->assertStringNotContainsString('Please confirm the following by replying to this email:', $introBody);
        $this->assertStringContainsString('Required delivery date(s) and time(s) for this project', $introBody);
        $this->assertStringContainsString('Secondary on-site contact for scheduling (name, cell, email)', $introBody);
        $this->assertStringContainsString('Delivery restrictions (truck size limits, loading dock and elevator access)', $introBody);
        $this->assertStringContainsString('Safety protocols (PPE, orientation, onsite training)', $introBody);
        $this->assertStringContainsString('Wall type if mounting is included (drywall, concrete, masonry, brick, metal, or wood)', $introBody);
        $this->assertStringNotContainsString('In the meantime, if you have any questions or other updates regarding this order, please let me know.', (string) $email->body_html);
        $this->assertStringContainsString('Deliver to Address', (string) $email->body_html);
        $this->assertStringContainsString('Mark Miller<br>', (string) $email->body_html);
        $this->assertStringContainsString('Acme Health (Account #A-100)', (string) $email->body_html);
        $this->assertStringContainsString('Acme Health Warehouse<br />', (string) $email->body_html);
        $this->assertStringContainsString('123 Main St<br />', (string) $email->body_html);
        $this->assertStringContainsString('Boston, MA 02110', (string) $email->body_html);
        $this->assertStringNotContainsString('PO Total:', (string) $email->body_html);
        $this->assertStringNotContainsString('PO Amount', (string) $email->body_html);
        $this->assertSame(['jane.doe@cmecorp.com', 'sally.am@cmecorp.com'], $email->cc ?? []);
        Mail::assertQueued(DtsTrackerAssignmentMail::class);

        $contact = $this->trackerContacts()
            ->firstWhere('tracker_id', 'TRK-900001');

        $this->assertNotNull($contact);
        $this->assertSame('pmhub.tracker.intro', $contact->email_type);
        $this->assertSame(DtsTrackerAssignmentMail::class, $contact->contact_type);
        $this->assertSame('900001', $contact->tracker_number);
        $this->assertSame(['PO-100'], $contact->po_numbers_snapshot);
        $this->assertSame($email->id, $contact->email_id);

        $log = $this->modelActionLogs()->firstWhere('id', $email->model_action_log_id);
        $this->assertNotNull($log);
        $this->assertSame('pmhub_tracker_intro_queued', $log->action);
        $this->assertSame($email->id, $log->loggable_id);

        $this->trackersCollectionMock
            ->shouldHaveReceived('updateOne')
            ->with(
                ['_id' => 'TRK-900001'],
                Mockery::on(function (array $update): bool {
                    $value = data_get($update, '$set.firstCustomerContactDate');

                    return $value instanceof UTCDateTime;
                })
            )
            ->once();
    }

    public function test_it_suppresses_hcaada_assignment_intro_for_any_customer(): void
    {
        $this->seedProfile(profileId: '1', firstName: 'Jane', lastName: 'Doe', email: 'jane.doe@cmecorp.com');
        $this->seedTracker([
            'trackerNumber' => '900010',
            'trackerId' => 'TRK-900010',
            'projectName' => 'HCAADA Project 1',
            'accountId' => '262090',
            'logisticsCoordinatorId' => '1',
        ]);
        $this->seedDtsOrderTracker('900010', 'ORD-900010', 'PO-900010');

        (new SendDtsTrackerAssignmentAlertJob(trackerNumbers: ['900010']))->handle();

        $this->assertSame(0, $this->emails()->count());
        $this->assertSame(0, $this->trackerContacts()->count());
        Mail::assertNothingQueued();
    }

    public function test_it_sends_normally_for_non_hcaada_projects(): void
    {
        $this->seedProfile(profileId: '1', firstName: 'Jane', lastName: 'Doe', email: 'jane.doe@cmecorp.com');
        $this->seedTracker([
            'trackerNumber' => '900011',
            'trackerId' => 'TRK-900011',
            'projectName' => 'Regular Project 2',
            'accountId' => '999999',
            'contactEmail' => 'hcaada@example.com',
            'logisticsCoordinatorId' => '1',
        ]);
        $this->seedDtsOrderTracker('900011', 'ORD-900011', 'PO-900011');

        $this->seedTracker([
            'trackerNumber' => '900012',
            'trackerId' => 'TRK-900012',
            'projectName' => 'Regular Project',
            'accountId' => '266237',
            'contactEmail' => 'regular@example.com',
            'logisticsCoordinatorId' => '1',
        ]);
        $this->seedDtsOrderTracker('900012', 'ORD-900012', 'PO-900012');

        (new SendDtsTrackerAssignmentAlertJob(trackerNumbers: ['900011', '900012']))->handle();

        $this->assertSame(2, $this->emails()->where('email_type', 'pmhub.tracker.intro')->count());
        $this->assertSame(2, $this->trackerContacts()->count());
    }

    public function test_it_does_not_include_a_suppressed_tracker_in_a_grouped_intro(): void
    {
        $this->seedProfile(profileId: '1', firstName: 'Jane', lastName: 'Doe', email: 'jane.doe@cmecorp.com');
        $this->seedTracker([
            'trackerNumber' => '900013',
            'trackerId' => 'TRK-900013',
            'projectName' => 'HCAADA Project 3',
            'accountId' => '266237',
            'logisticsCoordinatorId' => '1',
        ]);
        $this->seedDtsOrderTracker('900013', 'ORD-900013', 'PO-900013');

        $this->seedTracker([
            'trackerNumber' => '900014',
            'trackerId' => 'TRK-900014',
            'projectName' => 'Regular Project 4',
            'accountId' => '999999',
            'logisticsCoordinatorId' => '1',
        ]);
        $this->seedDtsOrderTracker('900014', 'ORD-900014', 'PO-900013');

        (new SendDtsTrackerAssignmentAlertJob(trackerNumbers: ['900013', '900014']))->handle();

        $email = $this->emails()->firstWhere('email_type', 'pmhub.tracker.intro');

        $this->assertNotNull($email);
        $this->assertSame(1, $this->emails()->count());
        $this->assertSame(1, $this->trackerContacts()->count());
        $this->assertSame('CME Tracker T900014', $email->subject);
        $this->assertSame('TRK-900014', $this->trackerContacts()->first()->tracker_id);
        $this->assertNotSame('purchase_order_grouped_intro', data_get($email->context, 'mode'));
    }

    public function test_it_suppresses_intro_and_follow_up_for_any_hcaada_project(): void
    {
        $this->seedProfile(profileId: '1', firstName: 'Jane', lastName: 'Doe', email: 'jane.doe@cmecorp.com');
        $this->seedTracker([
            'trackerNumber' => '900015',
            'trackerId' => 'TRK-900015',
            'projectName' => 'HCAADA Project 5',
            'accountId' => '266237',
            'logisticsCoordinatorId' => '1',
        ]);
        $this->seedDtsOrderTracker('900015', 'ORD-900015-A', 'PO-900015-A');

        (new SendDtsTrackerAssignmentAlertJob(trackerNumbers: ['900015']))->handle();

        $this->seedDtsOrderTracker('900015', 'ORD-900015-B', 'PO-900015-B');

        (new SendDtsTrackerAssignmentAlertJob(trackerNumbers: ['900015']))->handle();

        $this->assertSame(0, $this->emails()->where('email_type', 'pmhub.tracker.intro')->count());
        $this->assertSame(0, $this->emails()->where('email_type', 'pmhub.tracker.follow_up')->count());
        $this->assertSame(0, $this->trackerContacts()->count());
    }

    public function test_the_coordinator_fans_out_capped_processing_batches(): void
    {
        Bus::fake();
        $this->seedProfile(profileId: '1', firstName: 'Jane', lastName: 'Doe', email: 'jane.doe@cmecorp.com');

        for ($index = 1; $index <= 21; $index++) {
            $trackerNumber = '940'.str_pad((string) $index, 3, '0', STR_PAD_LEFT);

            $this->seedTracker([
                'trackerNumber' => $trackerNumber,
                'trackerId' => 'TRK-'.$trackerNumber,
                'trackerCreatedDate' => '2026-02-10',
                'logisticsCoordinatorId' => '1',
                'contactEmail' => 'customer-'.$index.'@example.com',
            ]);
            $this->seedOrderTracker([
                'orderKey' => 'ORD-'.$trackerNumber,
                'trackerNumber' => $trackerNumber,
                'customerPurchaseOrderNumber' => 'PO-'.$trackerNumber,
                'orderEntryDate' => '2026-02-10',
            ]);
        }

        (new SendDtsTrackerAssignmentAlertJob(launchDate: '2026-02-01'))->handle();

        Bus::assertDispatched(SendDtsTrackerAssignmentAlertJob::class, 2);
        Bus::assertDispatched(SendDtsTrackerAssignmentAlertJob::class, function (SendDtsTrackerAssignmentAlertJob $job): bool {
            return $job->queue === 'default'
                && is_array($job->trackerNumbers)
                && $job->trackerNumbers !== [];
        });
        $this->assertSame(0, $this->emails()->count());
    }

    public function test_the_coordinator_isolates_a_tracker_with_more_than_twenty_order_rows(): void
    {
        Bus::fake();
        $this->seedProfile(profileId: '1', firstName: 'Jane', lastName: 'Doe', email: 'jane.doe@cmecorp.com');
        $this->seedTracker([
            'trackerNumber' => '950001',
            'trackerId' => 'TRK-950001',
            'trackerCreatedDate' => '2026-02-10',
            'logisticsCoordinatorId' => '1',
            'contactEmail' => 'customer-950001@example.com',
        ]);

        for ($index = 1; $index <= 21; $index++) {
            $this->seedOrderTracker([
                'orderKey' => 'ORD-950001-'.$index,
                'trackerNumber' => '950001',
                'customerPurchaseOrderNumber' => 'PO-950001-'.$index,
                'orderEntryDate' => '2026-02-10',
            ]);
        }

        (new SendDtsTrackerAssignmentAlertJob(launchDate: '2026-02-01'))->handle();

        Bus::assertDispatched(SendDtsTrackerAssignmentAlertJob::class, 1);
        Bus::assertDispatched(SendDtsTrackerAssignmentAlertJob::class, function (SendDtsTrackerAssignmentAlertJob $job): bool {
            return $job->queue === 'default'
                && $job->trackerNumbers === ['950001'];
        });
    }

    public function test_it_includes_the_second_ship_to_address_line(): void
    {
        $this->seedProfile(profileId: '1', firstName: 'Jane', lastName: 'Doe', email: 'jane.doe@cmecorp.com');
        $this->seedTracker([
            'trackerNumber' => '950002',
            'trackerId' => 'TRK-950002',
            'customerShipToAddress1' => '123 Main St',
            'customerShipToAddress2' => 'Suite 200',
        ]);
        $this->seedOrderTracker([
            'orderKey' => 'ORD-950002',
            'trackerNumber' => '950002',
            'customerPurchaseOrderNumber' => 'PO-950002',
        ]);
        $this->seedOrderMetrics(orderNumberKey: 'ORD-950002', orderCustomerPOTotal: 1500.00, orderPrimarySalesRep: '123');
        $this->seedOrderLine(orderNumberKey: 'ORD-950002', orderLineSKU: 'CESS-DTS-1', orderLineQuantityOrdered: 1);

        (new SendDtsTrackerAssignmentAlertJob(trackerNumbers: ['950002']))->handle();

        $email = $this->emails()->firstWhere('email_type', 'pmhub.tracker.intro');

        $this->assertNotNull($email);
        $this->assertStringContainsString('Ste 200', (string) $email->body_html);
    }

    public function test_it_sends_single_purchase_order_intro_when_multiple_new_trackers_share_po(): void
    {
        $this->seedProfile(profileId: '1', firstName: 'Jane', lastName: 'Doe', email: 'jane.doe@cmecorp.com');
        $this->seedAccountManagerProfile();
        $this->seedAccountManager(acctMgrId: 123, name: 'Sally AM');

        $this->seedTracker([
            'trackerNumber' => '910001',
            'trackerId' => 'TRK-910001',
            'trackerCreatedDate' => '2026-02-10',
            'logisticsCoordinatorId' => '1',
            'contactName' => 'MARK MILLER',
            'contactEmail' => 'mark.miller@example.com',
            'customerShipToName' => 'Acme West',
            'customerShipToAddress1' => '10 Main St',
            'customerShipToCity' => 'Irvine',
            'customerShipToState' => 'CA',
            'customerShipToZip' => '92618',
        ]);

        $this->seedTracker([
            'trackerNumber' => '910002',
            'trackerId' => 'TRK-910002',
            'trackerCreatedDate' => '2026-02-10',
            'logisticsCoordinatorId' => '1',
            'contactName' => 'MARK MILLER',
            'contactEmail' => 'mark.miller@example.com',
            'customerShipToName' => 'Acme East',
            'customerShipToAddress1' => '20 Main St',
            'customerShipToCity' => 'Boston',
            'customerShipToState' => 'MA',
            'customerShipToZip' => '02110',
        ]);

        $this->seedOrderTracker([
            'orderKey' => 'ORD-G1',
            'trackerNumber' => '910001',
            'customerPurchaseOrderNumber' => 'PO-GROUP-1',
            'orderEntryDate' => '2026-02-10',
        ]);
        $this->seedOrderTracker([
            'orderKey' => 'ORD-G2',
            'trackerNumber' => '910002',
            'customerPurchaseOrderNumber' => 'PO-GROUP-1',
            'orderEntryDate' => '2026-02-10',
        ]);

        $this->seedOrderMetrics(orderNumberKey: 'ORD-G1', orderCustomerPOTotal: 1000.00, orderPrimarySalesRep: '123');
        $this->seedOrderMetrics(orderNumberKey: 'ORD-G2', orderCustomerPOTotal: 2000.00, orderPrimarySalesRep: '123');
        $this->seedOrderLine(orderNumberKey: 'ORD-G1', orderLineSKU: 'CESS-DTS-1', orderLineQuantityOrdered: 1);
        $this->seedOrderLine(orderNumberKey: 'ORD-G2', orderLineSKU: 'CESS-DTS-1', orderLineQuantityOrdered: 1);

        (new SendDtsTrackerAssignmentAlertJob(trackerNumbers: ['910001', '910002']))->handle();

        $this->assertSame(1, FakeDtsTrackerAlertRepository::dtsOrderKeyCallCount());
        $this->assertSame(1, $this->emails()->where('email_type', 'pmhub.tracker.intro')->count());
        $this->assertSame(0, $this->emails()->where('email_type', 'pmhub.tracker.follow_up')->count());

        $email = $this->emails()->firstWhere('email_type', 'pmhub.tracker.intro');
        $this->assertNotNull($email);
        $this->assertSame('Purchase Order PO-GROUP-1', $email->subject);
        $groupedBody = preg_replace('/\s+/', ' ', strip_tags((string) $email->body_html)) ?? '';
        $this->assertStringContainsString("Hi Mark, thank you for choosing CME's Direct-to-Site services.", $groupedBody);
        $this->assertStringContainsString('My name is Jane Doe and I will be your primary point of contact as we coordinate the delivery of your equipment.', $groupedBody);
        $this->assertStringContainsString('To ensure smooth delivery, please confirm all the following that apply, by replying to this email.', $groupedBody);
        $this->assertStringContainsString('Project Details', (string) $email->body_html);
        $this->assertStringContainsString('Primary Scheduling Contact:', (string) $email->body_html);
        $this->assertStringNotContainsString('To help us prepare for a smooth delivery and installation', (string) $email->body_html);
        $this->assertStringContainsString('Required delivery date(s) and time(s) for this project', $groupedBody);
        $this->assertStringContainsString('Secondary on-site contact for scheduling (name, cell, email)', $groupedBody);
        $this->assertStringContainsString('Delivery restrictions (truck size limits, loading dock and elevator access)', $groupedBody);
        $this->assertStringContainsString('Safety protocols (PPE, orientation, onsite training)', $groupedBody);
        $this->assertStringContainsString('Wall type if mounting is included (drywall, concrete, masonry, brick, metal, or wood)', $groupedBody);
        $this->assertStringNotContainsString('Your CME Project Manager', (string) $email->body_html);
        $this->assertStringContainsString('PO-GROUP-1', (string) $email->body_html);
        $this->assertStringContainsString('T910001', (string) $email->body_html);
        $this->assertStringContainsString('T910002', (string) $email->body_html);
        $this->assertStringNotContainsString('PO Total:', (string) $email->body_html);
        $this->assertStringNotContainsString('PO Amount', (string) $email->body_html);
        $this->assertSame(['jane.doe@cmecorp.com', 'sally.am@cmecorp.com'], $email->cc ?? []);
        $this->assertSame('purchase_order_grouped_intro', data_get($email->context, 'mode'));
        $this->assertSame(2, data_get($email->context, 'group_size'));

        $firstContact = $this->trackerContacts()->where('tracker_id', 'TRK-910001')->sortByDesc('id')->first();
        $secondContact = $this->trackerContacts()->where('tracker_id', 'TRK-910002')->sortByDesc('id')->first();

        $this->assertNotNull($firstContact);
        $this->assertNotNull($secondContact);
        $this->assertSame('pmhub.tracker.intro', $firstContact->email_type);
        $this->assertSame('pmhub.tracker.intro', $secondContact->email_type);
        $this->assertSame($email->id, $firstContact->email_id);
        $this->assertSame($email->id, $secondContact->email_id);
        $this->assertSame('po_intro_grouped', data_get($firstContact->context, 'event'));
        $this->assertSame('po_intro_grouped', data_get($secondContact->context, 'event'));

        $this->trackersCollectionMock
            ->shouldHaveReceived('updateMany')
            ->with(
                ['_id' => ['$in' => ['TRK-910001', 'TRK-910002']]],
                Mockery::on(function (array $update): bool {
                    $value = data_get($update, '$set.firstCustomerContactDate');

                    return $value instanceof UTCDateTime;
                })
            )
            ->once();
    }

    public function test_it_sends_follow_up_when_new_po_is_added_after_intro(): void
    {
        $this->seedProfile(profileId: '1', firstName: 'Jane', lastName: 'Doe', email: 'jane.doe@cmecorp.com');
        $this->seedAccountManagerProfile();
        $this->seedAccountManager(acctMgrId: 123, name: 'Sally AM');

        $this->seedTracker([
            'trackerNumber' => '900002',
            'trackerId' => 'TRK-900002',
            'trackerCreatedDate' => '2026-02-10',
            'logisticsCoordinatorId' => '1',
            'contactName' => 'MARK MILLER',
            'contactEmail' => 'mark.miller@example.com',
        ]);

        $this->seedOrderTracker([
            'orderKey' => 'ORD-1',
            'trackerNumber' => '900002',
            'customerPurchaseOrderNumber' => 'PO-100',
            'orderEntryDate' => '2026-02-10',
        ]);
        $this->seedOrderMetrics(orderNumberKey: 'ORD-1', orderCustomerPOTotal: 1200.00, orderPrimarySalesRep: '123');
        $this->seedOrderLine(orderNumberKey: 'ORD-1', orderLineSKU: 'CESS-DTS-1', orderLineQuantityOrdered: 1);

        (new SendDtsTrackerAssignmentAlertJob(trackerNumbers: ['900002']))->handle();

        $this->seedOrderTracker([
            'orderKey' => 'ORD-2',
            'trackerNumber' => '900002',
            'customerPurchaseOrderNumber' => 'PO-200',
            'orderEntryDate' => '2026-02-11',
        ]);
        $this->seedOrderMetrics(orderNumberKey: 'ORD-2', orderCustomerPOTotal: 500.00, orderPrimarySalesRep: '123');
        $this->seedOrderLine(orderNumberKey: 'ORD-2', orderLineSKU: 'CESS-DTS-1', orderLineQuantityOrdered: 1);

        (new SendDtsTrackerAssignmentAlertJob(trackerNumbers: ['900002']))->handle();

        $this->assertSame(1, $this->emails()->where('email_type', 'pmhub.tracker.intro')->count());
        $this->assertSame(1, $this->emails()->where('email_type', 'pmhub.tracker.follow_up')->count());

        $followUp = $this->emails()->firstWhere('email_type', 'pmhub.tracker.follow_up');
        $this->assertNotNull($followUp);
        $this->assertSame(EmailStatus::Sent, $followUp->status);
        $this->assertSame('T900002 Add On', $followUp->subject);
        $this->assertSame(1, $followUp->attempts);
        $this->assertStringStartsWith('pmhub.tracker.follow_up|tracker-id:TRK-900002|tracker:900002|snapshot:', (string) $followUp->dedupe_key);
        $this->assertSame(['PO-200'], data_get($followUp->context, 'po_numbers'));
        $this->assertStringContainsString('Newly Added PO(s)', (string) $followUp->body_html);
        $this->assertStringContainsString('Previously Added PO(s)', (string) $followUp->body_html);
        $this->assertStringNotContainsString('PO Total:', (string) $followUp->body_html);
        $this->assertStringNotContainsString('PO Amount', (string) $followUp->body_html);
        $this->assertSame(['jane.doe@cmecorp.com', 'sally.am@cmecorp.com'], $followUp->cc ?? []);
        $this->assertStringContainsString('PO-200', (string) $followUp->body_html);
        $this->assertStringContainsString('PO-100', (string) $followUp->body_html);
        $this->assertStringContainsString('Hi Mark,', (string) $followUp->body_html);
        $this->assertStringContainsString('purchase order', strtolower((string) $followUp->body_html));
        $this->assertStringContainsString('existing project tracker 900002.', (string) $followUp->body_html);
        $this->assertStringContainsString('I am continuing to monitor your', (string) $followUp->body_html);
        $this->assertStringContainsString('project.', (string) $followUp->body_html);
        $this->assertStringContainsString('If there have been any changes to your delivery address,', (string) $followUp->body_html);
        $this->assertStringContainsString('scope of services', (string) $followUp->body_html);
        $this->assertStringContainsString('Please confirm if any of the following has changed:', (string) $followUp->body_html);
        $followUpBody = preg_replace('/\s+/', ' ', strip_tags((string) $followUp->body_html)) ?? '';
        $this->assertStringContainsString('Required delivery date(s) and time(s) for this project', $followUpBody);
        $this->assertStringContainsString('Secondary on-site contact for scheduling (name, cell, email)', $followUpBody);
        $this->assertStringContainsString('Delivery restrictions (truck size limits, loading dock and elevator access)', $followUpBody);
        $this->assertStringContainsString('Safety protocols (PPE, orientation, onsite training)', $followUpBody);
        $this->assertStringContainsString('Wall type if mounting is included (drywall, concrete, masonry, brick, metal, or wood)', $followUpBody);
        $this->assertMatchesRegularExpression(
            '/please let us know as\s+soon\s+as possible to avoid day of delivery delays\./i',
            (string) $followUp->body_html
        );
        $this->assertStringNotContainsString('My name is', (string) $followUp->body_html);
        $this->assertStringNotContainsString("Thank you for choosing CME's Direct-to-Site services.", (string) $followUp->body_html);
        $this->assertStringNotContainsString('In the meantime, if you have any questions or other updates regarding this order, please let me know.', (string) $followUp->body_html);

        $this->assertSame(
            2,
            $this->trackerContacts()->where('tracker_id', 'TRK-900002')->count()
        );

        $latestContact = $this->trackerContacts()
            ->where('tracker_id', 'TRK-900002')
            ->sortByDesc('id')
            ->first();

        $this->assertNotNull($latestContact);
        $this->assertSame('pmhub.tracker.follow_up', $latestContact->email_type);
        $this->assertSame('900002', $latestContact->tracker_number);
        $this->assertSame(['PO-100', 'PO-200'], $latestContact->po_numbers_snapshot);
        $this->assertSame(['PO-200'], data_get($latestContact->context, 'added_po_numbers'));

        $followUpActionLog = $this->modelActionLogs()
            ->where('loggable_type', DatasyncPMHubTracker::class)
            ->where('loggable_id', $followUp->id)
            ->where('action', 'pmhub_tracker_follow_up_queued')
            ->first();

        $this->assertNotNull($followUpActionLog);

        $this->trackersCollectionMock
            ->shouldHaveReceived('updateOne')
            ->with(
                ['_id' => 'TRK-900002'],
                Mockery::on(function (array $update): bool {
                    $value = data_get($update, '$set.firstCustomerContactDate');

                    return $value instanceof UTCDateTime;
                })
            )
            ->once();
    }

    public function test_it_routes_to_launch_override_recipient_when_configured(): void
    {
        $this->seedProfile(profileId: '1', firstName: 'Jane', lastName: 'Doe', email: 'jane.doe@cmecorp.com');
        $this->seedAccountManagerProfile();
        $this->seedAccountManager(acctMgrId: 123, name: 'Sally AM');

        $this->seedTracker([
            'trackerNumber' => '900007',
            'trackerId' => 'TRK-900007',
            'trackerCreatedDate' => '2026-02-10',
            'logisticsCoordinatorId' => '1',
            'contactName' => 'MARK MILLER',
            'contactEmail' => 'mark.miller@example.com',
        ]);

        $this->seedOrderTracker([
            'orderKey' => 'ORD-7',
            'trackerNumber' => '900007',
            'customerPurchaseOrderNumber' => 'PO-700',
            'orderEntryDate' => '2026-02-10',
        ]);
        $this->seedOrderMetrics(orderNumberKey: 'ORD-7', orderCustomerPOTotal: 1200.00, orderPrimarySalesRep: '123');
        $this->seedOrderLine(orderNumberKey: 'ORD-7', orderLineSKU: 'CESS-DTS-1', orderLineQuantityOrdered: 1);

        (new SendDtsTrackerAssignmentAlertJob(trackerNumbers: ['900007']))
            ->withLaunchRecipientOverride('dchevrette@cmecorp.com')
            ->withLaunchBccRecipients(['mjturner@cmecorp.com'])
            ->handle();

        $email = $this->emails()->firstWhere('email_type', 'pmhub.tracker.intro');
        $this->assertNotNull($email);
        $this->assertSame(['dchevrette@cmecorp.com'], $email->to);
        $this->assertSame([], $email->cc ?? []);
        $this->assertSame(['mjturner@cmecorp.com'], $email->bcc ?? []);
        $this->assertSame(['mark.miller@example.com'], data_get($email->context, 'intended_to'));
        $this->assertSame(['jane.doe@cmecorp.com', 'sally.am@cmecorp.com'], data_get($email->context, 'intended_cc'));
        $this->assertSame('dchevrette@cmecorp.com', data_get($email->context, 'launch_override_recipient'));
    }

    public function test_it_routes_public_recipients_with_launch_bcc_when_configured(): void
    {
        $this->seedProfile(profileId: '1', firstName: 'Jane', lastName: 'Doe', email: 'jane.doe@cmecorp.com');
        $this->seedAccountManagerProfile();
        $this->seedAccountManager(acctMgrId: 123, name: 'Sally AM');

        $this->seedTracker([
            'trackerNumber' => '900008',
            'trackerId' => 'TRK-900008',
            'trackerCreatedDate' => '2026-02-10',
            'logisticsCoordinatorId' => '1',
            'contactName' => 'MARK MILLER',
            'contactEmail' => 'mark.miller@example.com',
        ]);

        $this->seedOrderTracker([
            'orderKey' => 'ORD-8',
            'trackerNumber' => '900008',
            'customerPurchaseOrderNumber' => 'PO-800',
            'orderEntryDate' => '2026-02-10',
        ]);
        $this->seedOrderMetrics(orderNumberKey: 'ORD-8', orderCustomerPOTotal: 1200.00, orderPrimarySalesRep: '123');
        $this->seedOrderLine(orderNumberKey: 'ORD-8', orderLineSKU: 'CESS-DTS-1', orderLineQuantityOrdered: 1);

        (new SendDtsTrackerAssignmentAlertJob(trackerNumbers: ['900008']))
            ->withLaunchBccRecipients(['mjturner@cmecorp.com'])
            ->handle();

        $email = $this->emails()->firstWhere('email_type', 'pmhub.tracker.intro');
        $this->assertNotNull($email);
        $this->assertSame(['mark.miller@example.com'], $email->to);
        $this->assertSame(['jane.doe@cmecorp.com', 'sally.am@cmecorp.com'], $email->cc ?? []);
        $this->assertSame(['mjturner@cmecorp.com'], $email->bcc ?? []);
        $this->assertNull(data_get($email->context, 'launch_override_recipient'));
    }

    public function test_it_does_not_send_follow_up_when_no_new_po_exists(): void
    {
        $this->seedProfile(profileId: '1', firstName: 'Jane', lastName: 'Doe', email: 'jane.doe@cmecorp.com');

        $this->seedTracker([
            'trackerNumber' => '900003',
            'trackerId' => 'TRK-900003',
            'trackerCreatedDate' => '2026-02-10',
            'logisticsCoordinatorId' => '1',
            'contactName' => 'MARK MILLER',
            'contactEmail' => 'mark.miller@example.com',
        ]);

        $this->seedOrderTracker([
            'orderKey' => 'ORD-1',
            'trackerNumber' => '900003',
            'customerPurchaseOrderNumber' => 'PO-100',
            'orderEntryDate' => '2026-02-10',
        ]);

        $this->seedOrderMetrics(orderNumberKey: 'ORD-1', orderCustomerPOTotal: 1200.00, orderPrimarySalesRep: '123');
        $this->seedOrderLine(orderNumberKey: 'ORD-1', orderLineSKU: 'CESS-DTS-3', orderLineQuantityOrdered: 1);

        (new SendDtsTrackerAssignmentAlertJob(trackerNumbers: ['900003']))->handle();
        (new SendDtsTrackerAssignmentAlertJob(trackerNumbers: ['900003']))->handle();

        $this->assertSame(1, $this->emails()->where('email_type', 'pmhub.tracker.intro')->count());
        $this->assertSame(0, $this->emails()->where('email_type', 'pmhub.tracker.follow_up')->count());
        $this->assertSame(1, $this->trackerContacts()->where('tracker_id', 'TRK-900003')->count());

        $this->trackersCollectionMock
            ->shouldHaveReceived('updateOne')
            ->with(
                ['_id' => 'TRK-900003'],
                Mockery::on(function (array $update): bool {
                    $value = data_get($update, '$set.firstCustomerContactDate');

                    return $value instanceof UTCDateTime;
                })
            )
            ->once();
    }

    public function test_it_skips_non_dts_trackers(): void
    {
        $this->seedProfile(profileId: '1', firstName: 'Jane', lastName: 'Doe', email: 'jane.doe@cmecorp.com');

        $this->seedTracker([
            'trackerNumber' => '900004',
            'trackerId' => 'TRK-900004',
            'trackerCreatedDate' => '2026-02-10',
            'logisticsCoordinatorId' => '1',
            'contactName' => 'MARK MILLER',
            'contactEmail' => 'mark.miller@example.com',
        ]);

        $this->seedOrderTracker([
            'orderKey' => 'ORD-1',
            'trackerNumber' => '900004',
            'customerPurchaseOrderNumber' => 'PO-100',
            'orderEntryDate' => '2026-02-10',
        ]);

        $this->seedOrderMetrics(orderNumberKey: 'ORD-1', orderCustomerPOTotal: 1200.00, orderPrimarySalesRep: '123');
        $this->seedOrderLine(orderNumberKey: 'ORD-1', orderLineSKU: 'NOT-DTS-SKU', orderLineQuantityOrdered: 1);

        (new SendDtsTrackerAssignmentAlertJob(trackerNumbers: ['900004']))->handle();

        $this->assertSame(0, $this->emails()->count());
        $this->assertSame(0, $this->trackerContacts()->where('tracker_id', 'TRK-900004')->count());
        $this->trackersCollectionMock->shouldNotHaveReceived('updateOne');
    }

    public function test_it_skips_trackers_with_invalid_contact_email_before_upsert(): void
    {
        $this->seedProfile(profileId: '1', firstName: 'Jane', lastName: 'Doe', email: 'jane.doe@cmecorp.com');

        $this->seedTracker([
            'trackerNumber' => '900005',
            'trackerId' => 'TRK-900005',
            'trackerCreatedDate' => '2026-02-10',
            'logisticsCoordinatorId' => '1',
            'contactName' => 'MARK MILLER',
            'contactEmail' => '',
        ]);

        $this->seedOrderTracker([
            'orderKey' => 'ORD-1',
            'trackerNumber' => '900005',
            'customerPurchaseOrderNumber' => 'PO-100',
            'orderEntryDate' => '2026-02-10',
        ]);

        $this->seedOrderMetrics(orderNumberKey: 'ORD-1', orderCustomerPOTotal: 1200.00, orderPrimarySalesRep: '123');
        $this->seedOrderLine(orderNumberKey: 'ORD-1', orderLineSKU: 'CESS-DTS-1', orderLineQuantityOrdered: 1);

        (new SendDtsTrackerAssignmentAlertJob(trackerNumbers: ['900005']))->handle();

        $this->assertSame(0, $this->emails()->count());
        $this->assertSame(0, $this->trackerContacts()->count());
        $this->trackersCollectionMock->shouldNotHaveReceived('updateOne');
    }

    public function test_it_hides_masked_scheduling_contact_phone_placeholder(): void
    {
        $this->seedProfile(profileId: '1', firstName: 'Jane', lastName: 'Doe', email: 'jane.doe@cmecorp.com');
        $this->seedAccountManager(acctMgrId: 123, name: 'Sally AM');

        $this->seedTracker([
            'trackerNumber' => '900008',
            'trackerId' => 'TRK-900008',
            'trackerCreatedDate' => '2026-02-10',
            'logisticsCoordinatorId' => '1',
            'contactName' => 'MARK MILLER',
            'contactEmail' => 'mark.miller@example.com',
            'contactPhone' => 'xxx-xxx-xxxx',
        ]);

        $this->seedOrderTracker([
            'orderKey' => 'ORD-8',
            'trackerNumber' => '900008',
            'customerPurchaseOrderNumber' => 'PO-800',
            'orderEntryDate' => '2026-02-10',
        ]);

        $this->seedOrderMetrics(orderNumberKey: 'ORD-8', orderCustomerPOTotal: 1200.00, orderPrimarySalesRep: '123');
        $this->seedOrderLine(orderNumberKey: 'ORD-8', orderLineSKU: 'CESS-DTS-1', orderLineQuantityOrdered: 1);

        (new SendDtsTrackerAssignmentAlertJob(trackerNumbers: ['900008']))->handle();

        $email = $this->emails()->firstWhere('email_type', 'pmhub.tracker.intro');
        $this->assertNotNull($email);
        $this->assertStringNotContainsString('xxx-xxx-xxxx', (string) $email->body_html);
    }

    public function test_it_skips_intro_when_po_total_is_zero_even_with_dts_qty(): void
    {
        $this->seedProfile(profileId: '1', firstName: 'Jane', lastName: 'Doe', email: 'jane.doe@cmecorp.com');
        $this->seedAccountManager(acctMgrId: 123, name: 'Sally AM');

        $this->seedTracker([
            'trackerNumber' => '900009',
            'trackerId' => 'TRK-900009',
            'trackerCreatedDate' => '2026-02-10',
            'logisticsCoordinatorId' => '1',
            'contactName' => 'MARK MILLER',
            'contactEmail' => 'mark.miller@example.com',
        ]);

        $this->seedOrderTracker([
            'orderKey' => 'ORD-9',
            'trackerNumber' => '900009',
            'customerPurchaseOrderNumber' => 'PO-900',
            'orderEntryDate' => '2026-02-10',
        ]);

        $this->seedOrderMetrics(orderNumberKey: 'ORD-9', orderCustomerPOTotal: 0.00, orderPrimarySalesRep: '123');
        $this->seedOrderLine(orderNumberKey: 'ORD-9', orderLineSKU: 'CESS-DTS-1', orderLineQuantityOrdered: 1);

        (new SendDtsTrackerAssignmentAlertJob(trackerNumbers: ['900009']))->handle();

        $this->assertSame(0, $this->emails()->where('email_type', 'pmhub.tracker.intro')->count());
        $this->assertSame(0, $this->trackerContacts()->count());
        $this->trackersCollectionMock->shouldNotHaveReceived('updateOne');
    }

    public function test_it_omits_zero_total_rows_from_grouped_intro(): void
    {
        $this->seedProfile(profileId: '1', firstName: 'Jane', lastName: 'Doe', email: 'jane.doe@cmecorp.com');
        $this->seedAccountManager(acctMgrId: 123, name: 'Sally AM');

        $this->seedTracker([
            'trackerNumber' => '920001',
            'trackerId' => 'TRK-920001',
            'trackerCreatedDate' => '2026-02-10',
            'logisticsCoordinatorId' => '1',
            'contactName' => 'MARK MILLER',
            'contactEmail' => 'mark.miller@example.com',
        ]);

        $this->seedTracker([
            'trackerNumber' => '920002',
            'trackerId' => 'TRK-920002',
            'trackerCreatedDate' => '2026-02-10',
            'logisticsCoordinatorId' => '1',
            'contactName' => 'MARK MILLER',
            'contactEmail' => 'mark.miller@example.com',
        ]);

        $this->seedOrderTracker([
            'orderKey' => 'ORD-Z1',
            'trackerNumber' => '920001',
            'customerPurchaseOrderNumber' => 'PO-GROUP-ZERO',
            'orderEntryDate' => '2026-02-10',
        ]);
        $this->seedOrderTracker([
            'orderKey' => 'ORD-Z2',
            'trackerNumber' => '920002',
            'customerPurchaseOrderNumber' => 'PO-GROUP-ZERO',
            'orderEntryDate' => '2026-02-10',
        ]);

        $this->seedOrderMetrics(orderNumberKey: 'ORD-Z1', orderCustomerPOTotal: 1200.00, orderPrimarySalesRep: '123');
        $this->seedOrderMetrics(orderNumberKey: 'ORD-Z2', orderCustomerPOTotal: 0.00, orderPrimarySalesRep: '123');
        $this->seedOrderLine(orderNumberKey: 'ORD-Z1', orderLineSKU: 'CESS-DTS-1', orderLineQuantityOrdered: 1);
        $this->seedOrderLine(orderNumberKey: 'ORD-Z2', orderLineSKU: 'CESS-DTS-1', orderLineQuantityOrdered: 1);

        (new SendDtsTrackerAssignmentAlertJob(trackerNumbers: ['920001', '920002']))->handle();

        $this->assertSame(1, $this->emails()->where('email_type', 'pmhub.tracker.intro')->count());
        $this->assertSame(0, $this->emails()->where('subject', 'Purchase Order PO-GROUP-ZERO')->count());

        $email = $this->emails()->firstWhere('email_type', 'pmhub.tracker.intro');
        $this->assertNotNull($email);
        $this->assertSame('CME Tracker T920001', $email->subject);
        $this->assertNotSame('purchase_order_grouped_intro', data_get($email->context, 'mode'));

        $this->assertSame(1, $this->trackerContacts()->where('tracker_id', 'TRK-920001')->count());
        $this->assertSame(0, $this->trackerContacts()->where('tracker_id', 'TRK-920002')->count());
    }

    public function test_it_skips_processing_on_weekends(): void
    {
        Carbon::setTestNow(Carbon::parse('2026-02-14 10:00:00')); // Saturday

        $this->seedProfile(profileId: '1', firstName: 'Jane', lastName: 'Doe', email: 'jane.doe@cmecorp.com');

        $this->seedTracker([
            'trackerNumber' => '900006',
            'trackerId' => 'TRK-900006',
            'trackerCreatedDate' => '2026-02-14',
            'logisticsCoordinatorId' => '1',
            'contactName' => 'MARK MILLER',
            'contactEmail' => 'mark.miller@example.com',
        ]);

        $this->seedOrderTracker([
            'orderKey' => 'ORD-1',
            'trackerNumber' => '900006',
            'customerPurchaseOrderNumber' => 'PO-100',
            'orderEntryDate' => '2026-02-14',
        ]);

        $this->seedOrderMetrics(orderNumberKey: 'ORD-1', orderCustomerPOTotal: 1500.25, orderPrimarySalesRep: '123');
        $this->seedOrderLine(orderNumberKey: 'ORD-1', orderLineSKU: 'CESS-DTS-1', orderLineQuantityOrdered: 1);

        (new SendDtsTrackerAssignmentAlertJob(trackerNumbers: ['900006']))->handle();

        $this->assertSame(0, $this->emails()->count());
        $this->assertSame(0, $this->trackerContacts()->count());
        $this->trackersCollectionMock->shouldNotHaveReceived('updateOne');
    }

    public function test_it_logs_job_start_and_finish_for_successful_runs(): void
    {
        Log::spy();

        $this->seedProfile(profileId: '1', firstName: 'Jane', lastName: 'Doe', email: 'jane.doe@cmecorp.com');
        $this->seedAccountManagerProfile();
        $this->seedAccountManager(acctMgrId: 123, name: 'Sally AM');

        $this->seedTracker([
            'trackerNumber' => '930001',
            'trackerId' => 'TRK-930001',
            'trackerCreatedDate' => '2026-02-10',
            'logisticsCoordinatorId' => '1',
            'contactName' => 'MARK MILLER',
            'contactEmail' => 'mark.miller@example.com',
        ]);

        $this->seedOrderTracker([
            'orderKey' => 'ORD-930001',
            'trackerNumber' => '930001',
            'customerPurchaseOrderNumber' => 'PO-930001',
            'orderEntryDate' => '2026-02-10',
        ]);
        $this->seedOrderMetrics(orderNumberKey: 'ORD-930001', orderCustomerPOTotal: 1500.25, orderPrimarySalesRep: '123');
        $this->seedOrderLine(orderNumberKey: 'ORD-930001', orderLineSKU: 'CESS-DTS-1', orderLineQuantityOrdered: 1);

        (new SendDtsTrackerAssignmentAlertJob(trackerNumbers: ['930001']))->handle();

        $this->assertSame(1, $this->emails()->where('email_type', 'pmhub.tracker.intro')->count());

        Log::shouldHaveReceived('info')
            ->withArgs(function (string $message, array $context): bool {
                return $message === '[PMHub DTS Tracker Alerts] Job started'
                    && ($context['status'] ?? null) === 'started'
                    && ($context['environment'] ?? null) === app()->environment()
                    && is_string($context['host'] ?? null)
                    && trim((string) ($context['host'] ?? '')) !== ''
                    && ($context['server_timezone'] ?? null) === date_default_timezone_get()
                    && array_key_exists('server_ip', $context)
                    && (
                        $context['server_ip'] === null
                        || (is_string($context['server_ip']) && trim($context['server_ip']) !== '')
                    )
                    && array_key_exists('server_ip_resolved_hostname', $context)
                    && (
                        $context['server_ip_resolved_hostname'] === null
                        || (is_string($context['server_ip_resolved_hostname']) && trim($context['server_ip_resolved_hostname']) !== '')
                    );
            })
            ->once();

        Log::shouldHaveReceived('info')
            ->withArgs(function (string $message, array $context): bool {
                return $message === '[PMHub DTS Tracker Alerts] Job finished'
                    && ($context['status'] ?? null) === 'success'
                    && ($context['environment'] ?? null) === app()->environment()
                    && ($context['intro_sent'] ?? null) === 1
                    && ($context['follow_up_sent'] ?? null) === 0
                    && is_string($context['host'] ?? null)
                    && trim((string) ($context['host'] ?? '')) !== '';
            })
            ->once();

        Log::shouldNotHaveReceived('error');
    }

    public function test_it_logs_failure_context_when_tracker_loading_throws(): void
    {
        Log::spy();

        $notificationRepository = Mockery::mock(DtsTrackerNotificationRepositoryInterface::class);
        $notificationRepository
            ->shouldReceive('getTrackersForProcessing')
            ->once()
            ->andThrow(new \RuntimeException('Unable to load trackers'));

        $this->app->instance(DtsTrackerNotificationRepositoryInterface::class, $notificationRepository);

        try {
            (new SendDtsTrackerAssignmentAlertJob(trackerNumbers: ['MISSING']))->handle();
            $this->fail('Expected the job to rethrow the tracker loading exception.');
        } catch (\RuntimeException $exception) {
            $this->assertSame('Unable to load trackers', $exception->getMessage());
        }

        Log::shouldHaveReceived('info')
            ->withArgs(function (string $message, array $context): bool {
                return $message === '[PMHub DTS Tracker Alerts] Job started'
                    && ($context['status'] ?? null) === 'started'
                    && ($context['environment'] ?? null) === app()->environment()
                    && is_string($context['host'] ?? null)
                    && trim((string) ($context['host'] ?? '')) !== ''
                    && ($context['server_timezone'] ?? null) === date_default_timezone_get()
                    && array_key_exists('server_ip', $context)
                    && (
                        $context['server_ip'] === null
                        || (is_string($context['server_ip']) && trim($context['server_ip']) !== '')
                    )
                    && array_key_exists('server_ip_resolved_hostname', $context)
                    && (
                        $context['server_ip_resolved_hostname'] === null
                        || (is_string($context['server_ip_resolved_hostname']) && trim($context['server_ip_resolved_hostname']) !== '')
                    );
            })
            ->once();

        Log::shouldHaveReceived('error')
            ->withArgs(function (string $message, array $context): bool {
                return $message === '[PMHub DTS Tracker Alerts] Job failed'
                    && ($context['status'] ?? null) === 'failed'
                    && ($context['environment'] ?? null) === app()->environment()
                    && ($context['exception_class'] ?? null) === \RuntimeException::class
                    && ($context['error'] ?? null) === 'Unable to load trackers'
                    && is_string($context['host'] ?? null)
                    && trim((string) ($context['host'] ?? '')) !== '';
            })
            ->once();

        Log::shouldHaveReceived('info')
            ->withArgs(function (string $message, array $context): bool {
                return $message === '[PMHub DTS Tracker Alerts] Job finished'
                    && ($context['status'] ?? null) === 'failed'
                    && ($context['environment'] ?? null) === app()->environment()
                    && ($context['exception_class'] ?? null) === \RuntimeException::class
                    && ($context['error'] ?? null) === 'Unable to load trackers'
                    && is_string($context['host'] ?? null)
                    && trim((string) ($context['host'] ?? '')) !== '';
            })
            ->once();
    }

    private function seedProfile(string $profileId, string $firstName, string $lastName, string $email): void
    {
        FakeDtsTrackerNotificationRepository::seedProfile(
            profileId: $profileId,
            firstName: $firstName,
            lastName: $lastName,
            email: $email
        );
    }

    private function seedTracker(array $overrides = []): void
    {
        $defaults = [
            'trackerNumber' => 'T-DEFAULT',
            'trackerId' => 'TRK-DEFAULT',
            'trackerCreatedDate' => '2026-02-10',
            'projectSpecialistId' => null,
            'logisticsCoordinatorId' => '1',
            'psCompDate' => null,
            'lcCompDate' => null,
            'contactName' => 'MARK MILLER',
            'contactEmail' => 'mark.miller@example.com',
            'contactPhone' => '555-111-2222',
            'mainWarehouseId' => null,
            'whName' => null,
            'projectName' => 'Project One',
            'projectNumber' => 'PN-100',
            'accountId' => 'A-100',
            'accountName' => 'Acme Health',
            'customerShipToName' => 'Acme Health Warehouse',
            'customerShipToAddress1' => '123 Main St',
            'customerShipToCity' => 'Boston',
            'customerShipToState' => 'MA',
            'customerShipToZip' => '02110',
            'accountManagerId' => '123',
            'notes' => null,
            'capId' => null,
            'deleted' => 0,
            'lastUpdate' => now(),
        ];

        FakeDtsTrackerNotificationRepository::seedTracker(array_merge($defaults, $overrides));
    }

    private function seedOrderTracker(array $overrides = []): void
    {
        $trackerNumber = trim((string) ($overrides['trackerNumber'] ?? ''));

        $defaults = [
            'orderKey' => 'ORD-DEFAULT',
            'orderNumber' => '1000',
            'orderEntryDate' => '2026-02-10',
            'trackerNumber' => 'T-DEFAULT',
            'customerPurchaseOrderNumber' => 'PO-DEFAULT',
            'lastUpdate' => now(),
        ];

        FakeDtsTrackerNotificationRepository::seedOrderTracker($trackerNumber, array_merge($defaults, $overrides));
    }

    private function seedDtsOrderTracker(
        string $trackerNumber,
        string $orderKey,
        string $purchaseOrderNumber,
    ): void {
        $this->seedOrderTracker([
            'orderKey' => $orderKey,
            'trackerNumber' => $trackerNumber,
            'customerPurchaseOrderNumber' => $purchaseOrderNumber,
            'orderEntryDate' => '2026-02-10',
        ]);
        $this->seedOrderMetrics(orderNumberKey: $orderKey, orderCustomerPOTotal: 1000.00, orderPrimarySalesRep: '123');
        $this->seedOrderLine(orderNumberKey: $orderKey, orderLineSKU: 'CESS-DTS-1', orderLineQuantityOrdered: 1);
    }

    private function seedOrderMetrics(
        string $orderNumberKey,
        float $orderCustomerPOTotal,
        string $orderPrimarySalesRep,
        ?string $orderNumber = null,
        ?string $orderCustomerNumber = null
    ): void {
        FakeDtsTrackerAlertRepository::seedOrder(
            orderNumberKey: $orderNumberKey,
            poAmountTotal: $orderCustomerPOTotal,
            orderPrimarySalesRep: $orderPrimarySalesRep
        );
    }

    private function seedOrderLine(string $orderNumberKey, string $orderLineSKU, int $orderLineQuantityOrdered = 1): void
    {
        FakeDtsTrackerAlertRepository::seedOrderLine(
            orderNumberKey: $orderNumberKey,
            orderLineSKU: $orderLineSKU,
            orderLineQuantityOrdered: $orderLineQuantityOrdered
        );
    }

    private function seedAccountManager(int $acctMgrId, string $name): void
    {
        FakeDtsTrackerAlertRepository::seedAccountManager(
            acctMgrId: $acctMgrId,
            name: $name
        );
    }

    private function seedAccountManagerProfile(): void
    {
        FakeDtsTrackerNotificationRepository::seedProfile(
            profileId: '123',
            firstName: 'Sally',
            lastName: 'AM',
            email: 'sally.am@cmecorp.com'
        );
    }

    private function emails(): SupportCollection
    {
        return collect(FakeDtsTrackerNotificationRepository::emails())
            ->map(fn (array $email) => (object) $email)
            ->values();
    }

    private function trackerContacts(): SupportCollection
    {
        return collect(FakeDtsTrackerNotificationRepository::trackerContacts())
            ->map(fn (array $contact) => (object) $contact)
            ->values();
    }

    private function modelActionLogs(): SupportCollection
    {
        return collect(FakeDtsTrackerNotificationRepository::modelActionLogs())
            ->map(fn (array $log) => (object) $log)
            ->values();
    }

    private function seedValidatedAddress(string $street, string $city, string $state, string $zip): void
    {
        $addressPayload = [
            'address_1' => $street,
            'address_2' => '',
            'city' => $city,
            'state' => $state,
            'zip' => $zip,
        ];

        FakeDtsTrackerNotificationRepository::seedValidatedAddress(
            AddressValidationService::computeAddressHash($addressPayload),
            [
                'street' => strtoupper($street),
                'city' => strtoupper($city),
                'state' => strtoupper($state),
                'zip' => $zip,
            ],
            trim($street.' '.$city.' '.$state.' '.$zip)
        );
    }

    private function makeMongoUpdateResult(int $matchedCount): object
    {
        return new class($matchedCount)
        {
            public function __construct(private readonly int $matchedCount) {}

            public function getMatchedCount(): int
            {
                return $this->matchedCount;
            }
        };
    }
}
