<?php

use App\Enums\Email\EmailType;
use App\Enums\Email\EmailStatus;
use App\Facades\APlus;
use App\Jobs\SendBillingHoldAlertJob;
use App\Mail\BillingHoldAlertMail;
use App\Models\APlus\Order as APlusOrder;
use App\Models\Email;
use App\Models\ModelActionLog;
use App\Services\Database\APlus as APlusService;
use Carbon\Carbon;
use Illuminate\Support\Facades\Mail;

function swapAPlusFake(): Mockery\MockInterface
{
    $mock = Mockery::mock(APlusService::class);
    APlus::swap($mock);

    return $mock;
}

it('queues billing hold email and creates email intent rows', function () {
    Carbon::setTestNow('2026-03-04 10:00:00');
    Mail::fake();

    $aplus = swapAPlusFake();

    $aplus->shouldReceive('selectRaw')
        ->once()
        ->andReturn(billingHoldAplusRows());

    DB::connection('datasync')->table('pmhubOrderTracker')->insert([
        'orderKey' => '17317_260101',
        'trackerNumber' => 'T126999',
        'lastUpdate' => now(),
    ]);

    DB::connection('datasync')->table('pmhubTracker')->insert([
        'trackerNumber' => 'T126999',
        'trackerId' => 'TRK-126999',
        'projectSpecialistId' => 'PS-1',
        'logisticsCoordinatorId' => 'PM-1',
    ]);

    DB::connection('datasync')->table('pmhubProfile')->insert([
        ['profileId' => 'PS-1', 'firstName' => 'Dana', 'lastName' => 'Specialist'],
        ['profileId' => 'PM-1', 'firstName' => 'Paul', 'lastName' => 'Manager'],
    ]);

    DB::connection('datasync')->table('cleanupNotes')->insert([
        'orderKey' => '17317_260101',
        'user' => 'jdoe',
        'note' => 'Latest cleanup note',
        'createdDate' => '2026-03-03 08:00:00',
    ]);

    $job = new SendBillingHoldAlertJob;
    app()->call([$job, 'handle']);

    $email = Email::query()
        ->where('email_type', 'alerts.order.billing_hold_over_7_days')
        ->first();

    $this->assertNotNull($email);
    $this->assertSame(EmailType::BillingHoldAlert, $email->mailable);
    $this->assertSame(APlusOrder::class, $email->related_type);
    $this->assertNull($email->related_id);
    $this->assertSame(EmailStatus::Queued, $email->status);
    $this->assertSame(['billing@cmecorp.com'], $email->to);
    $this->assertSame(['kbugbee@cmecorp.com'], $email->cc ?? []);
    $this->assertSame(0, $email->attempts);
    $this->assertNotNull($email->queued_at);
    $this->assertNotNull($email->model_action_log_id);
    $this->assertStringStartsWith(
        'alerts.order.billing_hold_over_7_days|date:2026-03-04|min-days:7|snapshot:',
        (string) $email->dedupe_key
    );
    $this->assertSame(1, data_get($email->context, 'row_count'));
    $this->assertSame(['17317_260101'], data_get($email->context, 'order_keys'));
    $this->assertSame('BH', data_get($email->context, 'hold_code'));

    $this->assertDatabaseHas('model_action_logs', [
        'id' => $email->model_action_log_id,
        'loggable_type' => Email::class,
        'loggable_id' => $email->id,
        'action' => 'billing_hold_alert_queued',
    ]);

    Mail::assertQueued(BillingHoldAlertMail::class, function (BillingHoldAlertMail $mail) use ($email): bool {
        $row = $mail->rows->first();

        return $mail->hasTo('billing@cmecorp.com')
            && $mail->hasCc('kbugbee@cmecorp.com')
            && $mail->rows->count() === 1
            && str_contains((string) data_get($row, 'cleanup_note'), 'Latest cleanup note')
            && data_get($row, 'tracker_number') === 'T126999'
            && $mail->emailType === 'alerts.order.billing_hold_over_7_days'
            && $mail->dedupeKey === $email->dedupe_key
            && $mail->intentEmailId === $email->id;
    });
})->group('skipped')->skip('Needs review');

it('does not create intent rows when no data qualifies', function () {
    Carbon::setTestNow('2026-03-04 10:00:00');
    Mail::fake();

    $aplus = swapAPlusFake();

    $aplus->shouldReceive('selectRaw')
        ->once()
        ->andReturn([]);

    $job = new SendBillingHoldAlertJob;
    app()->call([$job, 'handle']);

    Mail::assertNothingQueued();
    expect(Email::query()->count())->toBe(0);
    expect(ModelActionLog::query()->count())->toBe(0);
});

it('can queue an empty preview email when sendEmpty is enabled', function () {
    Carbon::setTestNow('2026-03-04 10:00:00');
    Mail::fake();

    $aplus = swapAPlusFake();

    $aplus->shouldReceive('selectRaw')
        ->once()
        ->andReturn([]);

    $job = new SendBillingHoldAlertJob(
        ['devrequests@cmecorp.com'],
        [],
        7,
        true,
    );
    app()->call([$job, 'handle']);

    $email = Email::query()
        ->where('email_type', 'alerts.order.billing_hold_over_7_days')
        ->first();

    $this->assertNotNull($email);
    $this->assertSame(EmailStatus::Queued, $email->status);
    $this->assertSame(0, data_get($email->context, 'row_count'));
    $this->assertSame(true, data_get($email->context, 'send_empty'));

    Mail::assertQueued(BillingHoldAlertMail::class, function (BillingHoldAlertMail $mail): bool {
        return $mail->hasTo('devrequests@cmecorp.com')
            && $mail->rows->count() === 0
            && $mail->minimumDaysHeld === 7;
    });
});

it('does not age BH hold from order entry date when hold date is missing', function () {
    Carbon::setTestNow('2026-03-04 10:00:00');
    Mail::fake();

    $aplus = swapAPlusFake();

    $aplus->shouldReceive('selectRaw')
        ->once()
        ->andReturn([
            [
                'orderNum' => '71019',
                'orderGen' => '0',
                'orderEntryDate' => '250101',
                'holdCode' => 'BH',
                'customerName' => 'Sample Customer',
                'customerNum' => '100002',
                'valueAmount' => '250.00',
                'billableProduct' => '250.00',
                'billableCharge' => '0.00',
                'holdUser' => 'LL',
                'holdDate' => '',
            ],
        ]);

    $job = new SendBillingHoldAlertJob;
    app()->call([$job, 'handle']);

    Mail::assertNothingQueued();
    expect(Email::query()->count())->toBe(0);
    expect(ModelActionLog::query()->count())->toBe(0);
});

it('skips queuing duplicate intent for the same snapshot', function () {
    Carbon::setTestNow('2026-03-04 10:00:00');
    Mail::fake();

    $aplus = swapAPlusFake();

    $aplus->shouldReceive('selectRaw')
        ->twice()
        ->andReturn(
            billingHoldAplusRows(),
            billingHoldAplusRows(),
        );

    DB::connection('datasync')->table('pmhubOrderTracker')->insert([
        'orderKey' => '17317_260101',
        'trackerNumber' => 'T126999',
        'lastUpdate' => now(),
    ]);

    DB::connection('datasync')->table('pmhubTracker')->insert([
        'trackerNumber' => 'T126999',
        'trackerId' => 'TRK-126999',
        'projectSpecialistId' => 'PS-1',
        'logisticsCoordinatorId' => 'PM-1',
    ]);

    DB::connection('datasync')->table('pmhubProfile')->insert([
        ['profileId' => 'PS-1', 'firstName' => 'Dana', 'lastName' => 'Specialist'],
        ['profileId' => 'PM-1', 'firstName' => 'Paul', 'lastName' => 'Manager'],
    ]);

    DB::connection('datasync')->table('cleanupNotes')->insert([
        'orderKey' => '17317_260101',
        'user' => 'jdoe',
        'note' => 'Latest cleanup note',
        'createdDate' => '2026-03-03 08:00:00',
    ]);

    $job = new SendBillingHoldAlertJob;
    app()->call([$job, 'handle']);
    app()->call([$job, 'handle']);

    Mail::assertQueued(BillingHoldAlertMail::class, 1);
    expect(Email::query()->count())->toBe(1);
    expect(ModelActionLog::query()->count())->toBe(1);
})->group('skipped')->skip('Needs review');

function billingHoldAplusRows(): array
{
    return [
        [
            'orderNum' => '17317',
            'orderGen' => '0',
            'orderEntryDate' => '260101',
            'holdCode' => 'BH',
            'customerName' => 'Test Hospital',
            'customerNum' => '100001',
            'valueAmount' => '1000.00',
            'billableProduct' => '750.00',
            'billableCharge' => '125.00',
            'holdUser' => 'MBRAXTON',
            'holdDate' => '260101',
        ],
    ];
}
