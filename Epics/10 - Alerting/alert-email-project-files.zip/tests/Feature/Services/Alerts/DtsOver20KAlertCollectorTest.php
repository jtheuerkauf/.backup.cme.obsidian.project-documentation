<?php
declare(strict_types=1);

use App\DTO\Alerts\AlertDataConfig;
use App\DTO\Alerts\AlertSourceConfig;
use App\Enums\Alerts\ScheduleType;
use App\Enums\ProcessStatus;
use App\Models\Alerts\Alert;
use App\Models\Alerts\AlertRun;
use App\Services\Alerts\AlertRunner;
use App\Services\Alerts\Collectors\Legacy\DtsOver20kAlertCollector;
use App\Services\Alerts\Legacy\AlertTracker;
use Carbon\CarbonImmutable;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Schema;

// @formatter:off
beforeEach(function (): void {
    foreach (['datasync', 'allrivers'] as $connection) {
        config()->set("database.connections.{$connection}", [
            'driver' => 'sqlite',
            'database' => ':memory:',
            'prefix' => '',
            'foreign_key_constraints' => true,
        ]);
        DB::purge($connection);
    }

    Schema::connection('datasync')->create('aplusOrders', function (Blueprint $table): void {
        $table->string('orderNumberGenKey');
        $table->string('orderNumberKey');
    });
    Schema::connection('datasync')->create('aplusOrderDetail', function (Blueprint $table): void {
        $table->string('orderNumberGenKey');
        $table->string('orderLineSKU');
        $table->decimal('orderLineTotalCost', 12, 2);
    });
    Schema::connection('datasync')->create('pmhubOrderTracker', function (Blueprint $table): void {
        $table->string('orderKey');
        $table->string('trackerNumber');
    });
    Schema::connection('datasync')->create('pmhubTracker', function (Blueprint $table): void {
        $table->string('trackerNumber');
        $table->string('trackerId');
        $table->date('trackerCreatedDate');
        $table->string('whName')->nullable();
        $table->string('logisticsCoordinatorId')->nullable();
        $table->string('projectSpecialistId')->nullable();
        $table->string('accountManagerId')->nullable();
        $table->string('customerShipToName')->nullable();
        $table->string('customerShipToAddress1')->nullable();
        $table->string('customerShipToCity')->nullable();
        $table->string('customerShipToState')->nullable();
        $table->string('customerShipToZip')->nullable();
        $table->date('psCompDate')->nullable();
        $table->date('lcCompDate')->nullable();
        $table->boolean('deleted')->default(false);
    });
    Schema::connection('datasync')->create('pmhubLineItem', function (Blueprint $table): void {
        $table->string('trackerId');
        $table->string('itemSku');
        $table->date('customerNeedByDate')->nullable();
    });
    Schema::connection('datasync')->create('pmhubProfile', function (Blueprint $table): void {
        $table->string('profileId');
        $table->string('firstName')->nullable();
        $table->string('lastName')->nullable();
    });
    Schema::connection('allrivers')->create('dtsOver14KAlert', function (Blueprint $table): void {
        $table->string('trackerNumber')->unique();
        $table->decimal('dtsTotalCost', 12, 2);
        $table->date('customerNeedByDate')->nullable();
        $table->date('lastAlertDate');
    });
    Schema::connection('allrivers')->create('alertTracking', function (Blueprint $table): void {
        $table->string('name');
        $table->date('runDate');
        $table->unsignedInteger('runCount');
        $table->unsignedInteger('totalRunCount');
        $table->unsignedInteger('lineCount');
        $table->unique(['name', 'runDate']);
    });
    createDimReportingTable();
    (require database_path('migrations/allrivers/2026_09_29_000000_create_alert_run_legacy_receipts_table.php'))->up();
});

function createDimReportingTable(): void
{
    Schema::connection('allrivers')->create('dimReporting', function (Blueprint $table): void {
        $table->string('name')->unique();
        $table->string('category');
        $table->string('displayName');
        $table->text('description');
        $table->string('frequency');
        $table->string('ownerEmail');
        $table->string('requestorEmail');
        $table->date('createdDate');
    });
}

function writePreviousDtsAlertState(\Illuminate\Support\Collection $rows, string $date): void
{
    DB::connection('allrivers')->table('dtsOver14KAlert')->upsert(
        $rows->map(static fn (array $row): array => [
            'trackerNumber' => $row['tracker_number'],
            'dtsTotalCost' => $row['dts_total_cost'],
            'customerNeedByDate' => $row['customer_need_by_date'],
            'lastAlertDate' => $date,
        ])->all(),
        ['trackerNumber'],
        ['dtsTotalCost', 'customerNeedByDate', 'lastAlertDate'],
    );
}

function dtsDataConfig(int $minimum = 20_000): AlertDataConfig
{
    return new AlertDataConfig(
        [],
        ['minimum_dts_total' => $minimum],
    );
}

it(
    'returns new and changed synced trackers and records the legacy audit writes',
    function (): void {
        DB::connection('datasync')->table('pmhubTracker')->insert([
            'trackerNumber' => 'T-100',
            'trackerId' => '100',
            'trackerCreatedDate' => '2026-09-01',
            'whName' => 'Cleveland',
            'customerShipToName' => 'Hospital',
            'customerShipToAddress1' => '1 Main',
            'customerShipToCity' => 'Cleveland',
            'customerShipToState' => 'OH',
            'customerShipToZip' => '44101',
            'deleted' => false,
        ]);
        DB::connection('datasync')->table('aplusOrders')->insert([
            'orderNumberGenKey' => 'O-1',
            'orderNumberKey' => 'O-1',
        ]);
        DB::connection('datasync')->table('aplusOrderDetail')->insert([
            'orderNumberGenKey' => 'O-1',
            'orderLineSKU' => 'CESS-DTS-1-A',
            'orderLineTotalCost' => 21_000,
        ]);
        DB::connection('datasync')->table('pmhubOrderTracker')->insert([
            'orderKey' => 'O-1',
            'trackerNumber' => 'T-100',
        ]);
        DB::connection('datasync')->table('pmhubLineItem')->insert([
            'trackerId' => '100',
            'itemSku' => 'CESS-DTS-1-A',
            'customerNeedByDate' => '2026-09-20',
        ]);

        $today = CarbonImmutable::parse('2026-09-14')->startOfDay();
        $collector = new DtsOver20kAlertCollector($today);
        $alert = new Alert();
        $alert->type_key = \App\Enums\Alerts\AlertType::DtsOver20k;
        $alert->name = 'Trackers with DTS-1 or DTS-3 Orders over $20K';
        $alert->source_config = new AlertSourceConfig([]);
        $dataConfig = new AlertDataConfig($alert->source_config->source, ['minimum_dts_total' => 20_000]);
        $preview = $collector->preview($alert, $dataConfig);
        expect(DB::connection('allrivers')->table('dtsOver14KAlert')->count())
            ->toBe(0)
            ->and(DB::connection('allrivers')->table('alertTracking')->count())
            ->toBe(0)
            ->and(DB::connection('allrivers')->table('dimReporting')->count())
            ->toBe(0);
        $run = new AlertRun([
            'started_at' => $today,
            'scheduled_for' => $today,
            'idempotency_key' => 'dts-collector-test',
        ]);
        $collector->collect($alert, $run, $dataConfig);
        $result = $collector->result();
        $tracker = new AlertTracker();
        expect(DB::connection('allrivers')->table('dtsOver14KAlert')->count())->toBe(0);
        $applied = $tracker->track($alert, $run, $result['context']['matched_row_count'], $result['legacy_state']);
        $duplicate = $tracker->track($alert, $run, $result['context']['matched_row_count'], $result['legacy_state']);
        expect(fn () => $tracker->track($alert, $run, 0, $result['legacy_state']))
            ->toThrow(RuntimeException::class, 'Legacy receipt conflicts with this run snapshot.');

        expect($applied)->toBeTrue()
            ->and($duplicate)->toBeFalse()
            ->and((float) DB::connection('allrivers')->table('dtsOver14KAlert')->value('dtsTotalCost'))
            ->toBe(21_000.0)
            ->and($preview->headers)->toBe(['Tracker', 'DTS Total', 'Need By', 'Within Two Weeks'])
            ->and($preview->rows)->toBe([['T-100', '$21,000.00', '2026-09-20', 'Yes']])
            ->and($result['status'])->toBe(\App\Enums\ProcessStatus::Succeeded)
            ->and($result['context']['matched_row_count'])->toBe(1)
            ->and($result['context']['payload'])->toBe(['item_keys' => ['T-100']])
            ->and(DB::connection('allrivers')->table('alertTracking')->first())
            ->toMatchObject([
                'name' => 'dtsOver20kAlert',
                'runDate' => '2026-09-14',
                'runCount' => 1,
                'totalRunCount' => 1,
                'lineCount' => 1,
            ])
            ->and(DB::connection('allrivers')->table('dimReporting')->first())
            ->toMatchObject([
                'category' => 'Alert',
                'name' => 'dtsOver20kAlert',
                'displayName' => $alert->name,
                'frequency' => 'Single',
                'ownerEmail' => 'rthomas@cmecorp.com',
                'requestorEmail' => 'dchevrette@cmecorp.com',
                'createdDate' => '2026-09-14',
            ]);
    },
);

it('retries a saved collection without recounting or collecting new source rows', function (): void {
    $collector = new DtsOver20kAlertCollector(CarbonImmutable::parse('2026-09-14'));
    config()->set('alerts.registry.dts-over-20k.collector', $collector);
    $alert = Alert::query()->create([
        'type_key' => 'dts-over-20k',
        'name' => 'DTS retry test',
        'source_config' => new AlertSourceConfig([]),
        'definition_version' => 1,
        'enabled_at' => now(),
    ]);
    $schedule = $alert->schedules()->create([
        'schedule_type' => ScheduleType::Cron,
        'schedule_definition' => '0 4 * * *',
        'timezone' => 'America/New_York',
        'data_params' => ['minimum_dts_total' => 20_000],
        'next_run_at' => now()->subMinute(),
        'enabled_at' => now(),
    ]);
    $run = AlertRun::query()->create([
        'alert_id' => $alert->id,
        'alert_schedule_id' => $schedule->id,
        'scheduled_for' => now()->subMinute(),
        'started_at' => CarbonImmutable::parse('2026-09-14'),
        'status' => ProcessStatus::Queued,
        'idempotency_key' => 'retry-test',
    ]);

    app(AlertRunner::class)->run($run);
    $run->refresh();
    expect($run->context['collection_snapshot']['status'])->toBe('empty')
        ->and(DB::table('alert_run_legacy_payloads')->where('alert_run_id', $run->id)->count())->toBe(1)
        ->and(DB::connection('allrivers')->table('alertTracking')->value('totalRunCount'))->toBe(1);

    DB::connection('datasync')->table('aplusOrders')->insert([
        'orderNumberGenKey' => 'O-LATER', 'orderNumberKey' => 'O-LATER',
    ]);
    DB::connection('datasync')->table('aplusOrderDetail')->insert([
        'orderNumberGenKey' => 'O-LATER', 'orderLineSKU' => 'CESS-DTS-1-LATER', 'orderLineTotalCost' => 21_000,
    ]);
    DB::connection('datasync')->table('pmhubOrderTracker')->insert([
        'orderKey' => 'O-LATER', 'trackerNumber' => 'T-LATER',
    ]);
    DB::connection('datasync')->table('pmhubTracker')->insert([
        'trackerNumber' => 'T-LATER', 'trackerId' => 'LATER',
        'trackerCreatedDate' => '2026-09-01', 'deleted' => false,
    ]);

    $retryCollector = new DtsOver20kAlertCollector(CarbonImmutable::parse('2026-09-14'));
    config()->set('alerts.registry.dts-over-20k.collector', $retryCollector);
    app(AlertRunner::class)->run($run);
    $run->refresh();

    expect($run->context['legacy_write']['status'])->toBe('already_applied')
        ->and($run->context['matched_row_count'])->toBe(0)
        ->and($retryCollector->rows())->toBeEmpty()
        ->and($retryCollector->result()['context']['matched_row_count'])->toBe(0)
        ->and(DB::connection('allrivers')->table('alertTracking')->value('totalRunCount'))->toBe(1)
        ->and(DB::connection('allrivers')->table('alertTracking')->value('runDate'))->toBe('2026-09-14')
        ->and(DB::connection('allrivers')->table('dtsOver14KAlert')->count())->toBe(0);
});

it('rolls back the receipt and counters if a later legacy write fails', function (): void {
    $collector = new DtsOver20kAlertCollector();
    $alert = new Alert();
    $alert->type_key = \App\Enums\Alerts\AlertType::DtsOver20k;
    $run = new AlertRun([
        'started_at' => CarbonImmutable::parse('2026-09-14'),
        'scheduled_for' => CarbonImmutable::parse('2026-09-14'),
        'idempotency_key' => 'rollback-test',
    ]);
    Schema::connection('allrivers')->drop('dimReporting');

    expect(fn () => app(AlertTracker::class)->track($alert, $run, 0))
        ->toThrow(\Illuminate\Database\QueryException::class);
    expect(DB::connection('allrivers')->table('alert_run_legacy_receipts')->count())->toBe(0)
        ->and(DB::connection('allrivers')->table('alertTracking')->count())->toBe(0);
});

it('marks a legacy failure partial and retries its saved result after repair', function (): void {
    $alert = Alert::query()->create([
        'type_key' => 'dts-over-20k',
        'name' => 'DTS partial retry test',
        'source_config' => new AlertSourceConfig([]),
        'definition_version' => 1,
        'enabled_at' => now(),
    ]);
    $schedule = $alert->schedules()->create([
        'schedule_type' => ScheduleType::Cron,
        'schedule_definition' => '0 4 * * *',
        'timezone' => 'America/New_York',
        'data_params' => ['minimum_dts_total' => 20_000],
        'next_run_at' => now()->subMinute(),
        'enabled_at' => now(),
    ]);
    $run = AlertRun::query()->create([
        'alert_id' => $alert->id,
        'alert_schedule_id' => $schedule->id,
        'scheduled_for' => now()->subMinute(),
        'status' => ProcessStatus::Queued,
        'idempotency_key' => 'partial-retry-test',
    ]);
    Schema::connection('allrivers')->drop('dimReporting');

    app(AlertRunner::class)->run($run);
    $run->refresh();
    expect($run->status)->toBe(ProcessStatus::Partial)
        ->and($run->context['legacy_write']['status'])->toBe('failed')
        ->and($run->context['collection_snapshot']['status'])->toBe('empty')
        ->and(DB::connection('allrivers')->table('alert_run_legacy_receipts')->count())->toBe(0);

    createDimReportingTable();
    app(AlertRunner::class)->run($run);
    $run->refresh();
    expect($run->context['legacy_write']['status'])->toBe('succeeded')
        ->and(DB::connection('allrivers')->table('alert_run_legacy_receipts')->count())->toBe(1)
        ->and(DB::connection('allrivers')->table('alertTracking')->value('totalRunCount'))->toBe(1);
});

it('requires a positive schedule threshold', function (): void {
    $collector = new DtsOver20kAlertCollector();
    expect(fn (): mixed => $collector->validate(dtsDataConfig(0)))
        ->toThrow(InvalidArgumentException::class, 'DTS Over 20K alerts require a positive minimum_dts_total parameter.');
});

it('uses the schedule threshold for collection and preview', function (): void {
    DB::connection('datasync')->table('pmhubTracker')->insert([
        'trackerNumber' => 'T-CONFIG', 'trackerId' => 'CONFIG',
        'trackerCreatedDate' => '2026-09-01', 'deleted' => false,
    ]);
    DB::connection('datasync')->table('aplusOrders')->insert([
        'orderNumberGenKey' => 'O-CONFIG', 'orderNumberKey' => 'O-CONFIG',
    ]);
    DB::connection('datasync')->table('aplusOrderDetail')->insert([
        'orderNumberGenKey' => 'O-CONFIG', 'orderLineSKU' => 'CESS-DTS-1-CONFIG',
        'orderLineTotalCost' => 21_000,
    ]);
    DB::connection('datasync')->table('pmhubOrderTracker')->insert([
        'orderKey' => 'O-CONFIG', 'trackerNumber' => 'T-CONFIG',
    ]);

    $collector = new DtsOver20kAlertCollector(CarbonImmutable::parse('2026-09-14'));
    $alert = new Alert();
    $alert->type_key = \App\Enums\Alerts\AlertType::DtsOver20k;
    $run = new AlertRun();

    $collector->collect($alert, $run, dtsDataConfig(22_000));
    expect($collector->result()['context']['matched_row_count'])->toBe(0)
        ->and($collector->rows())->toBeEmpty()
        ->and($collector->preview($alert, dtsDataConfig(22_000))->rows)->toBe([]);

    $collector->collect($alert, $run, dtsDataConfig(20_000));
    expect($collector->result()['context']['matched_row_count'])->toBe(1)
        ->and($collector->rows())->toHaveCount(1)
        ->and($collector->preview($alert, dtsDataConfig(20_000))->rows)->toHaveCount(1);
});

it('collects and tracks an alert even without recipients', function (): void {
    $alert = Alert::query()->create([
        'type_key' => 'dts-over-20k',
        'name' => 'DTS with no recipients',
        'source_config' => new AlertSourceConfig([]),
        'definition_version' => 1,
        'enabled_at' => now(),
    ]);
    $schedule = $alert->schedules()->create([
        'schedule_type' => ScheduleType::Cron,
        'schedule_definition' => '0 4 * * *',
        'timezone' => 'America/New_York',
        'data_params' => ['minimum_dts_total' => 20_000],
        'next_run_at' => now()->subMinute(),
        'enabled_at' => now(),
    ]);
    $run = AlertRun::query()->create([
        'alert_id' => $alert->id,
        'alert_schedule_id' => $schedule->id,
        'scheduled_for' => now()->subMinute(),
        'status' => ProcessStatus::Queued,
        'idempotency_key' => 'no-recipients-test',
    ]);

    app(AlertRunner::class)->run($run);
    $run->refresh();

    expect($run->status)->toBe(ProcessStatus::Skipped)
        ->and($run->context['matched_row_count'])->toBe(0)
        ->and($run->context['source_stats'][0]['status'])->toBe('succeeded')
        ->and($run->context['recipient_count'])->toBe(0)
        ->and($run->context['legacy_write']['status'])->toBe('succeeded')
        ->and(DB::connection('allrivers')->table('alertTracking')->value('runCount'))->toBe(0)
        ->and(DB::connection('allrivers')->table('alertTracking')->value('totalRunCount'))->toBe(1)
        ->and(DB::connection('allrivers')->table('dimReporting')->value('name'))->toBe('dtsOver20kAlert');
});

it('runs a general collector without legacy tracking configuration', function (): void {
    config()->set('alerts.registry.dts-over-20k', [
        'collector' => \App\Services\Alerts\NoopAlertCollector::class,
        'definition_version' => 1,
    ]);
    $alert = Alert::query()->create([
        'type_key' => 'dts-over-20k',
        'name' => 'General alert',
        'source_config' => new AlertSourceConfig(['connection' => 'datasync']),
        'definition_version' => 1,
        'enabled_at' => now(),
    ]);
    $schedule = $alert->schedules()->create([
        'schedule_type' => ScheduleType::Cron,
        'schedule_definition' => '0 4 * * *',
        'timezone' => 'America/New_York',
        'data_params' => [],
        'next_run_at' => now()->subMinute(),
        'enabled_at' => now(),
    ]);
    $run = AlertRun::query()->create([
        'alert_id' => $alert->id,
        'alert_schedule_id' => $schedule->id,
        'scheduled_for' => now()->subMinute(),
        'status' => ProcessStatus::Queued,
        'idempotency_key' => 'general-alert-test',
    ]);

    app(AlertRunner::class)->run($run);
    $run->refresh();

    expect($run->status)->toBe(ProcessStatus::Skipped)
        ->and($run->context)->not->toHaveKey('legacy_write')
        ->and(DB::connection('allrivers')->table('alertTracking')->count())->toBe(0);
});

it(
    'groups the selected need-by date without applying a different expression',
    function (): void {
        $datasync = DB::connection('datasync');
        $datasync->enableQueryLog();

            (new DtsOver20kAlertCollector(CarbonImmutable::parse('2026-09-14')))->buildRows(dtsDataConfig());

        $query = collect($datasync->getQueryLog())
            ->pluck('query')
            ->first(fn (string $sql): bool => str_contains($sql, 'line_items'));

        expect($query)
            ->toContain('"line_items"."customer_need_by_date"')
            ->not->toContain('CAST(line_items.customer_need_by_date AS CHAR)');
    },
);

it(
    'alerts once outside the two-week window and once after the need-by date enters it',
    function (): void {
        DB::connection('datasync')->table('pmhubTracker')->insert([
            'trackerNumber' => 'T-WINDOW',
            'trackerId' => 'WINDOW',
            'trackerCreatedDate' => '2026-08-01',
            'deleted' => false,
        ]);
        DB::connection('datasync')->table('aplusOrders')->insert([
            'orderNumberGenKey' => 'O-WINDOW',
            'orderNumberKey' => 'O-WINDOW',
        ]);
        DB::connection('datasync')->table('aplusOrderDetail')->insert([
            'orderNumberGenKey' => 'O-WINDOW',
            'orderLineSKU' => 'CESS-DTS-1-WINDOW',
            'orderLineTotalCost' => 19_000,
        ]);
        DB::connection('datasync')->table('pmhubOrderTracker')->insert([
            'orderKey' => 'O-WINDOW',
            'trackerNumber' => 'T-WINDOW',
        ]);
        DB::connection('datasync')->table('pmhubLineItem')->insert([
            'trackerId' => 'WINDOW',
            'itemSku' => 'CESS-DTS-1-WINDOW',
            'customerNeedByDate' => '2026-09-15',
        ]);

        $rowsOnAugust14 = (new DtsOver20kAlertCollector(CarbonImmutable::parse('2026-08-14')))->buildRows(dtsDataConfig());
        expect($rowsOnAugust14)->toBeEmpty();

        DB::connection('datasync')->table('aplusOrderDetail')
            ->where('orderNumberGenKey', 'O-WINDOW')
            ->update(['orderLineTotalCost' => 22_000]);

        $outsideWindowCollector = new DtsOver20kAlertCollector(CarbonImmutable::parse('2026-08-15'));
        $outsideWindowRows = $outsideWindowCollector->buildRows(dtsDataConfig());
        expect($outsideWindowRows)->toHaveCount(1)
            ->and($outsideWindowRows->first()['within_two_weeks'])->toBeFalse();
        writePreviousDtsAlertState($outsideWindowRows, '2026-08-15');

        expect((new DtsOver20kAlertCollector(CarbonImmutable::parse('2026-08-16')))->buildRows(dtsDataConfig()))->toBeEmpty()
            ->and((new DtsOver20kAlertCollector(CarbonImmutable::parse('2026-08-31')))->buildRows(dtsDataConfig()))->toBeEmpty();

        $insideWindowCollector = new DtsOver20kAlertCollector(CarbonImmutable::parse('2026-09-01'));
        $insideWindowRows = $insideWindowCollector->buildRows(dtsDataConfig());
        expect($insideWindowRows)->toHaveCount(1)
            ->and($insideWindowRows->first()['within_two_weeks'])->toBeTrue();
        writePreviousDtsAlertState($insideWindowRows, '2026-09-01');

        expect((new DtsOver20kAlertCollector(CarbonImmutable::parse('2026-09-02')))->buildRows(dtsDataConfig()))->toBeEmpty();
    },
);

it(
    'excludes completed, deleted, and below-threshold trackers',
    function(): void {
        DB::connection('datasync')->table('pmhubTracker')->insert([
            [
                'trackerNumber' => 'T-COMPLETE',
                'trackerId' => '1',
                'trackerCreatedDate' => '2026-09-01',
                'psCompDate' => '2026-09-02',
                'lcCompDate' => '2026-09-02',
                'deleted' => false,
            ], [
                'trackerNumber' => 'T-DELETED',
                'trackerId' => '2',
                'trackerCreatedDate' => '2026-09-01',
                'psCompDate' => null,
                'lcCompDate' => null,
                'deleted' => true,
            ], [
                'trackerNumber' => 'T-LOW',
                'trackerId' => '3',
                'trackerCreatedDate' => '2026-09-01',
                'psCompDate' => null,
                'lcCompDate' => null,
                'deleted' => false,
            ],
        ]);
        DB::connection('datasync')->table('aplusOrders')->insert([
            ['orderNumberGenKey' => 'O-1', 'orderNumberKey' => 'O-1'],
            ['orderNumberGenKey' => 'O-2', 'orderNumberKey' => 'O-2'],
            ['orderNumberGenKey' => 'O-3', 'orderNumberKey' => 'O-3'],
        ]);
        DB::connection('datasync')->table('aplusOrderDetail')->insert([
            ['orderNumberGenKey' => 'O-1', 'orderLineSKU' => 'CESS-DTS-1', 'orderLineTotalCost' => 20_000],
            ['orderNumberGenKey' => 'O-2', 'orderLineSKU' => 'CESS-DTS-3', 'orderLineTotalCost' => 20_000],
            ['orderNumberGenKey' => 'O-3', 'orderLineSKU' => 'CESS-DTS-1', 'orderLineTotalCost' => 19_999.99],
        ]);
        DB::connection('datasync')->table('pmhubOrderTracker')->insert([
            ['orderKey' => 'O-1', 'trackerNumber' => 'T-COMPLETE'],
            ['orderKey' => 'O-2', 'trackerNumber' => 'T-DELETED'],
            ['orderKey' => 'O-3', 'trackerNumber' => 'T-LOW'],
        ]);

        expect((new DtsOver20kAlertCollector(CarbonImmutable::parse('2026-09-14')))->buildRows(dtsDataConfig()))->toBeEmpty();
    },
);
