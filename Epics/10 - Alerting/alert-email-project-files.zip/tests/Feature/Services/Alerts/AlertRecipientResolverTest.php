<?php
declare(strict_types=1);

use App\DTO\Alerts\AlertSourceConfig;
use App\Models\Alerts\Alert;
use App\Models\Role;
use App\Models\User;
use App\Services\Alerts\AlertRecipientResolver;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Schema;

beforeEach(function (): void {
    config()->set('database.connections.datasync', [
        'driver' => 'sqlite',
        'database' => ':memory:',
        'prefix' => '',
    ]);
    DB::purge('datasync');

    Schema::connection('datasync')->create('adpUsers', function (Blueprint $table): void {
        $table->string('worker_id')->primary();
        $table->string('work_email')->nullable();
        $table->string('status')->nullable();
    });
});

it('resolves distinct users from enabled alert roles', function (): void {
    $enabledRole = Role::factory()->create();
    $secondEnabledRole = Role::factory()->create();
    $disabledRole = Role::factory()->create();
    $includedUser = User::factory()->create(['email' => 'included@example.test']);
    $inactiveUser = User::factory()->create(['email' => 'inactive@example.test']);
    $excludedUser = User::factory()->create(['email' => 'excluded@example.test']);
    $missingEmailUser = User::factory()->create(['email' => '']);
    $alert = Alert::query()->create([
        'type_key' => 'dts-over-20k',
        'name' => 'DTS recipients',
        'source_config' => new AlertSourceConfig([
            'connection' => 'datasync',
            'legacy_tracking_connection' => 'allrivers',
        ]),
        'definition_version' => 1,
        'enabled_at' => now(),
    ]);
    $alert->roles()->attach([
        $enabledRole->id => ['enabled' => true],
        $secondEnabledRole->id => ['enabled' => true],
        $disabledRole->id => ['enabled' => false],
    ]);

    $modelHasRoles = config('permission.table_names.model_has_roles');
    $modelKey = config('permission.column_names.model_morph_key', 'model_id');
    $roleKey = config('permission.column_names.role_pivot_key') ?? 'role_id';
    foreach ([
        [$enabledRole, $includedUser],
        [$secondEnabledRole, $includedUser],
        [$enabledRole, $inactiveUser],
        [$disabledRole, $excludedUser],
        [$enabledRole, $missingEmailUser],
    ] as [$role, $user]) {
        DB::table($modelHasRoles)->insert([
            $roleKey => $role->id,
            $modelKey => $user->id,
            'model_type' => User::class,
            config('permission.column_names.team_foreign_key') => 1,
        ]);
    }

    DB::connection('datasync')->table('adpUsers')->insert([
        ['worker_id' => 'active-recipient', 'work_email' => $includedUser->email, 'status' => 'Active'],
        ['worker_id' => 'inactive-recipient', 'work_email' => $inactiveUser->email, 'status' => 'Inactive'],
    ]);

    $recipients = app(AlertRecipientResolver::class)->resolve($alert);

    expect($recipients)->toHaveCount(1)
        ->and($recipients->toArray()[0]->email->address)->toBe('included@example.test')
        ->and($recipients->toArray()[0]->name)->toBe($includedUser->name);
});
