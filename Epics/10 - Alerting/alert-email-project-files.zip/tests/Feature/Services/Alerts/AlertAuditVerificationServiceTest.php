<?php

use App\Models\AlertAudit;
use App\Models\AlertAuditVerification;
use App\Models\AllRivers\AlertTracking;
use App\Services\Alerts\Audit\AlertAuditVerificationService;
use Illuminate\Support\Carbon;

beforeEach(function () {
    Carbon::setTestNow('2025-02-01');
});


it('handles audit by syncing and generating alert audits', function () {

    // ------------------------------------------------------------------
    // 1. Create normal AlertAudit entry
    // ------------------------------------------------------------------
    AlertAudit::factory()->create([
        'name'            => 'AlertA',
        'cadence_in_days' => 30,
        'last_verified'   => null,
    ]);

    // ------------------------------------------------------------------
    // 2. Seed AlertTracking rows
    // ------------------------------------------------------------------
    AlertTracking::factory()->create([
        'name'    => 'AlertA',
        'runDate' => now()->subDays(3),
    ]);

    AlertTracking::factory()->create([
        'name'    => 'AlertB',
        'runDate' => now()->subDays(1),
    ]);

    // ------------------------------------------------------------------
    // 3. Reporting data for AlertA
    // ------------------------------------------------------------------
    AlertTracking::factory()
        ->withReporting(1, [
            'ownerEmail'     => 'owner@example.com',
            'requestorEmail' => 'req@example.com',
            'displayName'    => 'DisplayA',
        ])
        ->create([
            'name'    => 'AlertA',
            'runDate' => now()->subDay(),
        ]);

    // ------------------------------------------------------------------
    // 4. Act
    // ------------------------------------------------------------------
    $service = new AlertAuditVerificationService();
    $result = $service->handleAudit();

    // ------------------------------------------------------------------
    // 5. Assert: AlertB was auto-created by syncAlertTracking()
    // ------------------------------------------------------------------
    $alertB = AlertAudit::where('name', 'AlertB')->first();

    expect($alertB)->not->toBeNull();
    expect($alertB->created_at)->toBeNull();

    // ------------------------------------------------------------------
    // 6. Assert audit verification creation
    // ------------------------------------------------------------------
    expect(AlertAuditVerification::count())->toBe(1);

    $verification = AlertAuditVerification::first();

    expect($verification->name)->toBe('AlertA');
    expect($verification->owner_email)->toBe('owner@example.com');
    expect($verification->requester_email)->toBe('req@example.com');

    // ------------------------------------------------------------------
    // 7. Assert output structure
    // ------------------------------------------------------------------
    expect($result)->toBeInstanceOf(\Illuminate\Support\Collection::class);

    expect($result->keys())->toContain('owner@example.com');

    $first = $result['owner@example.com'][0];

    expect($first['name'])->toBe('AlertA');
    expect($first['display_name'])->toBe('DisplayA');
    expect($first['owner_email'])->toBe('owner@example.com');
})->group('skipped')->skip('Needs review');
