<?php
declare(strict_types=1);

use App\DTO\Alerts\AlertDataConfig;
use App\DTO\Alerts\AlertPreview;
use App\DTO\Alerts\AlertSourceConfig;
use App\DTO\Email\EmailAddress;
use App\DTO\Email\EmailBuildRequest;
use App\DTO\Email\Recipient;
use App\DTO\Email\Recipients;
use App\Enums\Alerts\ScheduleType;
use App\Enums\Email\EmailStatus;
use App\Enums\Email\EmailType;
use App\Enums\ProcessStatus;
use App\Listeners\Email\MarkIntentEmailSending;
use App\Listeners\Email\MarkIntentEmailSent;
use App\Mail\Builders\Alert\AlertMailBuilder;
use App\Mail\BuiltMail;
use App\Models\Alerts\Alert;
use App\Models\Alerts\AlertRun;
use App\Models\Email;
use App\Services\Alerts\AlertMessageDispatcher;
use App\Services\Alerts\AlertRunner;
use App\Services\Alerts\Interfaces\AlertCollector;
use Illuminate\Mail\Events\MessageSending;
use Illuminate\Mail\Events\MessageSent;
use Illuminate\Mail\SentMessage;
use Illuminate\Support\Facades\Mail;
use Symfony\Component\Mailer\Envelope as SymfonyEnvelope;
use Symfony\Component\Mailer\SentMessage as SymfonySentMessage;
use Symfony\Component\Mime\Email as SymfonyEmail;

it(
    'persists a related email intent and queues the built alert message',
    function (): void {
        $collector = new class implements AlertCollector
        {
            public function validate(AlertDataConfig $dataConfig): void {}

            public function preview(Alert $alert, AlertDataConfig $dataConfig): AlertPreview
            {
                throw new LogicException('Preview is not used in this run.');
            }

            public function collect(Alert $alert, AlertRun $run, AlertDataConfig $dataConfig): void {}

            public function result(): array
            {
                return [
                    'status' => ProcessStatus::Succeeded,
                    'rows' => [
                        [
                            'tracker_id' => 100,
                            'tracker_number' => 'T-100',
                            'tracker_created_date' => '2026-10-01',
                            'warehouse' => 'Main',
                            'logistics_coordinator_name' => 'Coordinator',
                            'project_specialist_name' => 'Specialist',
                            'account_manager_name' => 'Manager',
                            'customer_name' => 'Customer',
                            'address_1' => '1 Test Street',
                            'city' => 'Boston',
                            'state' => 'MA',
                            'zip' => '02101',
                            'dts_total_cost' => 20_001,
                            'previous_dts_total_cost' => null,
                            'customer_need_by_date' => '2026-10-15',
                            'within_two_weeks' => false,
                        ],
                    ],
                    'context' => ['matched_row_count' => 1],
                ];
            }
        };
        config()->set('alerts.registry.dts-over-20k.collector', $collector);
        config()->set('alerts.registry.dts-over-20k.run_processor', null);
        Mail::fake();

        $alert = Alert::query()->create([
            'type_key' => 'dts-over-20k',
            'name' => 'DTS delivery plan test',
            'source_config' => new AlertSourceConfig([]),
            'definition_version' => 1,
            'enabled_at' => now(),
        ]);
        $schedule = $alert->schedules()->create([
            'schedule_type' => ScheduleType::Cron,
            'schedule_definition' => '0 4 * * *',
            'timezone' => 'America/New_York',
            'data_params' => ['minimum_dts_total' => 20_000],
            'next_run_at' => now()->subMinute(),
            'enabled_at' => now(),
        ]);
        $run = AlertRun::query()->create([
            'alert_id' => $alert->id,
            'alert_schedule_id' => $schedule->id,
            'scheduled_for' => now()->subMinute(),
            'status' => ProcessStatus::Queued,
            'idempotency_key' => 'delivery-plan-test',
        ]);

        $outcome = app(AlertRunner::class)->run($run, test: true);
        $run->refresh();

        expect($run->status)->toBe(ProcessStatus::Succeeded)
            ->and($run->context['planned_message_count'])->toBe(1)
            ->and($run->context['planned_boundary_keys'])->toBe(['all'])
            ->and($run->context['email_count'])->toBe(1)
            ->and($outcome->messages)->toHaveCount(1)
            ->and($outcome->messages[0]->boundaryKey())->toBe('all');
        $intent = Email::query()->sole();
        expect($intent->related_type)
            ->toBe(AlertRun::class)
            ->and($intent->related_id)->toBe($run->id)
            ->and($intent->status)->toBe(EmailStatus::Queued)
            ->and($intent->queued_at)->not
            ->toBeNull()
            ->and($intent->to)->toHaveCount(1)
            ->and($intent->bcc)->toBe([])
            ->and($run->emails()->sole()->id)->toBe($intent->id)
            ->and($run->context['email_messages']['all']['email_id'])->toBe($intent->id)
            ->and($run->context['email_messages']['all']['status'])->toBe('queued');
        Mail::assertNothingSent();
        Mail::assertQueued(
            BuiltMail::class,
            function (BuiltMail $mail) use ($intent): bool {
                return $mail->to[0]['address'] === $intent->to[0]
                       && count($mail->bcc) === 0
                       && $mail->headers()->text['X-Email-Intent-Id'] === (string) $intent->id;
            },
        );

        app(AlertRunner::class)->run($run, test: true);
        expect(Email::query()->count())->toBe(1);
        Mail::assertQueued(BuiltMail::class, 1);

        $unrelated = $intent->replicate();
        $unrelated->related_type = Alert::class;
        $unrelated->related_id = $run->id;
        $unrelated->dedupe_key = 'unrelated-email';
        $unrelated->save();

        expect($intent->alertRun?->is($run))
            ->toBeTrue()
            ->and($unrelated->alertRun)->toBeNull()
            ->and($intent->relatedRecord?->is($run))
            ->toBeTrue();
        $emails = Email::query()->with('relatedRecord')->whereKey([$intent->id, $unrelated->id])->get()->keyBy('id');
        expect($emails[$intent->id]->relatedRecord?->is($run))
            ->toBeTrue()
            ->and($emails[$unrelated->id]->alertRun)->toBeNull()
            ->and($emails[$unrelated->id]->relatedRecord instanceof AlertRun)->toBeFalse()
            ->and(Email::query()->whereHasMorph('relatedRecord', [AlertRun::class])->pluck('id')->all())->toBe([$intent->id]);

        $message = (new SymfonyEmail)
            ->from($intent->from_email)
            ->to($intent->to[0])
            ->subject($intent->subject)
            ->html($intent->body_html);
        $message->getHeaders()->addTextHeader('X-Email-Intent-Id', (string) $intent->id);
        app(MarkIntentEmailSending::class)->handle(new MessageSending($message));
        expect($run->refresh()->context['email_messages']['all']['status'])->toBe('processing');

        $sent = new SentMessage(new SymfonySentMessage($message, SymfonyEnvelope::create($message)));
        app(MarkIntentEmailSent::class)->handle(new MessageSent($sent));
        expect($intent->refresh()->status)
            ->toBe(EmailStatus::Sent)
            ->and($run->refresh()->context['email_messages']['all']['status'])->toBe('sent');
    }
);

it(
    'keeps a separate intent and status snapshot for every message boundary',
    function (): void {
        Mail::fake();
        $alert = Alert::query()->create(
            [
                'type_key' => 'dts-over-20k',
                'name' => 'Two-boundary alert',
                'source_config' => new AlertSourceConfig([]),
                'definition_version' => 1,
                'enabled_at' => now(),
            ],
        );
        $schedule = $alert->schedules()->create(
            [
                'schedule_type' => ScheduleType::Cron,
                'schedule_definition' => '0 4 * * *',
                'timezone' => 'America/New_York',
                'data_params' => ['minimum_dts_total' => 20_000],
                'next_run_at' => now()->subMinute(),
                'enabled_at' => now(),
            ],
        );
        $run = AlertRun::query()->create(
            [
                'alert_id' => $alert->id,
                'alert_schedule_id' => $schedule->id,
                'scheduled_for' => now()->subMinute(),
                'status' => ProcessStatus::Queued,
                'idempotency_key' => 'two-boundary-alert',
            ],
        );
        $recipients = new Recipients(new Recipient(new EmailAddress('recipient@example.test'), 'Recipient'));
        $requests = array_map(
            fn (string $key): EmailBuildRequest => new EmailBuildRequest(
                boundaryKey: $key,
                type: EmailType::DTSOver20kAlert,
                recipients: $recipients,
                subject: 'DTS alert',
                template: 'emails.alerts.dts-over-20k',
                viewData: ['rows' => collect(), 'generatedAt' => now()],
                relatedType: AlertRun::class,
                relatedId: $run->id,
            ),
            ['first', 'second'],
        );
        $messages = array_map(app(AlertMailBuilder::class)->build(...), $requests);

        app(AlertMessageDispatcher::class)->dispatch($run, $requests, $messages);
        app(AlertMessageDispatcher::class)->dispatch($run, $requests, $messages);

        expect($run->emails()->count())
            ->toBe(2)
            ->and($run->refresh()->context['email_count'])->toBe(2)
            ->and(array_keys($run->context['email_messages']))->toEqualCanonicalizing(['first', 'second']);
        Mail::assertQueued(BuiltMail::class, 2);

        $messages[0]->failed(new RuntimeException('Message failed'));
        expect($run->refresh()->context['email_messages']['first']['status'])
            ->toBe('failed')
            ->and($run->context['email_messages']['second']['status'])->toBe('queued')
            ->and($run->emails()->where('context->boundary_key', 'first')->sole()->status)->toBe(EmailStatus::Failed);
    });
