<?php
declare(strict_types=1);

use App\Enums\Email\EmailType;

it(
    'derives dashboard displays and existing access codes from email types',
    function(): void
    {
        expect(EmailType::OrderAcknowledgement->display())
            ->toBe('Order Acknowledgement')
            ->and(
                EmailType::DTSTrackerAssignment->display(),
            )->toBe('DTS Tracker Assignment')
            ->and(
                EmailType::DTSOver20kAlert->display(),
            )->toBe('DTS Over 20k Alert')
            ->and(
                EmailType::GenericAlert->display(),
            )->toBe('Generic Alert')
            ->and(
                EmailType::OrderAcknowledgement->permissionCode(),
            )
            ->toBe('mailable-order-acknowledgement')
            ->and(
                EmailType::ItemTypePendingReviewDigest->permissionCode(),
            )
            ->toBe('mailable-item-type-pending-review-digest')
            ->and(
                EmailType::GenericAlert->permissionCode(),
            )
            ->toBe('mailable-generic-alert')
            ->and(
                EmailType::DTSOver20kAlert->permissionCode(),
            )
            ->toBe('mailable-dts-over20k-alert')
            ->and(
                EmailType::POSubmissionRejected->permissionCode(),
            )
            ->toBe('mailable-po-submission-rejected');
    },
);
