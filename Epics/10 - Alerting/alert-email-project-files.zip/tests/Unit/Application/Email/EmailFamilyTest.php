<?php
declare(strict_types=1);

use App\Enums\Email\EmailFamily;
use App\Enums\Email\EmailType;
use App\Mail\Builders\Alert\AlertMailBuilder;
use App\Mail\Builders\FormRivers\FormRiversMailBuilder;
use App\Mail\Builders\General\GeneralMailBuilder;
use App\Mail\Builders\ItemType\ItemTypeMailBuilder;
use App\Mail\Builders\Portal\PortalMailBuilder;
use App\Mail\Builders\POSubmission\POSubmissionMailBuilder;

it('classifies every legacy email type and mailable', function (): void {
    foreach (EmailType::cases() as $type) {
        expect(EmailFamily::fromMailableClass($type->mailableClass()))->toBe($type->family());
    }

    expect(EmailFamily::fromMailableClass('Unknown\\Mail'))->toBeNull()
        ->and(EmailType::DTSOver20kAlert->family())->toBe(EmailFamily::Alert)
        ->and(EmailType::OrderInvoice->family())->toBe(EmailFamily::FormRivers)
        ->and(EmailType::ItemTypePendingReviewDigest->family())->toBe(EmailFamily::ItemType)
        ->and(EmailType::POSubmissionRejected->family())->toBe(EmailFamily::POSubmission)
        ->and(EmailType::PortalWelcome->family())->toBe(EmailFamily::Portal)
        ->and(EmailType::SyncSummary->family())->toBe(EmailFamily::General);
});

it('provides one builder for each family', function (): void {
    $builders = [
        new AlertMailBuilder,
        new FormRiversMailBuilder,
        new GeneralMailBuilder,
        new ItemTypeMailBuilder,
        new POSubmissionMailBuilder,
        new PortalMailBuilder,
    ];

    expect(array_map(fn ($builder) => $builder->family(), $builders))
        ->toEqualCanonicalizing(EmailFamily::cases());
});
