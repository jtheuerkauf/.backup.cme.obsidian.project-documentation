<?php
declare(strict_types=1);

use App\Enums\Alerts\AlertType;
use App\Services\Alerts\AlertsRegistry;
use App\Services\Alerts\Collectors\Legacy\DtsOver20kAlertCollector;
use App\Services\Alerts\Interfaces\AlertCollector;
use App\Services\Alerts\Interfaces\AlertRunProcessor;
use App\Services\Alerts\Legacy\RunProcessor;
use App\Services\Alerts\UnknownAlertType;
use Tests\TestCase;

uses(TestCase::class);

it('reads legacy reporting fields from the registered definition', function (): void {
    config()->set('alerts.registry.dts-over-20k.legacy_reporting.ownerEmail', 'configured@example.test');

    expect(app(AlertsRegistry::class)->legacyReporting(AlertType::DtsOver20k)['ownerEmail'])
        ->toBe('configured@example.test');
});

it('reads the DTS mail subject from the registered definition', function (): void {
    config()->set('alerts.registry.dts-over-20k.mail_subject', 'Configured DTS subject');

    expect(app(AlertsRegistry::class)->mailSubject(AlertType::DtsOver20k))
        ->toBe('Configured DTS subject');
});

it('returns the collector instance from the alert definition', function (): void {
    $collector = Mockery::mock(AlertCollector::class);
    config()->set('alerts.registry.'.AlertType::DtsOver20k->slug().'.collector', $collector);

    expect(app(AlertsRegistry::class)->collector(AlertType::DtsOver20k))->toBe($collector);
});

it('resolves a collector class from the alert definition', function (): void {
    config()->set('alerts.registry.'.AlertType::DtsOver20k->slug().'.collector', DtsOver20kAlertCollector::class);

    expect(app(AlertsRegistry::class)->collector(AlertType::DtsOver20k))
        ->toBeInstanceOf(DtsOver20kAlertCollector::class);
});

it('rejects a collector that does not implement the interface', function (mixed $collector): void {
    config()->set('alerts.registry.'.AlertType::DtsOver20k->slug().'.collector', $collector);

    expect(fn () => app(AlertsRegistry::class)->collector(AlertType::DtsOver20k))
        ->toThrow(UnknownAlertType::class, 'Unsupported Collector for alert type [dts-over-20k].');
})->with([
    'missing collector' => [null],
    'invalid class' => [stdClass::class],
    'invalid instance' => [new stdClass],
]);

it('returns the processor instance from the alert definition', function (): void {
    $processor = Mockery::mock(AlertRunProcessor::class);
    config()->set('alerts.registry.'.AlertType::DtsOver20k->slug().'.run_processor', $processor);

    expect(app(AlertsRegistry::class)->runProcessor(AlertType::DtsOver20k))->toBe($processor);
});

it('resolves a processor class from the alert definition', function (): void {
    config()->set('alerts.registry.' . AlertType::DtsOver20k->slug() . '.run_processor', RunProcessor::class);

    expect(app(AlertsRegistry::class)->runProcessor(AlertType::DtsOver20k))
        ->toBeInstanceOf(RunProcessor::class);
});

it('returns null when the alert definition has no processor', function (): void {
    config()->set('alerts.registry.'.AlertType::DtsOver20k->slug().'.run_processor', null);

    expect(app(AlertsRegistry::class)->runProcessor(AlertType::DtsOver20k))->toBeNull();
});

it('rejects a processor that does not implement the interface', function (mixed $processor): void {
    config()->set('alerts.registry.'.AlertType::DtsOver20k->slug().'.run_processor', $processor);

    expect(fn () => app(AlertsRegistry::class)->runProcessor(AlertType::DtsOver20k))
        ->toThrow(UnknownAlertType::class, 'Unsupported Run Processor for alert type [dts-over-20k].');
})->with([
    'invalid class' => [stdClass::class],
    'invalid instance' => [new stdClass],
]);
