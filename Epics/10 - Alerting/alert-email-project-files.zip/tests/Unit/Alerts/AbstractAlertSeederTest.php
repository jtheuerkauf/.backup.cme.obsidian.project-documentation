<?php
declare(strict_types=1);

use App\Enums\Alerts\AlertType;
use App\Enums\Alerts\ScheduleType;
use App\Models\Alerts\Alert;
use App\Models\Alerts\AlertSchedule;
use App\Models\Role;
use App\Services\Alerts\UnknownAlertType;
use Database\Seeders\Alerts\AbstractAlertSeeder;
use Database\Seeders\Alerts\DtsOver20kAlertSeeder;
use Illuminate\Foundation\Testing\LazilyRefreshDatabase;
use Illuminate\Support\Facades\DB;
use Tests\TestCase;

uses(TestCase::class, LazilyRefreshDatabase::class);

function validAbstractAlertSeederData(): array
{
    return [
        'alert' => [
            'type_key' => AlertType::DtsOver20k,
            'name' => 'Seeder test alert',
            'source_config' => [],
        ],
        'schedule' => [
            'schedule_type' => ScheduleType::Cron,
            'schedule_definition' => '0 4 * * *',
            'timezone' => 'America/New_York',
            'data_params' => ['minimum_dts_total' => 20_000],
        ],
        'recipient_roles' => [],
    ];
}

function abstractAlertSeederWith(array $data): AbstractAlertSeeder
{
    return new class($data) extends AbstractAlertSeeder
    {
        public function __construct(private array $data) {}

        protected function seedData(): array
        {
            return $this->data;
        }
    };
}

it('rejects an alert type that is not an AlertType case before writing', function (): void {
    $data = validAbstractAlertSeederData();
    $data['alert']['type_key'] = 'missing-alert-type';

    try {
        abstractAlertSeederWith($data)->run();
        $this->fail('Expected an invalid alert type to fail validation.');
    } catch (InvalidArgumentException $e) {
        expect($e->getMessage())->toBe('alerts.type_key must be an AlertType enum case.')
            ->and($e->getPrevious())->toBeInstanceOf(TypeError::class);
    }
    expect(Alert::query()->count())->toBe(0);
});

it('requires a registry entry with a definition version', function (array $registry): void {
    config()->set('alerts.registry', $registry);

    expect(fn () => abstractAlertSeederWith(validAbstractAlertSeederData())->run())
        ->toThrow(UnknownAlertType::class, 'Unsupported alert type [dts-over-20k].');
    expect(Alert::query()->count())->toBe(0);
})->with([
    'missing entry' => [[]],
    'missing version' => [['dts-over-20k' => []]],
]);

it('rejects a schedule type that is not a ScheduleType case before writing', function (): void {
    $data = validAbstractAlertSeederData();
    $data['schedule']['schedule_type'] = 'missing-schedule-type';

    try {
        abstractAlertSeederWith($data)->run();
        $this->fail('Expected an invalid schedule type to fail validation.');
    } catch (InvalidArgumentException $e) {
        expect($e->getMessage())->toBe('alert_schedules.schedule_type must be a ScheduleType enum case.')
            ->and($e->getPrevious())->toBeInstanceOf(TypeError::class);
    }
    expect(Alert::query()->count())->toBe(0);
});

it('rejects an invalid cron expression before writing', function (): void {
    $data = validAbstractAlertSeederData();
    $data['schedule']['schedule_definition'] = 'not a cron expression';

    expect(fn () => abstractAlertSeederWith($data)->run())
        ->toThrow(InvalidArgumentException::class, 'Invalid alert_schedules.schedule_definition cron expression.');
    expect(Alert::query()->count())->toBe(0);
});

it('rejects an invalid timezone before writing', function (): void {
    $data = validAbstractAlertSeederData();
    $data['schedule']['timezone'] = 'Invalid/Timezone';

    expect(fn () => abstractAlertSeederWith($data)->run())
        ->toThrow(InvalidArgumentException::class, 'Invalid alert_schedules.timezone [Invalid/Timezone].');
    expect(Alert::query()->count())->toBe(0);
});

it('rejects a recipient that is neither a role ID nor a code', function (): void {
    $data = validAbstractAlertSeederData();
    $data['recipient_roles'] = [1.5];

    expect(fn () => abstractAlertSeederWith($data)->run())
        ->toThrow(InvalidArgumentException::class, 'Alert recipients must be integer role IDs or roles.code strings.');
    expect(Alert::query()->count())->toBe(0);
});

it('rejects recipient IDs and codes that have no role', function (int|string $recipient): void {
    $data = validAbstractAlertSeederData();
    $data['recipient_roles'] = [$recipient];

    expect(fn () => abstractAlertSeederWith($data)->run())
        ->toThrow(InvalidArgumentException::class, "No role matches recipient role [{$recipient}].");
    expect(Alert::query()->count())->toBe(0);
})->with([
    'missing ID' => [999_999],
    'missing code' => ['MISSING_ROLE_CODE'],
]);

it('writes the alert, schedule, and role recipients and can be rerun', function (): void {
    $idRole = Role::factory()->create(['code' => 'ALERT_BY_ID']);
    $codeRole = Role::factory()->create(['code' => 'ALERT_BY_CODE']);
    $disabledRole = Role::factory()->create(['code' => 'ALERT_DISABLED']);
    $data = validAbstractAlertSeederData();
    $data['recipient_roles'] = [$idRole->id, 'ALERT_BY_CODE', 'ALERT_DISABLED' => false];
    $seeder = abstractAlertSeederWith($data);

    $seeder->run();
    $seeder->run();

    $alert = Alert::query()->sole();
    $schedule = AlertSchedule::query()->sole();
    expect($alert->type_key)->toBe(AlertType::DtsOver20k)
        ->and($alert->name)->toBe($data['alert']['name'])
        ->and($alert->source_config->source)->toBe($data['alert']['source_config'])
        ->and($alert->definition_version)->toBe(1)
        ->and($schedule->alert_id)->toBe($alert->id)
        ->and($schedule->schedule_type)->toBe(ScheduleType::Cron)
        ->and($schedule->schedule_definition)->toBe($data['schedule']['schedule_definition'])
        ->and($schedule->timezone)->toBe($data['schedule']['timezone'])
        ->and($schedule->data_params)->toBe($data['schedule']['data_params'])
        ->and($schedule->data_params_hash)->toBe(AlertSchedule::dataParamsHash($data['schedule']['data_params']))
        ->and($schedule->next_run_at)->not->toBeNull()
        ->and(DB::table('alert_role_recipients')->count())->toBe(3)
        ->and((bool) DB::table('alert_role_recipients')->where('role_id', $idRole->id)->value('enabled'))->toBeTrue()
        ->and((bool) DB::table('alert_role_recipients')->where('role_id', $codeRole->id)->value('enabled'))->toBeTrue()
        ->and((bool) DB::table('alert_role_recipients')->where('role_id', $disabledRole->id)->value('enabled'))->toBeFalse();
});

it('seeds the DTS alert with its enum type and schedule', function (): void {
    Role::factory()->create(['id' => 590]);
    $pmRole = Role::factory()->create(['code' => 'DTSPM']);
    $vpRole = Role::factory()->create(['code' => 'VPSSO']);

    (new DtsOver20kAlertSeeder)->run();

    $alert = Alert::query()->sole();
    $schedule = AlertSchedule::query()->sole();
    expect($alert->type_key)->toBe(AlertType::DtsOver20k)
        ->and($schedule->schedule_type)->toBe(ScheduleType::Cron)
        ->and($schedule->data_params)->toBe(['minimum_dts_total' => 20_000])
        ->and(DB::table('alert_role_recipients')->pluck('role_id')->all())
        ->toEqualCanonicalizing([590, $pmRole->id, $vpRole->id]);
});
