<?php
declare(strict_types=1);

use App\Enums\Alerts\AlertType;
use App\Services\Alerts\Legacy\AlertTracker;
use Tests\TestCase;

uses(TestCase::class);

it('uses the legacy calling filename for DTS tracking', function (): void {
    expect(AlertTracker::alertTrackingName(AlertType::DtsOver20k))
        ->toBe('dtsOver20kAlert');
});

it('uses the tracking identity registered for the alert type', function (): void {
    config()->set('alerts.registry.dts-over-20k.legacy_tracking_name', 'configuredDtsAlert');

    expect(AlertTracker::alertTrackingName(AlertType::DtsOver20k))
        ->toBe('configuredDtsAlert');
});
