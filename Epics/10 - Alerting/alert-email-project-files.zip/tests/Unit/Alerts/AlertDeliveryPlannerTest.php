<?php
declare(strict_types=1);

use App\DTO\Alerts\AlertDataConfig;
use App\DTO\Alerts\AlertMessageBoundary;
use App\DTO\Alerts\AlertPreview;
use App\DTO\Email\EmailAddress;
use App\DTO\Email\Recipient;
use App\DTO\Email\Recipients;
use App\Enums\Email\EmailType;
use App\Mail\Builders\Alert\AlertMailBuilder;
use App\Models\Alerts\Alert;
use App\Models\Alerts\AlertRun;
use App\Services\Alerts\AlertDeliveryPlanner;
use App\Services\Alerts\Interfaces\AlertBoundaryPlanner;
use App\Services\Alerts\Interfaces\AlertCollector;
use App\Support\Email\EmailMetadataResolver;
use Carbon\CarbonImmutable;
use Tests\TestCase;

uses(TestCase::class);

function collectedAlertRows(array $rows): AlertCollector
{
    return new class($rows) implements AlertCollector
    {
        public function __construct(private array $rows) {}

        public function validate(AlertDataConfig $dataConfig): void {}

        public function preview(Alert $alert, AlertDataConfig $dataConfig): AlertPreview
        {
            throw new LogicException('Preview is not used by delivery planning.');
        }

        public function collect(Alert $alert, AlertRun $run, AlertDataConfig $dataConfig): void {}

        public function result(): array
        {
            return ['rows' => $this->rows];
        }
    };
}

function alertDeliveryRun(): AlertRun
{
    $run = new AlertRun(['started_at' => CarbonImmutable::parse('2026-09-14 08:00:00')]);
    $run->setRelation('alert', new Alert(['type_key' => 'dts-over-20k']));

    return $run;
}

it('builds one typed broadcast message from the collected rows', function (): void {
    $rows = [['tracker_number' => 'T-1'], ['tracker_number' => 'T-2']];
    $recipients = new Recipients(
        new Recipient(new EmailAddress('one@example.com'), 'One'),
        new Recipient(new EmailAddress('two@example.com'), 'Two'),
    );

    $requests = app(AlertDeliveryPlanner::class)->plan(collectedAlertRows($rows), alertDeliveryRun(), $recipients);
    expect($requests)->toHaveCount(1)
        ->and($requests[0]->boundaryKey)->toBe('all')
        ->and($requests[0]->type)->toBe(EmailType::DTSOver20kAlert)
        ->and($requests[0]->viewData['rows']->all())->toBe($rows);

    $mail = app(AlertMailBuilder::class)->build($requests[0]);
    expect($mail->envelope()->subject)->toBe('Trackers with DTS-1 or DTS-3 Orders over $20K')
        ->and($mail->content()->view)->toBe('emails.alerts.dts-over-20k')
        ->and(array_column($mail->to, 'address'))->toBe(['one@example.com', 'two@example.com'])
        ->and($mail->bcc)->toBe([])
        ->and($mail->headers()->text['X-Email-Mailable'])->toBe(EmailType::DTSOver20kAlert->value)
        ->and(app(EmailMetadataResolver::class)->resolveFromMailable($mail)['mailable'])
        ->toBe(EmailType::DTSOver20kAlert->value);
});

it('keeps each boundary data with its own recipient set', function (): void {
    $rows = [
        ['tracker_number' => 'T-1', 'account_manager' => 'A'],
        ['tracker_number' => 'T-2', 'account_manager' => 'B'],
    ];
    $planner = new class implements AlertBoundaryPlanner
    {
        public function boundaries(AlertCollector $collector, AlertRun $run, Recipients $recipients): array
        {
            $rows = $collector->result()['rows'];

            return [
                new AlertMessageBoundary('manager:A', [$rows[0]], new Recipients(
                    new Recipient(new EmailAddress('a@example.com'), 'Manager A'),
                )),
                new AlertMessageBoundary('manager:B', [$rows[1]], new Recipients(
                    new Recipient(new EmailAddress('b@example.com'), 'Manager B'),
                )),
            ];
        }
    };
    config()->set('alerts.registry.dts-over-20k.email_delivery.boundary_planner', $planner);

    $requests = app(AlertDeliveryPlanner::class)->plan(
        collectedAlertRows($rows),
        alertDeliveryRun(),
        new Recipients,
    );

    expect($requests)->toHaveCount(2)
        ->and($requests[0]->boundaryKey)->toBe('manager:A')
        ->and($requests[0]->viewData['rows']->all())->toBe([$rows[0]])
        ->and($requests[0]->recipients->toArray()[0]->email->address)->toBe('a@example.com')
        ->and($requests[1]->boundaryKey)->toBe('manager:B')
        ->and($requests[1]->viewData['rows']->all())->toBe([$rows[1]])
        ->and($requests[1]->recipients->toArray()[0]->email->address)->toBe('b@example.com');
});

it('rejects duplicate boundary keys before building messages', function (): void {
    $planner = new class implements AlertBoundaryPlanner
    {
        public function boundaries(AlertCollector $collector, AlertRun $run, Recipients $recipients): array
        {
            return [
                new AlertMessageBoundary('owner:A', [['tracker_number' => 'T-1']], $recipients),
                new AlertMessageBoundary('owner:A', [['tracker_number' => 'T-2']], $recipients),
            ];
        }
    };
    config()->set('alerts.registry.dts-over-20k.email_delivery.boundary_planner', $planner);
    $recipients = new Recipients(new Recipient(new EmailAddress('a@example.com'), 'Manager A'));

    expect(fn () => app(AlertDeliveryPlanner::class)->plan(
        collectedAlertRows([['tracker_number' => 'T-1'], ['tracker_number' => 'T-2']]),
        alertDeliveryRun(),
        $recipients,
    ))->toThrow(UnexpectedValueException::class, 'distinct, nonempty keys');
});
