<?php
declare(strict_types=1);

use App\Models\Alerts\AlertSchedule;

it('hashes associative data parameters independent of key order', function (): void {
    $first = ['window' => ['to' => 'today', 'from' => 'yesterday'], 'minimum_dts_total' => 20_000];
    $second = ['minimum_dts_total' => 20_000, 'window' => ['from' => 'yesterday', 'to' => 'today']];

    expect(AlertSchedule::dataParamsHash($first))->toBe(AlertSchedule::dataParamsHash($second));
});
